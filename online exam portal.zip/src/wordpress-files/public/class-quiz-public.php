<?php
/**
 * Class CEQ_Quiz_Public
 * Designs shortcodes and registers frontend stylesheets/script dependencies.
 */

if (!defined('ABSPATH')) {
    exit;
}

class CEQ_Quiz_Public {

    public function __construct() {
        add_shortcode('competitive_quiz', array($this, 'render_quiz_portal_shortcode'));
        add_shortcode('check_online_test_results', array($this, 'render_online_test_results_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_frontend_assets'));
    }

    /**
     * Cache script registers securely
     */
    public function register_frontend_assets() {
        // Registers styling parameters for our SSC/CBT look
        wp_register_style('ceq-exam-style', CEQ_URL . 'public/css/quiz-style.css', array(), CEQ_VERSION);
        
        // Registers core state machine engines on client canvas
        wp_register_script('ceq-exam-engine', CEQ_URL . 'public/js/quiz-engine.js', array('jquery'), CEQ_VERSION, true);

        // Standard PDF rendering support inside examinations
        wp_register_script('ceq-jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);
    }

    /**
     * Renders CSS/HTML frameworks + initiates JS engines upon loading shortcode.
     */
    public function render_quiz_portal_shortcode($atts) {
        $args = shortcode_atts(array(
            'id' => 0
        ), $atts);

        $quiz_id = intval($args['id']);
        if (!$quiz_id) {
            return '<div style="color:red; font-weight:700;">' . esc_html__('Error: Competitive Exam Quiz ID is missing.', 'competitive-exam-quiz') . '</div>';
        }

        global $ceq_db;
        $quiz = $ceq_db->get_quiz($quiz_id);
        if (!$quiz) {
            return '<div style="color:red;">' . esc_html__('Error: Quiz instance has been removed.', 'competitive-exam-quiz') . '</div>';
        }

        // Force Enqueueing assets safely
        wp_enqueue_style('ceq-exam-style');
        wp_enqueue_script('ceq-jspdf');
        wp_enqueue_script('ceq-exam-engine');

        // Secure state vectors
        wp_localize_script('ceq-exam-engine', 'CEQ_Exam_Context', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('ceq-security-nonce'),
            'quiz_id'  => $quiz_id
        ));

        // Start returning buffering stream layouts
        ob_start();
        ?>
        <!-- Anchor portal selector tags -->
        <div id="ceq-exam-portal-container" class="ceq-container-reset" data-quiz-id="<?php echo $quiz_id; ?>" data-starts-at="<?php echo esc_attr($quiz['starts_at'] ?? ''); ?>">
            
            <!-- VIEW 1: Candidate Sign-in & Instructions Panel -->
            <div id="ceq-welcome-screen" class="ceq-card">
                <div class="ceq-header-bar">
                    <img src="<?php echo esc_url(CEQ_URL . 'public/images/exam-logo.png'); ?>" alt="Exam Logo" class="ceq-portal-logo" onerror="this.style.display='none';" />
                    <h2><?php echo esc_html($quiz['title']); ?> - Online Computer Based Test (CBT)</h2>
                </div>

                <div class="ceq-welcome-grid">
                    <div class="ceq-inst-box">
                        <h3>General Exam Instructions</h3>
                        <p><strong>Please read the following instructions carefully before starting:</strong></p>
                        <ol>
                            <li>Total duration of this mock exam is <strong><?php echo intval($quiz['duration_mins']); ?> Minutes</strong>.</li>
                            <li>The clock will be set at the server. The countdown timer on the top right-hand side of screen will display the remaining time available for you to complete the examination.</li>
                            <li>Each correct response awards <span class="text-success">+<?php echo floatval($quiz['positive_marks']); ?></span> marks.</li>
                            <li>Unanswered questions will not be penalized, whereas incorrect selections deduct <span class="text-fail">-<?php echo floatval($quiz['negative_marks']); ?></span> marks dynamically.</li>
                            <?php 
                            $sec_rules = array();
                            if (!empty($quiz['section_settings'])) {
                                $sec_rules = json_decode($quiz['section_settings'], true);
                            }
                            if (is_array($sec_rules) && !empty($sec_rules)): 
                            ?>
                                <li style="margin-top: 10px; margin-bottom: 10px;">
                                    <strong>Section-Specific / Varied Marking Scheme:</strong>
                                    <div style="margin-top: 6px; margin-bottom: 6px; overflow-x: auto; background: #fff; border: 1px solid #ddd; border-radius: 4px; padding: 2px;">
                                        <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 11px; line-height: 1.4;">
                                            <thead>
                                                <tr style="background: #f7f9fa; border-bottom: 1px solid #ddd;">
                                                    <th style="padding: 6px 10px; font-weight: bold; color: #1e293b;">Section Name</th>
                                                    <th style="padding: 6px 10px; font-weight: bold; color: #15803d; text-align: center;">Correct (+) Marks</th>
                                                    <th style="padding: 6px 10px; font-weight: bold; color: #b91c1c; text-align: center;">Wrong (-) Penalty</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($sec_rules as $sec_name => $vals): 
                                                    $pos_m = (isset($vals['positive_marks']) && $vals['positive_marks'] !== '') ? floatval($vals['positive_marks']) : floatval($quiz['positive_marks']);
                                                    $neg_m = (isset($vals['negative_marks']) && $vals['negative_marks'] !== '') ? floatval($vals['negative_marks']) : floatval($quiz['negative_marks']);
                                                ?>
                                                    <tr style="border-bottom: 1px solid #eee;">
                                                        <td style="padding: 6px 10px; font-weight: 600; color: #334155;"><?php echo esc_html($sec_name); ?></td>
                                                        <td style="padding: 6px 10px; text-align: center; font-weight: 700; color: #15803d; font-family: monospace;">+<?php echo $pos_m; ?></td>
                                                        <td style="padding: 6px 10px; text-align: center; font-weight: 700; color: #b91c1c; font-family: monospace;">-<?php echo $neg_m; ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </li>
                            <?php endif; ?>
                            <li><strong>Anti-Cheat Shield Active:</strong> Do not navigate outside the fullscreen test window. Minimizing, switching tabs, or resizing the viewport triggers an instant warning strike. The test will auto-submit after 3 persistent violations.</li>
                        </ol>
                    </div>

                    <div class="ceq-sign-in-box">
                        <!-- Scheduled countdown banner -->
                        <div id="ceq-scheduled-banner" class="ceq-hidden" style="margin-bottom: 20px; padding: 15px; background: #f9fafb; border: 2px solid #3b82f6; border-radius: 8px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                            <span style="font-weight: 800; color: #1d4ed8; display: block; font-size: 14px; text-transform: uppercase;">🕒 Scheduled Examination Portal</span>
                            <span id="ceq-scheduled-target-time" style="font-size: 12px; color: #4b5563; font-weight: 600; display: block; margin-top: 4px;">Loading target schedule...</span>
                            <div id="ceq-scheduled-countdown" style="margin-top: 10px; font-family: 'JetBrains Mono', monospace; font-size: 22px; font-weight: 800; color: #1e40af; background: #eff6ff; border: 1px solid #bfdbfe; padding: 8px; border-radius: 6px; letter-spacing: 1px;">00:00:00</div>
                        </div>

                        <h3>Candidate Entry Details</h3>
                        <div class="ceq-form-group">
                            <label for="ceq-candidate-name">Full Name *</label>
                            <input type="text" id="ceq-candidate-name" required placeholder="Enter candidate's legal name..." />
                        </div>
                        <div class="ceq-form-group">
                            <label for="ceq-candidate-father-name">Father's Name *</label>
                            <input type="text" id="ceq-candidate-father-name" required placeholder="Enter candidate's father name..." />
                        </div>
                        <div class="ceq-form-group">
                            <label for="ceq-candidate-phone">Mobile Number *</label>
                            <input type="tel" id="ceq-candidate-phone" required placeholder="e.g. +91 98765 43210..." />
                        </div>
                        <div class="ceq-form-group">
                            <label for="ceq-candidate-email">Email Address *</label>
                            <input type="email" id="ceq-candidate-email" required placeholder="email@address.com..." />
                        </div>
                        <div class="ceq-form-group">
                            <label for="ceq-default-lang">Exam Language</label>
                            <select id="ceq-default-lang">
                                <option value="EN">English</option>
                                <option value="HI">Hindi / हिंदी</option>
                            </select>
                        </div>
                        <button id="ceq-btn-start-exam" class="ceq-btn ceq-btn-primary">Acknowledge & Start Test</button>
                    </div>
                </div>
            </div>

            <!-- VIEW 2: The Core NTA CBT Interface Panel -->
            <div id="ceq-exam-workspace" class="ceq-hidden">
                <div class="ceq-workspace-header">
                    <div class="ceq-quiz-meta">
                        <h2><?php echo esc_html($quiz['title']); ?></h2>
                        <span class="ceq-tag-live">● Assessment Live</span>
                    </div>
                    <div class="ceq-timer-block">
                        <span class="ceq-timer-label">Time Remaining:</span>
                        <div id="ceq-countdown-timer">00:00:00</div>
                    </div>
                </div>

                <!-- Category headings -->
                <div class="ceq-sections-nav" id="ceq-sections-bar">
                    <!-- Loaded dynamically via javascript engine -->
                </div>

                <div class="ceq-grid-workspace">
                    <!-- Left side: Question display layout -->
                    <div class="ceq-left-column">
                        <div class="ceq-question-card">
                            <div class="ceq-q-header">
                                <span id="ceq-question-number-badge">Question No. 1</span>
                                <div class="ceq-marking-tags">
                                    <span class="ceq-pos-badge">+<?php echo floatval($quiz['positive_marks']); ?></span>
                                    <span class="ceq-neg-badge">-<?php echo floatval($quiz['negative_marks']); ?></span>
                                </div>
                            </div>
                            
                            <div class="ceq-q-body-container" id="ceq-question-body-viewport">
                                <!-- Question text injected via JS -->
                            </div>

                            <div class="ceq-options-list" id="ceq-options-viewport">
                                <!-- Option tags injected via JS -->
                            </div>
                        </div>

                        <!-- CTA Controls -->
                        <div class="ceq-workspace-footer">
                            <div class="ceq-footer-left">
                                <button id="ceq-btn-mark-review" class="ceq-btn ceq-btn-warning">Mark for Review & Next</button>
                                <button id="ceq-btn-clear-response" class="ceq-btn ceq-btn-secondary">Clear Response</button>
                            </div>
                            <div class="ceq-footer-right">
                                <button id="ceq-btn-save-next" class="ceq-btn ceq-btn-success">Save & Next</button>
                            </div>
                        </div>
                    </div>

                    <!-- Right side: Question Palettes -->
                    <div class="ceq-right-column">
                        <div class="ceq-candidate-info-strip">
                            <div class="ceq-avatar-mock">👤</div>
                            <div>
                                <h4 id="ceq-live-cand-name">Candidate Name</h4>
                                <small>Subject Code: <span id="ceq-live-subject-code"><?php echo esc_html(!empty($quiz['subject_code']) ? $quiz['subject_code'] : __('N/A', 'competitive-exam-quiz')); ?></span></small>
                            </div>
                        </div>

                        <!-- Color code index -->
                        <div class="ceq-palette-legend">
                            <div class="ceq-legend-item"><span class="legend-box item-not-visited">0</span> Not Visited</div>
                            <div class="ceq-legend-item"><span class="legend-box item-not-answered">0</span> Not Answered</div>
                            <div class="ceq-legend-item"><span class="legend-box item-answered">0</span> Answered</div>
                            <div class="ceq-legend-item"><span class="legend-box item-marked">0</span> Marked for Review</div>
                            <div class="ceq-legend-item"><span class="legend-box item-answered-marked">0</span> Ans & Marked</div>
                        </div>

                        <div class="ceq-palette-container">
                            <h3>Question Palette</h3>
                            <div class="ceq-palette-buttons-grid" id="ceq-palette-grid">
                                <!-- Dynamic grid items filled via Javascript -->
                            </div>
                        </div>

                        <div class="ceq-palette-submit-panel">
                            <button id="ceq-btn-final-submit" class="ceq-btn ceq-btn-blue w-100">Submit Examination</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- VIEW 3: Instant Report Card & Rank lists -->
            <div id="ceq-results-screen" class="ceq-card ceq-hidden">
                <div class="ceq-success-icon-banner">🎉 EXAMINATION SUBMITTED SUCCESSFULLY 🎉</div>
                
                <h2 class="text-center" style="margin: 15px 0;">Performance Analytical Report Card</h2>
                <div class="ceq-candidate-summary-banner">
                    <div>Candidate Name: <strong id="ceq-report-name">John Doe</strong></div>
                    <div>Final Grade Status: <strong id="ceq-report-grading">-</strong></div>
                </div>

                <div class="ceq-score-metrics-grid">
                    <div class="metric-block bg-score-tot">
                        <small>Total Marks Scored</small>
                        <h2 id="ceq-metric-score">0.0</h2>
                    </div>
                    <div class="metric-block bg-score-correct">
                        <small>Correct Solved</small>
                        <h2 id="ceq-metric-correct">0</h2>
                    </div>
                    <div class="metric-block bg-score-incorrect">
                        <small>Incorrect Errors</small>
                        <h2 id="ceq-metric-incorrect">0</h2>
                    </div>
                    <div class="metric-block bg-score-unanswered">
                        <small>Left Unanswered</small>
                        <h2 id="ceq-metric-unanswered">0</h2>
                    </div>
                </div>

                <div class="ceq-download-action-bar">
                    <button id="ceq-btn-download-pdf" class="ceq-btn ceq-btn-success shadow">📥 Download PDF Certificate</button>
                </div>

                <!-- See Result Analysis Button -->
                <div style="text-align: center; margin: 25px 0 15px 0;">
                    <button id="ceq-btn-toggle-solutions" class="ceq-btn ceq-btn-blue shadow" style="font-weight: 700; padding: 12px 24px; font-size: 14px;">🔍 See Result Analysis</button>
                </div>

                <!-- Live Dynamic Incorrect/Wrong Answer and Solution Review Segment -->
                <div id="ceq-explanations-review-container" class="ceq-hidden" style="margin: 30px 0; padding: 25px; background: #ffffff; border: 1px solid #e1e7ec; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                    <h3 style="border-bottom: 2px solid #2B6CB0; padding-bottom: 8px; color: #1A365D; margin-top: 0; font-weight: 700; font-size: 18px;">Question Review, Answer Keys & Explanations</h3>
                    <div id="ceq-explanations-review-list" style="margin-top: 20px;">
                        <!-- Injected via JavaScript upon submit validation -->
                    </div>
                </div>

                <h3 style="border-bottom:2px solid #e1e1e1; padding-bottom:6px; margin-top:30px;">Meritorious Performance Highscore Leaders</h3>
                <div style="overflow-x: auto; width: 100%; -webkit-overflow-scrolling: touch; margin-top: 15px; border-radius: 6px; border: 1px solid #e2e8f0;">
                    <table class="ceq-table" id="ceq-leaderboard-table" style="min-width: 600px; width: 100%; margin-top: 0;">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Candidate Identifier</th>
                                <th>Points Secured</th>
                                <th>Assessment Timing</th>
                                <th>Anti-Cheat Warnings</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Dynamically fetched via wp admin logs during execution -->
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Renders the Results Checker Shortcode on any page.
     * Offers a clean search field where candidate inputs their registered mobile number
     * and fetches scored certificates, sections, warnings, and PDF downloads securely.
     */
    public function render_online_test_results_shortcode($atts) {
        wp_enqueue_style('ceq-exam-style');
        wp_enqueue_script('ceq-jspdf');
        wp_enqueue_script('ceq-exam-engine');

        wp_localize_script('ceq-exam-engine', 'CEQ_Exam_Context', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('ceq-security-nonce'),
            'quiz_id'  => 0
        ));

        ob_start();
        ?>
        <div id="ceq-results-checker-container" class="ceq-container-reset">
            <div class="ceq-card" style="max-width: 650px; margin: 30px auto; padding: 25px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1); border-radius: 12px; border: 1px solid #e2e8f0; background: #fff;">
                <div class="ceq-results-checker-header" style="text-align: center; margin-bottom: 25px; display: flex; flex-direction: column; align-items: center; gap: 8px;">
                    <h2 style="margin: 0; font-size: 22px; font-weight: 800; color: #1a365d; font-family: sans-serif; tracking-tight: -0.5px;">Check Online Test Results</h2>
                    <p style="margin: 0; font-size: 13px; color: #4a5568; font-weight: 500; font-family: sans-serif; max-width: 500px; line-height: 1.5;">Enter the exact mobile number you used at the time of your exam below to lookup grades and scoreboard rankings.</p>
                </div>

                <div class="ceq-results-search-form" style="display: flex; flex-direction: column; gap: 15px; margin-bottom: 25px; width: 100%;">
                    <div style="width: 100%;">
                        <input type="tel" id="ceq-search-phone" placeholder="Enter your registered mobile number..." style="width: 100%; padding: 12px 16px; border: 1.5px solid #cbd5e1; border-radius: 8px; font-size: 14.5px; box-sizing: border-box; outline: none; transition: all 0.2s; font-family: monospace;" />
                    </div>
                    <div style="width: 100%;">
                        <button id="ceq-btn-search-results" class="ceq-btn ceq-btn-primary" style="width: 100%; padding: 13px 28px; font-weight: 800; border-radius: 8px; cursor: pointer; white-space: nowrap; font-size: 14.5px; text-transform: uppercase; letter-spacing: 0.5px; transition: all 0.15s; background: #3182ce; color: #ffffff; border: none;">🔍 Check Results</button>
                    </div>
                </div>

                <div id="ceq-search-error" style="color: #c53030; background: #fff5f5; border: 1.5px solid #fed7d7; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; display: none; font-weight: 700; font-family: sans-serif;"></div>

                <div id="ceq-search-results-viewport">
                    <div style="text-align: center; color: #a0aec0; padding: 40px 10px; font-style: italic; font-size: 13px; font-family: sans-serif; border: 1px dashed #e2e8f0; border-radius: 8px;">
                        No searches initiated yet. Please enter your mobile number above to fetch official performance grades.
                    </div>
                </div>
            </div>
        </div>
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
        <?php
        return ob_get_clean();
    }
}
