=== Competitive Exam Quiz System ===
Contributors: Expert WordPress Developer
Tags: quiz, competitive exam, exam system, cbt, NTA, SSC, timer, leaderboard, anti-cheat, live assessment
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

A production-ready NTA/SSC style live CBT (Computer Based Test) online assessment portal simulation for WordPress. Incorporates live countdown timers, question section sheets, candidate dashboards, active anti-cheat shielding, CSV question import, public leaderboards, and client-side PDF certificate printing.

== Description ==

Competitive Exam Quiz System is a premium, powerful assessment framework for WordPress designed specifically to build mock portals mapping National Testing Agency (NTA), Union Public Service Commission (UPSC), and Staff Selection Commission (SSC) CBT formats.

= Key Features =
* **Fullscreen CBT Overlay Mode**: Blocks external distracting layout wrappers to create immersive test environments.
* **Double-Marking Schema Support**: Positive & Negative marks per question customizable at Admin dashboard.
* **Smart Section Navigation Tab Bar**: Seamless click routing across categories.
* **Interactive 5-State Color Palette Grid**: Track visited, answered, flagged, and review statuses easily.
* **Anti-Cheat Shield**: Constantly monitors tab-switching, active window blurs, and triggers warning alerts (auto-submits on 3 warnings).
* **CSV Batch Import Utility**: Upload hundreds of items from Excel sheets instantly.
* **PDF Exporter Tool**: Allow verified candidates to preserve results locally as highscores certs.

== Installation ==

1. Upload the `competitive-exam-quiz` zip folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Access the custom menu "Exam Quiz System" to build a test.
4. Insert shortcode `[competitive_quiz id="YOUR_QUIZ_ID"]` inside any post or page.

== Frequently Asked Questions ==

= Can players take multiple tests? =
Yes! Submissions are recorded distinctly in separate tables mapped dynamically to the candidate name and emails.

= Does negative marking support decimal inputs? =
Yes! Both positive and negative marks support accurate floating margins (e.g. +2.0 and -0.5).
