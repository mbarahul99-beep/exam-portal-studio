<?php
/**
 * Class CEQ_Quiz_Ajax
 * Controls AJAX communications and secure endpoint operations.
 */

if (!defined('ABSPATH')) {
    exit;
}

class CEQ_Quiz_Ajax {

    public function __construct() {
        // Enqueue AJAX events for logged-in and guest users
        add_action('wp_ajax_ceq_fetch_quiz_data', array($this, 'fetch_quiz_data'));
        add_action('wp_ajax_nopriv_ceq_fetch_quiz_data', array($this, 'fetch_quiz_data'));

        add_action('wp_ajax_ceq_submit_quiz_answers', array($this, 'submit_quiz_answers'));
        add_action('wp_ajax_nopriv_ceq_submit_quiz_answers', array($this, 'submit_quiz_answers'));
        
        add_action('wp_ajax_ceq_load_leaderboard', array($this, 'load_leaderboard'));
        add_action('wp_ajax_nopriv_ceq_load_leaderboard', array($this, 'load_leaderboard'));

        add_action('wp_ajax_ceq_check_online_results', array($this, 'check_online_results'));
        add_action('wp_ajax_nopriv_ceq_check_online_results', array($this, 'check_online_results'));

        add_action('wp_ajax_ceq_fetch_quiz_solutions', array($this, 'fetch_quiz_solutions'));
        add_action('wp_ajax_nopriv_ceq_fetch_quiz_solutions', array($this, 'fetch_quiz_solutions'));
    }

    /**
     * Secures and fetches comprehensive quiz structure
     */
    public function fetch_quiz_data() {
        check_ajax_referer('ceq-security-nonce', 'security');

        $quiz_id = isset($_POST['quiz_id']) ? intval($_POST['quiz_id']) : 0;
        if (!$quiz_id) {
            wp_send_json_error(array('message' => __('Invalid Quiz ID selected.', 'competitive-exam-quiz')));
        }

        global $ceq_db;
        $quiz = $ceq_db->get_quiz($quiz_id);
        if (!$quiz) {
            wp_send_json_error(array('message' => __('Requested Quiz does not exist.', 'competitive-exam-quiz')));
        }

        // Active Pre-registration CSV Phone validation checklist
        if (isset($quiz['restrict_by_phone']) && intval($quiz['restrict_by_phone']) === 1) {
            $entered_phone = isset($_POST['candidate_phone']) ? sanitize_text_field($_POST['candidate_phone']) : '';
            if (empty($entered_phone)) {
                wp_send_json_error(array('message' => __('A registered Mobile Number is strictly required to participate in this exam.', 'competitive-exam-quiz')));
            }

            $clean_entered = preg_replace('/\D/', '', $entered_phone);
            
            // 1. Verify that the mobile number is registered
            $allowed_string = isset($quiz['allowed_phones']) ? $quiz['allowed_phones'] : '';
            $allowed_array = array_map(function($p) {
                return preg_replace('/\D/', '', $p);
            }, explode(',', $allowed_string));
            $allowed_array = array_filter($allowed_array); // clear blanks

            if (!in_array($clean_entered, $allowed_array)) {
                wp_send_json_error(array('message' => __('Your mobile number is not pre-registered for this examination. Please contact the administrator.', 'competitive-exam-quiz')));
            }

            // 2. Verify that they have not completed the exam already
            global $wpdb;
            $table_results = $wpdb->prefix . 'ceq_results';
            $existing_phones = $wpdb->get_col($wpdb->prepare("SELECT candidate_phone FROM $table_results WHERE quiz_id = %d", $quiz_id));
            if (!empty($existing_phones)) {
                foreach ($existing_phones as $res_phone) {
                    if (preg_replace('/\D/', '', $res_phone) === $clean_entered) {
                        wp_send_json_error(array('message' => __('You have already submitted or completed this examination using this mobile number.', 'competitive-exam-quiz')));
                    }
                }
            }
        }

        $questions_raw = $ceq_db->get_questions($quiz_id);
        $questions = array();

        // Standardize response to maintain front-end security (do not pass correct answer immediately on general render)
        foreach ($questions_raw as $q) {
            $questions[] = array(
                'id'             => intval($q['id']),
                'section_name'   => sanitize_text_field($q['section_name']),
                'question_text'  => wp_kses_post($q['question_text']),
                'options'        => $q['options'], // Decoded JSON array
                'positive_marks' => $q['positive_marks'],
                'negative_marks' => $q['negative_marks'],
                'question_image' => isset($q['question_image']) ? $q['question_image'] : '',
                'option_images'  => isset($q['option_images']) ? $q['option_images'] : array('', '', '', '')
            );
        }

        wp_send_json_success(array(
            'quiz'      => $quiz,
            'questions' => $questions
        ));
    }

    /**
     * Submits the client exam responses, computes negative/positive markings, and stores results
     */
    public function submit_quiz_answers() {
        check_ajax_referer('ceq-security-nonce', 'security');

        $quiz_id        = isset($_POST['quiz_id']) ? intval($_POST['quiz_id']) : 0;
        $candidate_name  = isset($_POST['candidate_name']) ? sanitize_text_field($_POST['candidate_name']) : '';
        $candidate_father_name = isset($_POST['candidate_father_name']) ? sanitize_text_field($_POST['candidate_father_name']) : '';
        $candidate_email = isset($_POST['candidate_email']) ? sanitize_email($_POST['candidate_email']) : '';
        $candidate_phone = isset($_POST['candidate_phone']) ? sanitize_text_field($_POST['candidate_phone']) : '';
        $user_answers    = isset($_POST['answers']) ? json_decode(stripslashes($_POST['answers']), true) : array();
        $time_taken      = isset($_POST['time_taken']) ? intval($_POST['time_taken']) : 0;
        $cheat_alerts    = isset($_POST['cheat_alerts']) ? intval($_POST['cheat_alerts']) : 0;
        $cheat_incidents = isset($_POST['cheat_incidents']) ? json_decode(stripslashes($_POST['cheat_incidents']), true) : array();

        if (empty($candidate_name)) {
            wp_send_json_error(array('message' => __('Please enter a valid Candidate Name to submit.', 'competitive-exam-quiz')));
        }
        if (empty($candidate_phone)) {
            wp_send_json_error(array('message' => __('Please enter a valid Mobile Number to submit.', 'competitive-exam-quiz')));
        }

        global $ceq_db;
        $quiz = $ceq_db->get_quiz($quiz_id);
        if (!$quiz) {
            wp_send_json_error(array('message' => __('Quiz context not found.', 'competitive-exam-quiz')));
        }

        // Active Pre-registration CSV Phone validation on submission
        if (isset($quiz['restrict_by_phone']) && intval($quiz['restrict_by_phone']) === 1) {
            $clean_entered = preg_replace('/\D/', '', $candidate_phone);
            
            // 1. Verify that the mobile number is registered
            $allowed_string = isset($quiz['allowed_phones']) ? $quiz['allowed_phones'] : '';
            $allowed_array = array_map(function($p) {
                return preg_replace('/\D/', '', $p);
            }, explode(',', $allowed_string));
            $allowed_array = array_filter($allowed_array); // clear blanks

            if (!in_array($clean_entered, $allowed_array)) {
                wp_send_json_error(array('message' => __('Aborted: Your mobile number is not pre-registered for this examination.', 'competitive-exam-quiz')));
            }

            // 2. Verify that they have not completed the exam already
            global $wpdb;
            $table_results = $wpdb->prefix . 'ceq_results';
            $existing_phones = $wpdb->get_col($wpdb->prepare("SELECT candidate_phone FROM $table_results WHERE quiz_id = %d", $quiz_id));
            if (!empty($existing_phones)) {
                foreach ($existing_phones as $res_phone) {
                    if (preg_replace('/\D/', '', $res_phone) === $clean_entered) {
                        wp_send_json_error(array('message' => __('Aborted: You have already submitted or completed this examination using this mobile number.', 'competitive-exam-quiz')));
                    }
                }
            }
        }

        // Fetch master questions database mapping to compute real score server-side (Preventing client tampering)
        global $wpdb;
        $table_questions = $wpdb->prefix . 'ceq_questions';
        $questions_db = $wpdb->get_results($wpdb->prepare("SELECT id, section_name, correct_option_index, options, positive_marks, negative_marks FROM $table_questions WHERE quiz_id = %d", $quiz_id), ARRAY_A);

        $total_score = 0;
        $correct_count = 0;
        $incorrect_count = 0;
        $unanswered_count = 0;

        $pos_marks = floatval($quiz['positive_marks']);
        $neg_marks = floatval($quiz['negative_marks']);

        $section_settings_raw = isset($quiz['section_settings']) ? $quiz['section_settings'] : '';
        $section_settings = array();
        if (!empty($section_settings_raw)) {
            $section_settings = json_decode($section_settings_raw, true);
            if (!is_array($section_settings)) {
                $section_settings = array();
            }
        }

        $section_metrics = array();

        // Calculate grades
        foreach ($questions_db as $q) {
            $q_id = intval($q['id']);
            $sec = sanitize_text_field($q['section_name']);
            
            if (!isset($section_metrics[$sec])) {
                $section_metrics[$sec] = array(
                    'score'      => 0,
                    'correct'    => 0,
                    'incorrect'  => 0,
                    'unanswered' => 0
                );
            }

            // Calculate dynamic question/section wise marks
            $q_pos = $pos_marks;
            $q_neg = $neg_marks;

            // 1. Check section level setting override
            if (isset($section_settings[$sec])) {
                if (isset($section_settings[$sec]['positive_marks'])) {
                    $q_pos = floatval($section_settings[$sec]['positive_marks']);
                }
                if (isset($section_settings[$sec]['negative_marks'])) {
                    $q_neg = floatval($section_settings[$sec]['negative_marks']);
                }
            }

            // 2. Check question level override
            if (isset($q['positive_marks']) && $q['positive_marks'] !== null && $q['positive_marks'] !== '') {
                $q_pos = floatval($q['positive_marks']);
            }
            if (isset($q['negative_marks']) && $q['negative_marks'] !== null && $q['negative_marks'] !== '') {
                $q_neg = floatval($q['negative_marks']);
            }

            if (!isset($user_answers[$q_id]) || $user_answers[$q_id] === '' || $user_answers[$q_id] === null) {
                $section_metrics[$sec]['unanswered']++;
                $unanswered_count++;
            } else {
                $selected_idx = intval($user_answers[$q_id]);
                $correct_idx  = intval($q['correct_option_index']);

                if ($selected_idx === $correct_idx) {
                    $section_metrics[$sec]['score'] += $q_pos;
                    $section_metrics[$sec]['correct']++;
                    $total_score += $q_pos;
                    $correct_count++;
                } else {
                    $section_metrics[$sec]['score'] -= $q_neg;
                    $section_metrics[$sec]['incorrect']++;
                    $total_score -= $q_neg;
                    $incorrect_count++;
                }
            }
        }

        // Store result pack in custom tables
        $result_payload = array(
            'quiz_id'               => $quiz_id,
            'candidate_name'        => $candidate_name,
            'candidate_father_name' => $candidate_father_name,
            'candidate_email'       => $candidate_email,
            'candidate_phone'       => $candidate_phone,
            'score'                 => $total_score,
            'answers'               => $user_answers,
            'time_taken_seconds'    => $time_taken,
            'cheating_incidents'    => $cheat_incidents,
            'cheating_alerts_count' => $cheat_alerts,
            'section_scores'        => $section_metrics,
        );

        $inserted_id = $ceq_db->save_result($result_payload);

        if ($inserted_id) {
            // Fetch questions with correct answers and explanations for candidate review screen
            $questions_full = $wpdb->get_results($wpdb->prepare(
                "SELECT id, section_name, question_text, options, correct_option_index, explanation, question_image, option_images 
                 FROM $table_questions 
                 WHERE quiz_id = %d 
                 ORDER BY id ASC", 
                $quiz_id
            ), ARRAY_A);

            foreach ($questions_full as &$q) {
                $q['options'] = json_decode($q['options'], true);
                if (!empty($q['option_images'])) {
                    $q['option_images'] = json_decode($q['option_images'], true);
                } else {
                    $q['option_images'] = array("", "", "", "");
                }
            }

            $total_possible_marks = $ceq_db->get_quiz_total_marks($quiz_id);
            $passing_percentage = floatval($quiz['passing_score'] ?? 33.0);
            $required_score_to_pass = ($passing_percentage / 100.0) * $total_possible_marks;
            $has_passed = ($total_score >= $required_score_to_pass);

            wp_send_json_success(array(
                'result_id'         => $inserted_id,
                'total_score'       => floatval($total_score),
                'correct_count'     => $correct_count,
                'incorrect_count'   => $incorrect_count,
                'unanswered'        => $unanswered_count,
                'section_scores'    => $section_metrics,
                'candidate_name'    => $candidate_name,
                'candidate_father_name' => $candidate_father_name,
                'passing_score'     => $required_score_to_pass, // sending the actual calculated score needed to pass
                'passing_percentage'=> $passing_percentage,
                'has_passed'        => $has_passed,
                'questions_review'  => $questions_full,
                'user_answers'      => $user_answers,
                'message'           => __('Exam completed successfully!', 'competitive-exam-quiz')
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to insert exam submission records.', 'competitive-exam-quiz')));
        }
    }

    /**
     * Fetch real-time public leaderboard ranking log
     */
    public function load_leaderboard() {
        $quiz_id = isset($_POST['quiz_id']) ? intval($_POST['quiz_id']) : 0;
        if (!$quiz_id) {
            wp_send_json_error(array('message' => __('Quiz ID cannot be zero.', 'competitive-exam-quiz')));
        }

        global $ceq_db;
        $board = $ceq_db->get_leaderboard($quiz_id, 30);
        wp_send_json_success($board);
    }

    /**
     * Checks online test results using candidate phone number lookup
     */
    public function check_online_results() {
        check_ajax_referer('ceq-security-nonce', 'security');

        $phone = isset($_POST['candidate_phone']) ? sanitize_text_field($_POST['candidate_phone']) : '';
        if (empty($phone)) {
            wp_send_json_error(array('message' => __('Please enter your registered mobile number.', 'competitive-exam-quiz')));
        }

        global $ceq_db;
        $results = $ceq_db->get_results_by_phone($phone);

        if (empty($results)) {
            wp_send_json_error(array('message' => __('No examination records found for the entered mobile number.', 'competitive-exam-quiz')));
        }

        wp_send_json_success($results);
    }

    /**
     * Fetch questions along with correct answers and explanations for scorecard solutions review.
     */
    public function fetch_quiz_solutions() {
        check_ajax_referer('ceq-security-nonce', 'security');

        $quiz_id = isset($_POST['quiz_id']) ? intval($_POST['quiz_id']) : 0;
        if (!$quiz_id) {
            wp_send_json_error(array('message' => __('Invalid Quiz ID.', 'competitive-exam-quiz')));
        }

        global $wpdb;
        $table_questions = $wpdb->prefix . 'ceq_questions';
        
        $questions = $wpdb->get_results($wpdb->prepare(
            "SELECT id, section_name, question_text, options, correct_option_index, explanation, question_image, option_images 
             FROM $table_questions 
             WHERE quiz_id = %d 
             ORDER BY id ASC", 
            $quiz_id
        ), ARRAY_A);

        foreach ($questions as &$q) {
            $q['options'] = json_decode($q['options'], true);
            if (!empty($q['option_images'])) {
                $q['option_images'] = json_decode($q['option_images'], true);
            } else {
                $q['option_images'] = array("", "", "", "");
            }
        }

        wp_send_json_success(array('questions' => $questions));
    }
}
