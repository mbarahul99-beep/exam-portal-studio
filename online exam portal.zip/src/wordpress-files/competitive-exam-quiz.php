<?php
/**
 * Plugin Name: Competitive Exam Quiz System
 * Plugin URI: https://example.com/competitive-exam-quiz-system
 * Description: A production-ready, professional SSC/NTA style online exam portal simulation for WordPress. Incorporates live countdown timers, a question palette, section-based questions, anti-cheat detection, CSV question importation, public leaderboards, and PDF download keys.
 * Version: 1.1.0
 * Author: Expert WordPress Developer
 * Author URI: https://example.com/
 * License: GPL2 or later
 * Text Domain: competitive-exam-quiz
 * Requires PHP: 8.0
 * Requires at least: 5.8
 */

if (!defined('ABSPATH')) {
    exit; // Prevents direct access
}

// Define plugin-wide paths and constants
define('CEQ_VERSION', '1.1.0');
define('CEQ_PATH', plugin_dir_path(__FILE__));
define('CEQ_URL', plugin_dir_url(__FILE__));
define('CEQ_INC', CEQ_PATH . 'includes/');
define('CEQ_ADMIN', CEQ_PATH . 'admin/');
define('CEQ_PUBLIC', CEQ_PATH . 'public/');

// Core initialization trigger
add_action('plugins_loaded', 'ceq_init_plugin');

function ceq_init_plugin() {
    // Require essential classes
    require_once CEQ_INC . 'class-quiz-db.php';
    require_once CEQ_INC . 'class-quiz-ajax.php';
    require_once CEQ_ADMIN . 'class-quiz-admin.php';
    require_once CEQ_PUBLIC . 'class-quiz-public.php';

    // Instantiate controllers
    global $ceq_db, $ceq_ajax, $ceq_admin, $ceq_public;
    $ceq_db     = new CEQ_Quiz_DB();
    $ceq_ajax   = new CEQ_Quiz_Ajax();
    $ceq_admin  = new CEQ_Quiz_Admin();
    $ceq_public = new CEQ_Quiz_Public();
}

/**
 * DB Provisioning upon Activation
 */
register_activation_hook(__FILE__, 'ceq_activate_plugin');
function ceq_activate_plugin() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Table 1: Quizzes
    $table_quizzes = $wpdb->prefix . 'ceq_quizzes';
    $sql_quizzes = "CREATE TABLE $table_quizzes (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        title varchar(255) NOT NULL,
        subject_code varchar(50) DEFAULT '' NOT NULL,
        duration_mins int(11) DEFAULT 60 NOT NULL,
        passing_score decimal(5,2) DEFAULT 33.00,
        positive_marks decimal(4,2) DEFAULT 2.00,
        negative_marks decimal(4,2) DEFAULT 0.50,
        sections text NOT NULL, -- Comma-separated custom section list
        starts_at varchar(50) DEFAULT '' NOT NULL, -- Scheduled date-time
        status varchar(20) DEFAULT 'published' NOT NULL, -- published or draft
        restrict_by_phone tinyint(1) DEFAULT 0 NOT NULL,
        allowed_phones longtext NOT NULL,
        section_settings longtext NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // Table 2: Questions
    $table_questions = $wpdb->prefix . 'ceq_questions';
    $sql_questions = "CREATE TABLE $table_questions (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        quiz_id bigint(20) NOT NULL,
        section_name varchar(100) NOT NULL,
        question_text text NOT NULL,
        options text NOT NULL, -- JSON serialized string
        correct_option_index tinyint(4) NOT NULL,
        explanation text,
        positive_marks decimal(4,2) DEFAULT NULL,
        negative_marks decimal(4,2) DEFAULT NULL,
        question_image text DEFAULT NULL,
        option_images text DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY quiz_id (quiz_id)
    ) $charset_collate;";

    // Table 3: Active Submissions / Results
    $table_results = $wpdb->prefix . 'ceq_results';
    $sql_results = "CREATE TABLE $table_results (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        quiz_id bigint(20) NOT NULL,
        candidate_name varchar(150) NOT NULL,
        candidate_email varchar(150),
        candidate_phone varchar(50) DEFAULT '' NOT NULL, -- Added to track mobile contacts
        score decimal(6,2) DEFAULT 0.00,
        answers text, -- JSON representation of answers taken
        time_taken_seconds int(11) NOT NULL,
        cheating_incidents text, -- JSON representation of tab switches/flags
        cheating_alerts_count int(11) DEFAULT 0,
        section_scores text, -- JSON representation of sub-scores
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY quiz_id (quiz_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_quizzes);
    dbDelta($sql_questions);
    dbDelta($sql_results);

    // Dynamic schema migration: add option_images column if it does not exist
    $column = $wpdb->get_results("SHOW COLUMNS FROM `$table_questions` LIKE 'option_images'");
    if (empty($column)) {
        $wpdb->query("ALTER TABLE `$table_questions` ADD `option_images` text DEFAULT NULL AFTER `question_image` ");
    }

    // Bootstrap initial sample quiz if database is fully empty
    $count = $wpdb->get_var("SELECT COUNT(*) FROM $table_quizzes");
    if ($count == 0) {
        $default_sections = 'General Intelligence,General Awareness,Quantitative Aptitude,English Language';
        $wpdb->insert($table_quizzes, array(
            'title' => 'SSC General Mock Exam',
            'duration_mins' => 15,
            'passing_score' => 40.00,
            'positive_marks' => 2.00,
            'negative_marks' => 0.50,
            'sections' => $default_sections
        ));
        $quiz_id = $wpdb->insert_id;

        $questions = array(
            array(
                'quiz_id' => $quiz_id,
                'section_name' => 'General Intelligence',
                'question_text' => 'In a certain code, TEACHER is written as VGCEJGT. How is CHILDREN written in that code?',
                'options' => json_encode(array('EJKNFTGP', 'EJKGFTGP', 'EJKNFTHP', 'EJKGFTGP')),
                'correct_option_index' => 0,
                'explanation' => 'Each letter is shifted 2 places forward.'
            ),
            array(
                'quiz_id' => $quiz_id,
                'section_name' => 'General Awareness',
                'question_text' => 'Which of the following articles of the Indian Constitution is related to the abolition of Untouchability?',
                'options' => json_encode(array('Article 14', 'Article 17', 'Article 19', 'Article 21')),
                'correct_option_index' => 1,
                'explanation' => 'Article 17 of the Constitution of India abolishes the practice of untouchability.'
            ),
            array(
                'quiz_id' => $quiz_id,
                'section_name' => 'Quantitative Aptitude',
                'question_text' => 'The ratio of speed of three cars is 2:3:4. What is the ratio of time taken by them to cover the same distance?',
                'options' => json_encode(array('2:3:4', '4:3:2', '4:3:6', '6:4:3')),
                'correct_option_index' => 3,
                'explanation' => 'Time ratio is reciprocal of speed ratio: 1/2 : 1/3 : 1/4 = 6:4:3.'
            ),
            array(
                'quiz_id' => $quiz_id,
                'section_name' => 'English Language',
                'question_text' => 'Identify the synonym of the word "ABANDON".',
                'options' => json_encode(array('Adopt', 'Forsake', 'Retain', 'Uphold')),
                'correct_option_index' => 1,
                'explanation' => 'To abandon means to leave or desert. Forsake is a direct synonym.'
            )
        );

        foreach ($questions as $q) {
            $wpdb->insert($table_questions, $q);
        }
    }
}

/**
 * Cleanup on Uninstallation
 * Clean only when constant CEQ_UNINSTALL_DELETE is active. (Safe policy)
 */
register_uninstall_hook(__FILE__, 'ceq_uninstall_plugin');
function ceq_uninstall_plugin() {
    if (!defined('WP_UNINSTALL_PLUGIN')) {
        exit;
    }
    // Developers can activate uninstall purge via WP options or wp-config definition
    if (get_option('ceq_purge_data_on_uninstall') === 'yes') {
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . "ceq_results");
        $wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . "ceq_questions");
        $wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . "ceq_quizzes");
        delete_option('ceq_purge_data_on_uninstall');
    }
}
