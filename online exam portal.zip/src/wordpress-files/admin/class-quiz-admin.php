<?php
/**
 * Class CEQ_Quiz_Admin
 * Designs and commands the background administrative views.
 */

if (!defined('ABSPATH')) {
    exit;
}

class CEQ_Quiz_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'register_admin_panel'));
        add_action('admin_init', array($this, 'handle_actions'));
    }

    /**
     * Mount Exam System item on the side navbar of the WP admin control panel
     */
    public function register_admin_panel() {
        add_menu_page(
            __('Exam Quiz System', 'competitive-exam-quiz'),
            __('Exam Quiz System', 'competitive-exam-quiz'),
            'manage_options',
            'competitive-exam-quiz',
            array($this, 'render_dashboard_page'),
            'dashicons-clipboard',
            30
        );

        add_submenu_page(
            'competitive-exam-quiz',
            __('Manage Questions', 'competitive-exam-quiz'),
            __('Manage Questions', 'competitive-exam-quiz'),
            'manage_options',
            'ceq-questions-manager',
            array($this, 'render_questions_page')
        );

        add_submenu_page(
            'competitive-exam-quiz',
            __('Quiz Results & Export', 'competitive-exam-quiz'),
            __('Results & Export', 'competitive-exam-quiz'),
            'manage_options',
            'ceq-results-manager',
            array($this, 'render_results_page')
        );
    }

    /**
     * Action handlers for CSV uploads, exports, and Quiz CRUD operations
     */
    public function handle_actions() {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        // Action: Export Quiz Results
        if (isset($_GET['action']) && $_GET['action'] === 'ceq_export_results') {
            $this->export_results_to_csv();
        }

        // Action: Handle CSV Question Imports
        if (isset($_POST['ceq_import_csv_nonce']) && wp_verify_nonce($_POST['ceq_import_csv_nonce'], 'ceq_import_csv')) {
            $this->import_questions_from_csv();
        }

        // Action: Delete Quiz Action Listener
        if (isset($_GET['action']) && $_GET['action'] === 'ceq_delete_quiz' && isset($_GET['quiz_id']) && isset($_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'ceq_delete_quiz_' . $_GET['quiz_id'])) {
                global $ceq_db;
                $ceq_db->delete_quiz(intval($_GET['quiz_id']));
                wp_redirect(admin_url('admin.php?page=competitive-exam-quiz&deleted=1'));
                exit;
            }
        }

        // Action: Delete Individual Student Result Action Listener
        if (isset($_GET['action']) && $_GET['action'] === 'ceq_delete_result' && isset($_GET['result_id']) && isset($_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'ceq_delete_result_' . $_GET['result_id'])) {
                global $ceq_db;
                $ceq_db->delete_result(intval($_GET['result_id']));
                $qz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;
                wp_redirect(admin_url('admin.php?page=ceq-results-manager&quiz_id=' . $qz_id . '&deleted=1'));
                exit;
            }
        }
    }

    /**
     * Render general configurations and dynamic quiz-building options
     */
    public function render_dashboard_page() {
        global $wpdb, $ceq_db;
        $table = $wpdb->prefix . 'ceq_quizzes';

        // Self-heal check: ensure structures are fully ready before potential insertion
        $columns = $wpdb->get_col("DESCRIBE $table");
        if (!empty($columns)) {
            if (!in_array('subject_code', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `subject_code` varchar(50) DEFAULT '' NOT NULL AFTER `title`");
            }
            if (!in_array('sections', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `sections` text NOT NULL AFTER `negative_marks`");
            }
            if (!in_array('starts_at', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `starts_at` varchar(50) DEFAULT '' NOT NULL AFTER `sections`");
            }
            if (!in_array('status', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `status` varchar(20) DEFAULT 'published' NOT NULL AFTER `starts_at`");
            }
            if (!in_array('restrict_by_phone', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `restrict_by_phone` tinyint(1) DEFAULT 0 NOT NULL AFTER `status`");
            }
            if (!in_array('allowed_phones', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `allowed_phones` longtext NOT NULL AFTER `restrict_by_phone`");
            }
        }

        // Delete alert message
        if (isset($_GET['deleted']) && $_GET['deleted'] == 1) {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Exam Quiz deleted successfully.', 'competitive-exam-quiz') . '</p></div>';
        }

        // Handle Quiz creation or updates
        if (isset($_POST['ceq_save_quiz_nonce']) && wp_verify_nonce($_POST['ceq_save_quiz_nonce'], 'ceq_save_quiz')) {
            $title             = sanitize_text_field($_POST['title']);
            $subject_code      = sanitize_text_field($_POST['subject_code'] ?? '');
            $duration          = intval($_POST['duration_mins']);
            $passing_score     = floatval($_POST['passing_score']);
            $positive_marks    = floatval($_POST['positive_marks']);
            $negative_marks    = floatval($_POST['negative_marks']);
            $sections          = sanitize_text_field($_POST['sections']);
            $starts_at         = sanitize_text_field($_POST['starts_at'] ?? '');
            $status            = sanitize_text_field($_POST['status'] ?? 'published');
            $restrict_by_phone = isset($_POST['restrict_by_phone']) ? 1 : 0;
            $section_settings  = isset($_POST['section_settings']) ? wp_unslash($_POST['section_settings']) : '';

            // Handle Allowed Phones CSV parse if uploaded
            $allowed_phones = '';
            if (isset($_FILES['allowed_phones_csv']) && !empty($_FILES['allowed_phones_csv']['tmp_name'])) {
                $file = $_FILES['allowed_phones_csv']['tmp_name'];
                if (($handle = fopen($file, "r")) !== FALSE) {
                    $phones_array = array();
                    while (($row_data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                        foreach ($row_data as $cell) {
                            $clean_number = preg_replace('/[^\d\+]/', '', $cell);
                            if (strlen($clean_number) >= 8) {
                                $phones_array[] = $clean_number;
                            }
                        }
                    }
                    fclose($handle);
                    if (!empty($phones_array)) {
                        $allowed_phones = implode(',', array_unique($phones_array));
                    }
                }
            }

            // If sections are left completely blank, keep it empty or as entered manually
            if (empty(trim($sections))) {
                $sections = '';
            }

            $edit_id = isset($_POST['edit_id']) ? intval($_POST['edit_id']) : 0;

            if ($edit_id > 0) {
                // Update
                $update_fields = array(
                    'title'             => $title,
                    'subject_code'      => $subject_code,
                    'duration_mins'     => $duration,
                    'passing_score'     => $passing_score,
                    'positive_marks'    => $positive_marks,
                    'negative_marks'    => $negative_marks,
                    'sections'          => $sections,
                    'starts_at'         => $starts_at,
                    'status'            => $status,
                    'restrict_by_phone' => $restrict_by_phone,
                    'section_settings'  => $section_settings
                );
                
                if (!empty($allowed_phones)) {
                    $update_fields['allowed_phones'] = $allowed_phones;
                }

                $result = $wpdb->update($table, $update_fields, array('id' => $edit_id));

                if ($result === false) {
                    echo '<div class="notice notice-error is-dismissible"><p>' . sprintf(__('Failed to update Exam Quiz. DB Error: %s', 'competitive-exam-quiz'), esc_html($wpdb->last_error)) . '</p></div>';
                } else {
                    echo '<div class="notice notice-success is-dismissible"><p>' . __('Exam Quiz properties updated successfully!', 'competitive-exam-quiz') . '</p></div>';
                }
            } else {
                // Insert
                $result = $wpdb->insert($table, array(
                    'title'             => $title,
                    'subject_code'      => $subject_code,
                    'duration_mins'     => $duration,
                    'passing_score'     => $passing_score,
                    'positive_marks'    => $positive_marks,
                    'negative_marks'    => $negative_marks,
                    'sections'          => $sections,
                    'starts_at'         => $starts_at,
                    'status'            => $status,
                    'restrict_by_phone' => $restrict_by_phone,
                    'allowed_phones'    => $allowed_phones,
                    'section_settings'  => $section_settings
                ));

                if ($result === false) {
                    echo '<div class="notice notice-error is-dismissible"><p>' . sprintf(__('Failed to create Exam Quiz. DB Error: %s', 'competitive-exam-quiz'), esc_html($wpdb->last_error)) . '</p></div>';
                } else {
                    echo '<div class="notice notice-success is-dismissible"><p>' . __('New Exam Quiz created successfully!', 'competitive-exam-quiz') . '</p></div>';
                }
            }
        }

        // Check if editing a quiz is requested
        $edit_quiz = null;
        if (isset($_GET['action']) && $_GET['action'] === 'ceq_edit_quiz' && isset($_GET['quiz_id'])) {
            $edit_quiz = $ceq_db->get_quiz(intval($_GET['quiz_id']));
        }

        $quizzes = $ceq_db->get_quizzes();
        ?>
        <div class="wrap" style="background: #fdfdfd; padding: 20px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h1 style="font-weight: 700; color: #1d2327; margin-bottom: 20px;">Competitive Exam Quiz System Dashboard</h1>
            <p style="color: #646970; font-size: 14px;">Use Shortcode <code>[competitive_quiz id="QUIZ_ID"]</code> on any page or post to render the exam portal on your front-end theme.</p>
            
            <hr style="border: 0; border-top: 1px solid #dcdcde; margin: 20px 0;" />

            <div style="display: flex; gap: 24px; flex-wrap: wrap;">
                <!-- Quiz creator panel / editor panel -->
                <div style="flex: 1; min-width: 320px; background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                    <?php if ($edit_quiz): ?>
                        <h2 style="font-weight: 600; font-size: 16px; margin-top: 0; color: #1a73e8;"><?php _e('Edit Exam Instance', 'competitive-exam-quiz'); ?> (ID: <?php echo intval($edit_quiz['id']); ?>)</h2>
                    <?php else: ?>
                        <h2 style="font-weight: 600; font-size: 16px; margin-top: 0;"><?php _e('Create Online Exam/Test', 'competitive-exam-quiz'); ?></h2>
                    <?php endif; ?>

                    <form method="post" enctype="multipart/form-data" action="<?php echo admin_url('admin.php?page=competitive-exam-quiz'); ?>">
                        <?php wp_nonce_field('ceq_save_quiz', 'ceq_save_quiz_nonce'); ?>
                        
                        <?php if ($edit_quiz): ?>
                            <input type="hidden" name="edit_id" value="<?php echo intval($edit_quiz['id']); ?>" />
                        <?php endif; ?>

                        <table class="form-table" style="max-width: 100%;">
                            <tr>
                                <th scope="row"><label><?php _e('Exam Title', 'competitive-exam-quiz'); ?></label></th>
                                <td><input type="text" name="title" required class="regular-text" placeholder="e.g. Combined Graduate Level (CGL) Tier-I" value="<?php echo $edit_quiz ? esc_attr($edit_quiz['title']) : ''; ?>" /></td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Subject Code', 'competitive-exam-quiz'); ?></label></th>
                                <td><input type="text" name="subject_code" class="regular-text" placeholder="e.g. CS-101, SSC-CGL" value="<?php echo $edit_quiz && isset($edit_quiz['subject_code']) ? esc_attr($edit_quiz['subject_code']) : ''; ?>" /></td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Duration (Mins)', 'competitive-exam-quiz'); ?></label></th>
                                <td><input type="number" name="duration_mins" value="<?php echo $edit_quiz ? intval($edit_quiz['duration_mins']) : '60'; ?>" required min="1" class="small-text" /> mins</td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Minimum Passing Score (%)', 'competitive-exam-quiz'); ?></label></th>
                                <td><input type="number" step="0.5" name="passing_score" value="<?php echo $edit_quiz ? floatval($edit_quiz['passing_score']) : '33.0'; ?>" required min="0" class="small-text" /> %</td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Positive Mark per Correct', 'competitive-exam-quiz'); ?></label></th>
                                <td><input type="number" step="0.1" name="positive_marks" value="<?php echo $edit_quiz ? floatval($edit_quiz['positive_marks']) : '2.0'; ?>" required class="small-text" /> marks</td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Negative Mark per Incorrect', 'competitive-exam-quiz'); ?></label></th>
                                <td><input type="number" step="0.1" name="negative_marks" value="<?php echo $edit_quiz ? floatval($edit_quiz['negative_marks']) : '0.5'; ?>" required class="small-text" /> marks</td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Exam Sections', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <textarea name="sections" rows="3" style="width:100%; font-family:inherit;" placeholder="Let separate options with commas. Example: General Intelligence, General Awareness, Quantitative Aptitude, English Language"><?php echo $edit_quiz ? esc_textarea($edit_quiz['sections']) : ''; ?></textarea>
                                    <p class="description"><?php _e('Comma-separated list of exam sections. Leave empty to start with no sections by default. Sections will be auto-generated when uploading a CSV or manually typing section names.', 'competitive-exam-quiz'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Scheduled Start Time', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="datetime-local" name="starts_at" class="regular-text" style="width:100%; max-width: 250px;" value="<?php echo $edit_quiz && isset($edit_quiz['starts_at']) ? esc_attr($edit_quiz['starts_at']) : ''; ?>" />
                                    <p class="description"><?php _e('Set a target date and time when the exam goes live. Prior to this, candidates will be presented with a real-time countdown. Leave empty for instant access.', 'competitive-exam-quiz'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Exam Status/State', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <?php $curr_status = $edit_quiz && isset($edit_quiz['status']) ? $edit_quiz['status'] : 'published'; ?>
                                    <select name="status" class="postform" style="width:100%; max-width: 250px;">
                                        <option value="published" <?php selected($curr_status, 'published'); ?>><?php _e('🟢 Published (Standard CBT Access)', 'competitive-exam-quiz'); ?></option>
                                        <option value="draft" <?php selected($curr_status, 'draft'); ?>><?php _e('🔘 Draft (Restricted / Hidden)', 'competitive-exam-quiz'); ?></option>
                                    </select>
                                    <p class="description"><?php _e('Draft exams will remain hidden from candidates on front-end layouts but can be configured and updated inside WP Admin.', 'competitive-exam-quiz'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Phone Restriction', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <?php $curr_restrict = $edit_quiz && isset($edit_quiz['restrict_by_phone']) ? intval($edit_quiz['restrict_by_phone']) : 0; ?>
                                    <input type="checkbox" name="restrict_by_phone" id="ceq_restrict_by_phone" value="1" <?php checked($curr_restrict, 1); ?> onchange="jQuery('#ceq-phone-upload-row').toggle(this.checked);" />
                                    <label for="ceq_restrict_by_phone"><strong><?php _e('Restrict participation to pre-uploaded mobile numbers', 'competitive-exam-quiz'); ?></strong></label>
                                    <p class="description"><?php _e('Enable this to allow only students whose mobile numbers are uploaded in a CSV file to participate in the exam. Each registered student can write the exam exactly once.', 'competitive-exam-quiz'); ?></p>
                                </td>
                            </tr>
                            <tr id="ceq-phone-upload-row" style="<?php echo $curr_restrict === 1 ? '' : 'display: none;'; ?>">
                                <th scope="row"><label><?php _e('Upload Mobile Numbers CSV', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="file" name="allowed_phones_csv" accept=".csv" />
                                    <p class="description"><?php _e('Upload a CSV file containing allowed mobile numbers. The file should list phone numbers (e.g. one per row, optionally under a "phone" or more header).', 'competitive-exam-quiz'); ?></p>
                                    <?php if ($edit_quiz && !empty($edit_quiz['allowed_phones'])): ?>
                                        <div style="margin-top: 10px; background: #fafafa; border: 1px solid #e2e8f0; padding: 10px; max-height: 120px; overflow-y: auto; font-family: monospace; font-size: 11px; border-radius: 4px;">
                                            <strong>Currently Parsed Allowed Numbers (<?php echo count(explode(',', $edit_quiz['allowed_phones'])); ?>):</strong><br>
                                            <span style="word-wrap: break-word;"><?php echo esc_html($edit_quiz['allowed_phones']); ?></span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Section-Specific Marks (JSON Override)', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <textarea name="section_settings" rows="4" style="width:100%; font-family:monospace;" placeholder='{"Section Name": {"positive_marks": 4, "negative_marks": 1}}'><?php echo $edit_quiz ? esc_textarea($edit_quiz['section_settings']) : ''; ?></textarea>
                                    <p class="description"><?php _e('Define custom scoring for specific quiz sections. Format as JSON, e.g., {"Physics": {"positive_marks": 4, "negative_marks": 1}}. Leave empty to use overall marking.', 'competitive-exam-quiz'); ?></p>
                                </td>
                            </tr>
                        </table>
                        <p class="submit">
                            <input type="submit" class="button button-primary" value="<?php echo $edit_quiz ? 'Update Exam Settings' : 'Create Exam Instance'; ?>" style="background-color: #2271b1; font-weight: 600;" />
                            <?php if ($edit_quiz): ?>
                                <a href="<?php echo admin_url('admin.php?page=competitive-exam-quiz'); ?>" class="button button-link"><?php _e('Cancel Edit', 'competitive-exam-quiz'); ?></a>
                            <?php endif; ?>
                        </p>
                    </form>
                </div>

                <!-- Active Quizzes list -->
                <div style="flex: 1.5; min-width: 380px; background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                    <h2 style="font-weight: 600; font-size: 16px; margin-top: 0;">Active Exam Portals</h2>
                    <table class="wp-list-table widefat fixed striped table-view-list" style="margin-top: 10px;">
                        <thead>
                            <tr>
                                <th style="font-weight: 600; width: 45px;"><?php _e('ID', 'competitive-exam-quiz'); ?></th>
                                <th style="font-weight: 600;"><?php _e('Title', 'competitive-exam-quiz'); ?></th>
                                <th style="font-weight: 600;"><?php _e('Duration', 'competitive-exam-quiz'); ?></th>
                                <th style="font-weight: 600;"><?php _e('Sections', 'competitive-exam-quiz'); ?></th>
                                <th style="font-weight: 600;"><?php _e('Schedule Mode', 'competitive-exam-quiz'); ?></th>
                                <th style="font-weight: 600;"><?php _e('Marking (+/-)', 'competitive-exam-quiz'); ?></th>
                                <th style="font-weight: 600;"><?php _e('Shortcode', 'competitive-exam-quiz'); ?></th>
                                <th style="font-weight: 600;"><?php _e('Actions', 'competitive-exam-quiz'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($quizzes)): ?>
                                <tr><td colspan="8" style="text-align: center; color: #8c8f94;"><?php _e('No quiz portals found. Create one now!', 'competitive-exam-quiz'); ?></td></tr>
                            <?php else: ?>
                                <?php foreach ($quizzes as $quiz): ?>
                                    <tr>
                                        <td><?php echo intval($quiz['id']); ?></td>
                                        <td>
                                            <strong><?php echo esc_html($quiz['title']); ?></strong>
                                            <div style="margin-top: 4px;">
                                                <?php if (isset($quiz['status']) && $quiz['status'] === 'draft'): ?>
                                                    <span style="font-size: 10px; font-weight: bold; background: #e2e8f0; border: 1px solid #cbd5e1; color: #475569; padding: 1px 4px; border-radius: 3px;">🔘 Draft</span>
                                                <?php else: ?>
                                                    <span style="font-size: 10px; font-weight: bold; background: #dcfce7; border: 1px solid #bbf7d0; color: #166534; padding: 1px 4px; border-radius: 3px;">🟢 Published</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td><?php echo intval($quiz['duration_mins']); ?> mins</td>
                                        <td><div style="font-size:11px; color:#555; max-height: 48px; overflow:hidden; text-overflow:ellipsis;"><?php echo esc_html($quiz['sections'] ?? 'N/A'); ?></div></td>
                                        <td>
                                            <?php if (!empty($quiz['starts_at'])): ?>
                                                <span style="font-size: 11px; font-weight: 600; background: #eff6ff; border: 1px solid #bfdbfe; color: #1d4ed8; padding: 2px 6px; border-radius: 4px; display: inline-block;">
                                                    🕒 Scheduled:<br><?php echo esc_html(str_replace('T', ' ', $quiz['starts_at'])); ?>
                                                </span>
                                            <?php else: ?>
                                                <span style="font-size: 11px; font-weight: 600; background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 2px 6px; border-radius: 4px; display: inline-block;">
                                                     🟢 Immediate
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td><span style="color: green;">+<?php echo floatval($quiz['positive_marks']); ?></span> / <span style="color: red;">-<?php echo floatval($quiz['negative_marks']); ?></span></td>
                                        <td><code>[competitive_quiz id="<?php echo intval($quiz['id']); ?>"]</code></td>
                                        <td>
                                            <a class="button button-small" href="<?php echo admin_url('admin.php?page=competitive-exam-quiz&action=ceq_edit_quiz&quiz_id=' . $quiz['id']); ?>"><?php _e('Edit', 'competitive-exam-quiz'); ?></a>
                                            <a class="button button-small button-secondary" href="<?php echo admin_url('admin.php?page=ceq-questions-manager&quiz_id=' . $quiz['id']); ?>"><?php _e('Questions', 'competitive-exam-quiz'); ?></a>
                                            <a class="button button-small" href="<?php echo admin_url('admin.php?page=ceq-results-manager&quiz_id=' . $quiz['id']); ?>"><?php _e('Results', 'competitive-exam-quiz'); ?></a>
                                            <a class="button button-small delete" onclick="return confirm('Deleting this quiz will wipe out all questions and results connected to it. Continue?');" href="<?php echo wp_nonce_url(admin_url('admin.php?page=competitive-exam-quiz&action=ceq_delete_quiz&quiz_id=' . $quiz['id']), 'ceq_delete_quiz_' . $quiz['id']); ?>" style="color: #b32d2e; border-color: #b32d2e; display:block; margin-top:2px; text-align:center;"><?php _e('Delete', 'competitive-exam-quiz'); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render full question inventory, individual question builder and CSV import interface
     */
    public function render_questions_page() {
        global $wpdb, $ceq_db;
        $quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;
        
        if (!$quiz_id) {
            $all_quizzes = $ceq_db->get_quizzes();
            $quiz_id = !empty($all_quizzes) ? intval($all_quizzes[0]['id']) : 0;
        }

        if (!$quiz_id) {
            echo '<div class="wrap"><h1 style="font-weight: 700;">Please create a Quiz first in the main dashboard before managing questions.</h1></div>';
            return;
        }

        // Action: Individual Question insert manually
        if (isset($_POST['ceq_add_question_nonce']) && wp_verify_nonce($_POST['ceq_add_question_nonce'], 'ceq_add_question')) {
            $sec            = sanitize_text_field($_POST['section_name']);
            $text           = wp_kses_post($_POST['question_text']);
            $opts           = array_map('sanitize_text_field', $_POST['options']);
            $correct        = intval($_POST['correct_option_index']);
            $explain        = wp_kses_post($_POST['explanation']);
            $q_pos          = (isset($_POST['positive_marks']) && $_POST['positive_marks'] !== '') ? floatval($_POST['positive_marks']) : null;
            $q_neg          = (isset($_POST['negative_marks']) && $_POST['negative_marks'] !== '') ? floatval($_POST['negative_marks']) : null;
            $image_url      = isset($_POST['question_image_url']) ? esc_url_raw($_POST['question_image_url']) : '';

            // Handle manual physical file upload using WP media helpers
            if (!empty($_FILES['ceq_question_image_file']['name'])) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                require_once(ABSPATH . 'wp-admin/includes/file.php');
                require_once(ABSPATH . 'wp-admin/includes/media.php');
                
                $attachment_id = media_handle_upload('ceq_question_image_file', 0);
                if (!is_wp_error($attachment_id)) {
                    $image_url = wp_get_attachment_url($attachment_id);
                }
            }

            // Handle Option Images
            $opt_images = array('', '', '', '');
            if (isset($_POST['option_image_urls']) && is_array($_POST['option_image_urls'])) {
                foreach ($_POST['option_image_urls'] as $i => $val) {
                    $opt_images[$i] = esc_url_raw($val);
                }
            }
            for ($i = 0; $i < 4; $i++) {
                $file_key = 'ceq_option_image_file_' . $i;
                if (!empty($_FILES[$file_key]['name'])) {
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    require_once(ABSPATH . 'wp-admin/includes/file.php');
                    require_once(ABSPATH . 'wp-admin/includes/media.php');
                    
                    $attachment_id = media_handle_upload($file_key, 0);
                    if (!is_wp_error($attachment_id)) {
                        $opt_images[$i] = wp_get_attachment_url($attachment_id);
                    }
                }
            }

            $wpdb->insert($wpdb->prefix . 'ceq_questions', array(
                'quiz_id'              => $quiz_id,
                'section_name'         => $sec,
                'question_text'        => $text,
                'options'              => json_encode($opts),
                'correct_option_index' => $correct,
                'explanation'          => $explain,
                'positive_marks'       => $q_pos,
                'negative_marks'       => $q_neg,
                'question_image'       => $image_url,
                'option_images'        => json_encode($opt_images)
            ));

            // Automatically register new section name to parent Quiz
            if (!empty($sec)) {
                $quiz_table = $wpdb->prefix . 'ceq_quizzes';
                $parent_quiz = $wpdb->get_row($wpdb->prepare("SELECT * FROM $quiz_table WHERE id = %d", $quiz_id), ARRAY_A);
                if ($parent_quiz) {
                    $existing_sections = !empty($parent_quiz['sections']) ? array_map('trim', explode(',', $parent_quiz['sections'])) : array();
                    if (!in_array($sec, $existing_sections)) {
                        $existing_sections[] = $sec;
                        $wpdb->update($quiz_table, array('sections' => implode(',', array_filter($existing_sections))), array('id' => $quiz_id));
                    }
                }
            }

            echo '<div class="notice notice-success is-dismissible"><p>' . __('Question saved successfully!', 'competitive-exam-quiz') . '</p></div>';
        }

        // Action: Individual Question UPDATE manually
        if (isset($_POST['ceq_edit_question_nonce']) && wp_verify_nonce($_POST['ceq_edit_question_nonce'], 'ceq_edit_question')) {
            $q_id           = intval($_POST['edit_question_id']);
            $sec            = sanitize_text_field($_POST['section_name']);
            $text           = wp_kses_post($_POST['question_text']);
            $opts           = array_map('sanitize_text_field', $_POST['options']);
            $correct        = intval($_POST['correct_option_index']);
            $explain        = wp_kses_post($_POST['explanation']);
            $q_pos          = (isset($_POST['positive_marks']) && $_POST['positive_marks'] !== '') ? floatval($_POST['positive_marks']) : null;
            $q_neg          = (isset($_POST['negative_marks']) && $_POST['negative_marks'] !== '') ? floatval($_POST['negative_marks']) : null;
            
            // Retain old image if no new input URL or file is selected
            $existing_q     = $wpdb->get_row($wpdb->prepare("SELECT question_image, option_images FROM {$wpdb->prefix}ceq_questions WHERE id = %d", $q_id), ARRAY_A);
            $image_url      = ($existing_q && !empty($existing_q['question_image'])) ? $existing_q['question_image'] : '';
            
            $existing_option_images = array('', '', '', '');
            if ($existing_q && !empty($existing_q['option_images'])) {
                $existing_option_images = json_decode($existing_q['option_images'], true);
                if (!is_array($existing_option_images)) {
                    $existing_option_images = array('', '', '', '');
                }
            }

            if (isset($_POST['question_image_url'])) {
                $input_url = trim($_POST['question_image_url']);
                if ($input_url !== '') {
                    $image_url = esc_url_raw($input_url);
                } else {
                    $image_url = ''; // Cleared intentionally
                }
            }

            // Handle manual physical file upload using WP media helpers
            if (!empty($_FILES['ceq_question_image_file']['name'])) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                require_once(ABSPATH . 'wp-admin/includes/file.php');
                require_once(ABSPATH . 'wp-admin/includes/media.php');
                
                $attachment_id = media_handle_upload('ceq_question_image_file', 0);
                if (!is_wp_error($attachment_id)) {
                    $image_url = wp_get_attachment_url($attachment_id);
                }
            }

            // Handle Option Images Update
            $opt_images = $existing_option_images;
            if (isset($_POST['option_image_urls']) && is_array($_POST['option_image_urls'])) {
                foreach ($_POST['option_image_urls'] as $i => $val) {
                    $opt_images[$i] = esc_url_raw($val);
                }
            }
            for ($i = 0; $i < 4; $i++) {
                $file_key = 'ceq_option_image_file_' . $i;
                if (!empty($_FILES[$file_key]['name'])) {
                    require_once(ABSPATH . 'wp-admin/includes/image.php');
                    require_once(ABSPATH . 'wp-admin/includes/file.php');
                    require_once(ABSPATH . 'wp-admin/includes/media.php');
                    
                    $attachment_id = media_handle_upload($file_key, 0);
                    if (!is_wp_error($attachment_id)) {
                        $opt_images[$i] = wp_get_attachment_url($attachment_id);
                    }
                }
            }

            $wpdb->update($wpdb->prefix . 'ceq_questions', array(
                'section_name'         => $sec,
                'question_text'        => $text,
                'options'              => json_encode($opts),
                'correct_option_index' => $correct,
                'explanation'          => $explain,
                'positive_marks'       => $q_pos,
                'negative_marks'       => $q_neg,
                'question_image'       => $image_url,
                'option_images'        => json_encode($opt_images)
            ), array('id' => $q_id));

            // Automatically check if section needs registering to parent quiz
            if (!empty($sec)) {
                $quiz_table = $wpdb->prefix . 'ceq_quizzes';
                $parent_quiz = $wpdb->get_row($wpdb->prepare("SELECT * FROM $quiz_table WHERE id = %d", $quiz_id), ARRAY_A);
                if ($parent_quiz) {
                    $existing_sections = !empty($parent_quiz['sections']) ? array_map('trim', explode(',', $parent_quiz['sections'])) : array();
                    if (!in_array($sec, $existing_sections)) {
                        $existing_sections[] = $sec;
                        $wpdb->update($quiz_table, array('sections' => implode(',', array_filter($existing_sections))), array('id' => $quiz_id));
                    }
                }
            }

            echo '<div class="notice notice-success is-dismissible"><p>' . __('Question updated successfully!', 'competitive-exam-quiz') . '</p></div>';
        }

        // Action: Fetch Question if Editing mode is triggered internally
        $edit_question = null;
        if (isset($_GET['action']) && $_GET['action'] === 'ceq_edit_question' && isset($_GET['question_id'])) {
            $edit_id = intval($_GET['question_id']);
            $edit_question = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ceq_questions WHERE id = %d", $edit_id), ARRAY_A);
            if ($edit_question) {
                $edit_question['options'] = json_decode($edit_question['options'], true);
                if (!empty($edit_question['option_images'])) {
                    $edit_question['option_images'] = json_decode($edit_question['option_images'], true);
                } else {
                    $edit_question['option_images'] = array('', '', '', '');
                }
            }
        }

        $active_quiz = $ceq_db->get_quiz($quiz_id);
        $questions   = $ceq_db->get_questions($quiz_id);
        $quizzes     = $ceq_db->get_quizzes();

        // Dynamically split active sections list
        $sections_list = isset($active_quiz['sections']) && !empty(trim($active_quiz['sections']))
            ? array_map('trim', explode(',', $active_quiz['sections']))
            : array();
        ?>
        <div class="wrap" style="background: #fdfdfd; padding: 20px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h1 style="font-weight: 700; color: #1d2327; margin-bottom: 20px;"><?php _e('Question Management Portal', 'competitive-exam-quiz'); ?></h1>
            
            <div style="margin-bottom: 24px; padding: 15px; background: #eef7ff; border-left: 4px solid #1a73e8; border-radius: 4px; display: flex; align-items: center; justify-content: space-between;">
                <div>
                     <h3 style="margin: 0; font-size: 16px; color: #00367a; font-weight: 600;"><?php _e('Currently Managing: ', 'competitive-exam-quiz'); ?><?php echo esc_html($active_quiz['title']); ?></h3>
                     <p style="margin: 3px 0 0; color: #3c4043;"><?php echo count($questions); ?> <?php _e('total questions registered in mock databank.', 'competitive-exam-quiz'); ?></p>
                </div>
                <!-- Selection dropdown -->
                <form method="get" action="">
                    <input type="hidden" name="page" value="ceq-questions-manager" />
                    <strong>Select Quiz: </strong>
                    <select name="quiz_id" onchange="this.form.submit()" style="padding: 4px 6px; font-weight: 500;">
                        <?php foreach($quizzes as $qz): ?>
                            <option value="<?php echo intval($qz['id']); ?>" <?php selected($quiz_id, $qz['id']); ?>><?php echo esc_html($qz['title']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>

            <div style="display: flex; gap: 24px; flex-wrap: wrap;">
                <!-- CSV question uploader & manual form panel -->
                <div style="flex: 1; min-width: 320px; background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                    <?php if (!$edit_question): ?>
                        <h2 style="font-weight: 600; font-size: 16px; margin-top: 0; display: flex; align-items: center; gap: 6px;"><span class="dashicons dashicons-database-import" style="color: #1a73e8;"></span> <?php _e('CSV Import Utility', 'competitive-exam-quiz'); ?></h2>
                        <form method="post" enctype="multipart/form-data" action="" style="background: #fdfdfd; padding: 15px; border: 1px dashed #c0c0c0; border-radius: 4px; margin-bottom: 25px;">
                            <?php wp_nonce_field('ceq_import_csv', 'ceq_import_csv_nonce'); ?>
                            <input type="hidden" name="import_quiz_id" value="<?php echo intval($quiz_id); ?>" />
                            <p style="margin-top: 0;"><?php _e('Excel structure: CSV column mapping has to follow strictly this order: <code>Section Name, Question, Option 1, Option 2, Option 3, Option 4, Correct Option Index (0-3), Explanation</code>', 'competitive-exam-quiz'); ?></p>
                            <p><input type="file" name="ceq_csv_file" required accept=".csv" /></p>
                            <p><input type="submit" class="button button-secondary" value="Import via CSV File" style="font-weight: 600;" /></p>
                        </form>
                    <?php endif; ?>

                    <h2 style="font-weight: 600; font-size: 16px; margin-top: 20px; color: #1a73e8;">
                        <?php echo $edit_question ? __('Edit Question Parameters (ID: ' . intval($edit_question['id']) . ')', 'competitive-exam-quiz') : __('Add Question Manually', 'competitive-exam-quiz'); ?>
                    </h2>
                    
                    <form method="post" enctype="multipart/form-data" action="">
                        <?php if ($edit_question): ?>
                            <?php wp_nonce_field('ceq_edit_question', 'ceq_edit_question_nonce'); ?>
                            <input type="hidden" name="edit_question_id" value="<?php echo intval($edit_question['id']); ?>" />
                        <?php else: ?>
                            <?php wp_nonce_field('ceq_add_question', 'ceq_add_question_nonce'); ?>
                        <?php endif; ?>

                        <table class="form-table" style="max-width: 100%;">
                            <tr>
                                <th scope="row"><label><?php _e('Section Name', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="text" name="section_name" required list="ceq-sections-datalist" placeholder="e.g. History or Quantitative Aptitude" style="width: 100%; max-width: 250px;" class="regular-text" value="<?php echo $edit_question ? esc_attr($edit_question['section_name']) : ''; ?>" />
                                    <datalist id="ceq-sections-datalist">
                                        <?php foreach ($sections_list as $sec): ?>
                                            <option value="<?php echo esc_attr($sec); ?>">
                                        <?php endforeach; ?>
                                    </datalist>
                                    <p class="description"><?php _e('Type section name or select existing sections list.', 'competitive-exam-quiz'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Question Text', 'competitive-exam-quiz'); ?></label></th>
                                <td><textarea name="question_text" required rows="4" style="width: 100%; font-family: inherit;"><?php echo $edit_question ? esc_textarea($edit_question['question_text']) : ''; ?></textarea></td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Option A', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="text" name="options[]" class="large-text" value="<?php echo ($edit_question && isset($edit_question['options'][0])) ? esc_attr($edit_question['options'][0]) : ''; ?>" />
                                    <div style="margin-top: 6px; display: flex; align-items: center; gap: 8px;">
                                        <input type="text" name="option_image_urls[0]" placeholder="<?php _e('Option A Image URL (Optional)', 'competitive-exam-quiz'); ?>" class="regular-text" style="width: 300px; margin: 0;" value="<?php echo ($edit_question && isset($edit_question['option_images'][0])) ? esc_attr($edit_question['option_images'][0]) : ''; ?>" />
                                        <input type="file" name="ceq_option_image_file_0" accept="image/*" />
                                    </div>
                                    <?php if ($edit_question && !empty($edit_question['option_images'][0])): ?>
                                        <div style="margin-top: 6px;"><img src="<?php echo esc_url($edit_question['option_images'][0]); ?>" style="max-height: 50px; border: 1px solid #ddd; padding: 2px; background: #fff;" /></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Option B', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="text" name="options[]" class="large-text" value="<?php echo ($edit_question && isset($edit_question['options'][1])) ? esc_attr($edit_question['options'][1]) : ''; ?>" />
                                    <div style="margin-top: 6px; display: flex; align-items: center; gap: 8px;">
                                        <input type="text" name="option_image_urls[1]" placeholder="<?php _e('Option B Image URL (Optional)', 'competitive-exam-quiz'); ?>" class="regular-text" style="width: 300px; margin: 0;" value="<?php echo ($edit_question && isset($edit_question['option_images'][1])) ? esc_attr($edit_question['option_images'][1]) : ''; ?>" />
                                        <input type="file" name="ceq_option_image_file_1" accept="image/*" />
                                    </div>
                                    <?php if ($edit_question && !empty($edit_question['option_images'][1])): ?>
                                        <div style="margin-top: 6px;"><img src="<?php echo esc_url($edit_question['option_images'][1]); ?>" style="max-height: 50px; border: 1px solid #ddd; padding: 2px; background: #fff;" /></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Option C', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="text" name="options[]" class="large-text" value="<?php echo ($edit_question && isset($edit_question['options'][2])) ? esc_attr($edit_question['options'][2]) : ''; ?>" />
                                    <div style="margin-top: 6px; display: flex; align-items: center; gap: 8px;">
                                        <input type="text" name="option_image_urls[2]" placeholder="<?php _e('Option C Image URL (Optional)', 'competitive-exam-quiz'); ?>" class="regular-text" style="width: 300px; margin: 0;" value="<?php echo ($edit_question && isset($edit_question['option_images'][2])) ? esc_attr($edit_question['option_images'][2]) : ''; ?>" />
                                        <input type="file" name="ceq_option_image_file_2" accept="image/*" />
                                    </div>
                                    <?php if ($edit_question && !empty($edit_question['option_images'][2])): ?>
                                        <div style="margin-top: 6px;"><img src="<?php echo esc_url($edit_question['option_images'][2]); ?>" style="max-height: 50px; border: 1px solid #ddd; padding: 2px; background: #fff;" /></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Option D', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="text" name="options[]" class="large-text" value="<?php echo ($edit_question && isset($edit_question['options'][3])) ? esc_attr($edit_question['options'][3]) : ''; ?>" />
                                    <div style="margin-top: 6px; display: flex; align-items: center; gap: 8px;">
                                        <input type="text" name="option_image_urls[3]" placeholder="<?php _e('Option D Image URL (Optional)', 'competitive-exam-quiz'); ?>" class="regular-text" style="width: 300px; margin: 0;" value="<?php echo ($edit_question && isset($edit_question['option_images'][3])) ? esc_attr($edit_question['option_images'][3]) : ''; ?>" />
                                        <input type="file" name="ceq_option_image_file_3" accept="image/*" />
                                    </div>
                                    <?php if ($edit_question && !empty($edit_question['option_images'][3])): ?>
                                        <div style="margin-top: 6px;"><img src="<?php echo esc_url($edit_question['option_images'][3]); ?>" style="max-height: 50px; border: 1px solid #ddd; padding: 2px; background: #fff;" /></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Correct Index', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <?php $curr_correct = $edit_question ? intval($edit_question['correct_option_index']) : 0; ?>
                                    <select name="correct_option_index">
                                        <option value="0" <?php selected($curr_correct, 0); ?>>A</option>
                                        <option value="1" <?php selected($curr_correct, 1); ?>>B</option>
                                        <option value="2" <?php selected($curr_correct, 2); ?>>C</option>
                                        <option value="3" <?php selected($curr_correct, 3); ?>>D</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Question Image', 'competitive-exam-quiz'); ?></label></th>
                                <td>
                                    <input type="text" name="question_image_url" placeholder="Paste image URL here, or upload below..." style="width: 100%; margin-bottom: 5px;" class="regular-text" value="<?php echo $edit_question && isset($edit_question['question_image']) ? esc_attr($edit_question['question_image']) : ''; ?>" />
                                    <br>
                                    <input type="file" name="ceq_question_image_file" accept="image/*" />
                                    <?php if ($edit_question && !empty($edit_question['question_image'])): ?>
                                        <div style="margin-top: 10px;">
                                            <strong>Current Image Preview:</strong><br>
                                            <img src="<?php echo esc_url($edit_question['question_image']); ?>" style="max-width: 150px; border: 1px solid #c3c4c7; margin-top:5px; border-radius:3px;" />
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Explanation', 'competitive-exam-quiz'); ?></label></th>
                                <td><textarea name="explanation" rows="3" style="width: 100%; font-family: inherit;"><?php echo $edit_question ? esc_textarea($edit_question['explanation']) : ''; ?></textarea></td>
                            </tr>
                        </table>
                        <p class="submit" style="display: flex; gap: 8px; align-items: center;">
                            <input type="submit" class="button button-primary" value="<?php echo $edit_question ? __('Update Question Entry', 'competitive-exam-quiz') : __('Save Question Entry', 'competitive-exam-quiz'); ?>" />
                            <?php if ($edit_question): ?>
                                <a href="<?php echo admin_url('admin.php?page=ceq-questions-manager&quiz_id=' . $quiz_id); ?>" class="button button-link"><?php _e('Cancel Edit', 'competitive-exam-quiz'); ?></a>
                            <?php endif; ?>
                        </p>
                    </form>
                </div>

                <!-- Live Inventory list -->
                <div style="flex: 1.5; min-width: 380px; background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                    <h2 style="font-weight: 600; font-size: 16px; margin-top: 0;"><?php _e('Active Question Bank', 'competitive-exam-quiz'); ?></h2>
                    <div style="max-height: 800px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 4px; padding: 10px;">
                        <?php if (empty($questions)): ?>
                            <p style="text-align: center; color: #8c8f94; padding: 40px 0;"><?php _e('This exam is empty. Add questions or import via CSV to begin.', 'competitive-exam-quiz'); ?></p>
                        <?php else: ?>
                            <?php $num=1; foreach($questions as $question): ?>
                                <div style="border-bottom: 1px solid #edf2f7; padding: 12px 0; margin-bottom: 12px;">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                        <span style="font-weight: 600; color: #1a73e8; background: #e8f0fe; padding: 2px 8px; border-radius: 20px; font-size: 11px;"><?php echo esc_html($question['section_name']); ?></span>
                                        <span style="font-size: 12px; color: #718096; font-weight: 500;">Q. <?php echo $num++; ?></span>
                                    </div>
                                    <p style="font-weight: 500; font-size: 14px; margin: 8px 0; color: #2d3748;"><?php echo esc_html($question['question_text']); ?></p>
                                    
                                    <?php if (!empty($question['question_image'])): ?>
                                        <div style="margin: 10px 0;">
                                            <a href="<?php echo esc_url($question['question_image']); ?>" target="_blank">
                                                <img src="<?php echo esc_url($question['question_image']); ?>" style="max-height: 120px; border: 1px solid #edf2f7; border-radius: 4px; display: block; box-shadow: 0 1px 2px rgba(0,0,0,0.05);" />
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <ol type="A" style="margin: 0; padding-left: 20px; font-size: 13px; color: #4a5568;">
                                        <?php if (is_array($question['options'])): ?>
                                            <?php foreach($question['options'] as $idx => $opt): ?>
                                                <li style="<?php echo ($idx === intval($question['correct_option_index'])) ? 'color: #10b981; font-weight: 600;' : ''; ?> margin-bottom: 8px;">
                                                    <div><?php echo esc_html($opt); ?></div>
                                                    <?php if (!empty($question['option_images'][$idx])): ?>
                                                        <div style="margin: 4px 0;">
                                                            <a href="<?php echo esc_url($question['option_images'][$idx]); ?>" target="_blank">
                                                                <img src="<?php echo esc_url($question['option_images'][$idx]); ?>" style="max-height: 50px; border: 1px solid #edf2f7; border-radius: 4px; display: block;" />
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if($idx === intval($question['correct_option_index'])) echo ' <span style="font-size: 11px; font-weight: normal;">(Correct Answer)</span>'; ?>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </ol>
                                    <?php if (!empty($question['explanation'])): ?>
                                        <div style="background: #f8fafc; padding: 8px 12px; margin-top: 8px; border-radius: 4px; font-size: 12px; color: #64748b; border-left: 3px solid #cbd5e1;">
                                            <strong>Explanation:</strong> <?php echo esc_html($question['explanation']); ?>
                                        </div>
                                    <?php endif; ?>

                                    <div style="margin-top: 10px; display: flex; gap: 8px;">
                                        <a href="<?php echo admin_url('admin.php?page=ceq-questions-manager&quiz_id=' . $quiz_id . '&action=ceq_edit_question&question_id=' . $question['id']); ?>" 
                                           class="button button-small" 
                                           style="font-weight: 600;">
                                           Edit Details
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render candidates performance metrics list and public leaderboard exports
     */
    public function render_results_page() {
        global $wpdb, $ceq_db;
        $quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;

        if (!$quiz_id) {
            $all_quizzes = $ceq_db->get_quizzes();
            $quiz_id = !empty($all_quizzes) ? intval($all_quizzes[0]['id']) : 0;
        }

        if (!$quiz_id) {
            echo '<div class="wrap"><h1 style="font-weight: 700;">Please create a Quiz first in the main dashboard to proceed with Results.</h1></div>';
            return;
        }

        $active_quiz = $ceq_db->get_quiz($quiz_id);
        $quizzes = $ceq_db->get_quizzes();

        $table_results = $wpdb->prefix . 'ceq_results';
        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_results WHERE quiz_id = %d ORDER BY score DESC, time_taken_seconds ASC", $quiz_id), ARRAY_A);

        $total_possible_marks = $ceq_db->get_quiz_total_marks($quiz_id);
        $passing_percentage = floatval($active_quiz['passing_score'] ?? 33.0);
        $required_score_to_pass = ($passing_percentage / 100.0) * $total_possible_marks;

        if (isset($_GET['deleted']) && $_GET['deleted'] == 1) {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Student result entry deleted successfully!', 'competitive-exam-quiz') . '</p></div>';
        }
        ?>
        <div class="wrap" style="background: #fdfdfd; padding: 20px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; margin-bottom: 20px;">
                <h1 style="font-weight: 700; color: #1d2327; margin: 0;">Exam Performance & Meritorious Rank List</h1>
                <a class="button button-primary" style="background-color: #10b981; font-weight: 600; border: none;" href="<?php echo admin_url('admin.php?page=ceq-results-manager&action=ceq_export_results&quiz_id=' . $quiz_id); ?>"><?php _e('Export Results to CSV', 'competitive-exam-quiz'); ?></a>
            </div>

            <div style="margin-bottom: 24px; padding: 15px; background: #fdfdfd; border: 1px solid #c3c4c7; border-radius: 4px; display: flex; align-items: center; justify-content: space-between;">
                <div>
                    <h3 style="margin: 0; font-size: 16px; font-weight: 600; color: #2c3e50;"><?php echo esc_html($active_quiz['title']); ?></h3>
                    <p style="margin: 3px 0 0; color: #7f8c8d;">
                        <?php echo count($results); ?> <?php _e('total candidates successfully completed this test.', 'competitive-exam-quiz'); ?>
                        | <?php _e('Required to Pass:', 'competitive-exam-quiz'); ?> <strong><?php echo number_format($required_score_to_pass, 2); ?> pts</strong> (<?php echo $passing_percentage; ?>% of <?php echo $total_possible_marks; ?> max pts)
                    </p>
                </div>
                <form method="get" action="">
                    <input type="hidden" name="page" value="ceq-results-manager" />
                    <strong>Select Quiz: </strong>
                    <select name="quiz_id" onchange="this.form.submit()" style="padding: 4px 6px; font-weight: 500;">
                        <?php foreach($quizzes as $qz): ?>
                            <option value="<?php echo intval($qz['id']); ?>" <?php selected($quiz_id, $qz['id']); ?>><?php echo esc_html($qz['title']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>

            <table class="wp-list-table widefat fixed striped table-view-list" style="border: 1px solid #e0e0e0; box-shadow: none;">
                <thead>
                    <tr>
                        <th style="font-weight: 700; width: 60px;"><?php _e('Rank', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700;"><?php _e('Candidate Name', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700;"><?php _e('Email Address', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700;"><?php _e('Mobile Number', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700;"><?php _e('Score Obtained', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700;"><?php _e('Time Taken', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700;"><?php _e('Anti-Cheat Warnings', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700;"><?php _e('Date & Time', 'competitive-exam-quiz'); ?></th>
                        <th style="font-weight: 700; width: 100px; text-align: center;"><?php _e('Actions', 'competitive-exam-quiz'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($results)): ?>
                        <tr><td colspan="9" style="text-align: center; color: #95a5a6; padding: 30px;"><?php _e('No submissions registered yet for this test.', 'competitive-exam-quiz'); ?></td></tr>
                    <?php else: ?>
                        <?php $rank = 1; foreach ($results as $res): 
                            $cand_score = floatval($res['score']);
                            $is_passed = ($cand_score >= $required_score_to_pass);
                        ?>
                            <tr>
                                <td style="font-weight: 700; color: #2c3e50;">#<?php echo $rank++; ?></td>
                                <td>
                                    <strong><?php echo esc_html($res['candidate_name']); ?></strong>
                                    <?php if (!empty($res['candidate_father_name'])): ?>
                                        <div style="font-size: 11px; color: #64748b; font-weight: 500; margin-top: 3px;">
                                            Father: <?php echo esc_html($res['candidate_father_name']); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($res['candidate_email'] ?: 'N/A'); ?></td>
                                <td><strong><?php echo esc_html($res['candidate_phone'] ?: 'N/A'); ?></strong></td>
                                <td>
                                    <div style="font-weight: 700; font-size: 14px; <?php echo $is_passed ? 'color: #10b981;' : 'color: #ef4444;'; ?>">
                                        <?php echo $cand_score; ?>
                                        <span style="font-size: 11px; font-weight: normal; color: #7f8c8d;"> (<?php echo $is_passed ? 'Passed' : 'Failed'; ?>)</span>
                                    </div>
                                </td>
                                <td><?php echo gmdate("H:i:s", intval($res['time_taken_seconds'])); ?></td>
                                <td>
                                    <?php if(intval($res['cheating_alerts_count']) > 0): ?>
                                        <span style="background: #fee2e2; color: #b91c1c; font-weight: 600; font-size: 11px; padding: 2px 8px; border-radius: 4px;">
                                            <?php echo intval($res['cheating_alerts_count']); ?> flag warnings
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #10b981; font-weight: 500; font-size: 12px;">✔ Clean (0 alerts)</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(date('Y-m-d H:i', strtotime($res['created_at']))); ?></td>
                                <td style="text-align: center;">
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ceq-results-manager&action=ceq_delete_result&quiz_id=' . $quiz_id . '&result_id=' . $res['id']), 'ceq_delete_result_' . $res['id']); ?>" 
                                       class="button button-small" 
                                       style="color: #ef4444; border-color: #fca5a5; font-weight: 600; text-decoration: none;"
                                       onclick="return confirm('Are you sure you want to permanently delete this student result entry? This cannot be undone.');">
                                       Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * CSV Questions Importer Logic
     */
    private function import_questions_from_csv() {
        if (empty($_FILES['ceq_csv_file']['tmp_name'])) {
            return;
        }

        $quiz_id = isset($_POST['import_quiz_id']) ? intval($_POST['import_quiz_id']) : 0;
        if (!$quiz_id) {
            return;
        }

        $file = $_FILES['ceq_csv_file']['tmp_name'];
        if (($handle = fopen($file, "r")) !== FALSE) {
            global $wpdb;
            $table = $wpdb->prefix . 'ceq_questions';
            
            // Skip headers line if present
            $header = fgetcsv($handle, 1000, ",");
            
            $imported_sections = array();
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                if (count($data) < 7) {
                    continue; // Incomplete row
                }

                $section_name  = sanitize_text_field($data[0]);
                $question_text = wp_kses_post($data[1]);
                $options       = array(
                    sanitize_text_field($data[2]),
                    sanitize_text_field($data[3]),
                    sanitize_text_field($data[4]),
                    sanitize_text_field($data[5])
                );
                $correct_idx   = intval($data[6]);
                $explanation   = isset($data[7]) ? wp_kses_post($data[7]) : '';
                $positive_override = (isset($data[8]) && $data[8] !== '') ? floatval($data[8]) : null;
                $negative_override = (isset($data[9]) && $data[9] !== '') ? floatval($data[9]) : null;

                $wpdb->insert($table, array(
                    'quiz_id'              => $quiz_id,
                    'section_name'         => $section_name,
                    'question_text'        => $question_text,
                    'options'              => json_encode($options),
                    'correct_option_index' => $correct_idx,
                    'explanation'          => $explanation,
                    'positive_marks'       => $positive_override,
                    'negative_marks'       => $negative_override,
                    'option_images'        => json_encode(array('', '', '', ''))
                ));

                if (!empty($section_name)) {
                    $imported_sections[] = $section_name;
                }
            }
            fclose($handle);

            // Automatically merge and update parent Quiz sections list
            if (!empty($imported_sections)) {
                $quiz_table = $wpdb->prefix . 'ceq_quizzes';
                $parent_quiz = $wpdb->get_row($wpdb->prepare("SELECT * FROM $quiz_table WHERE id = %d", $quiz_id), ARRAY_A);
                if ($parent_quiz) {
                    $existing_sections = !empty($parent_quiz['sections']) ? array_map('trim', explode(',', $parent_quiz['sections'])) : array();
                    $merged_sections = array_unique(array_merge($existing_sections, $imported_sections));
                    $wpdb->update($quiz_table, array('sections' => implode(',', array_filter($merged_sections))), array('id' => $quiz_id));
                }
            }

            echo '<div class="notice notice-success is-dismissible"><p>' . __('Questions batch successfully imported into test banco!', 'competitive-exam-quiz') . '</p></div>';
        }
    }

    /**
     * Core CSV Exporter Pipeline
     */
    private function export_results_to_csv() {
        $quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;
        if (!$quiz_id) {
            return;
        }

        global $wpdb;
        $table_results = $wpdb->prefix . 'ceq_results';
        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_results WHERE quiz_id = %d ORDER BY score DESC, time_taken_seconds ASC", $quiz_id), ARRAY_A);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=ceq_exam_results_' . $quiz_id . '_' . date('Y-m-d') . '.csv');
        $output = fopen('php://output', 'w');

        fputcsv($output, array('Rank', 'Candidate Name', 'Candidate Email', 'Mobile Number', 'Score Obtained', 'Time Taken (Seconds)', 'Anti-Cheat Alerts Count', 'Date Submitted'));

        $rank = 1;
        foreach ($results as $res) {
            fputcsv($output, array(
                $rank++,
                $res['candidate_name'],
                $res['candidate_email'],
                $res['candidate_phone'],
                $res['score'],
                $res['time_taken_seconds'],
                $res['cheating_alerts_count'],
                $res['created_at']
            ));
        }

        fclose($output);
        exit;
    }
}
