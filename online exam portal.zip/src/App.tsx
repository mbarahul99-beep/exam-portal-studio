import React, { useState, useEffect, useRef } from "react";
import JSZip from "jszip";
import { jsPDF } from "jspdf";
import { 
  INITIAL_QUIZZES, 
  INITIAL_QUESTIONS, 
  INITIAL_RESULTS, 
  PLUGIN_METADATA_FILES,
  Quiz, 
  Question, 
  Result,
  getQuestionMarks
} from "./data";

// Import raw PHP plugin files for copying/downloading
// @ts-ignore
import mainPhp from "./wordpress-files/competitive-exam-quiz.php?raw";
// @ts-ignore
import dbPhp from "./wordpress-files/includes/class-quiz-db.php?raw";
// @ts-ignore
import ajaxPhp from "./wordpress-files/includes/class-quiz-ajax.php?raw";
// @ts-ignore
import adminPhp from "./wordpress-files/admin/class-quiz-admin.php?raw";
// @ts-ignore
import publicPhp from "./wordpress-files/public/class-quiz-public.php?raw";
// @ts-ignore
import styleCss from "./wordpress-files/public/css/quiz-style.css?raw";
// @ts-ignore
import engineJs from "./wordpress-files/public/js/quiz-engine.js?raw";
// @ts-ignore
import readmeTxt from "./wordpress-files/readme.txt?raw";

import { 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Timer, 
  Download, 
  UploadCloud, 
  Plus, 
  Trash2, 
  Settings, 
  FileText, 
  Code, 
  Archive, 
  User, 
  List, 
  Sparkles, 
  ExternalLink, 
  ShieldAlert, 
  DownloadCloud, 
  Check, 
  Layers, 
  Globe 
} from "lucide-react";

const FILE_CONTENTS: Record<string, string> = {
  "competitive-exam-quiz.php": mainPhp,
  "includes/class-quiz-db.php": dbPhp,
  "includes/class-quiz-ajax.php": ajaxPhp,
  "admin/class-quiz-admin.php": adminPhp,
  "public/class-quiz-public.php": publicPhp,
  "public/css/quiz-style.css": styleCss,
  "public/js/quiz-engine.js": engineJs,
  "readme.txt": readmeTxt
};

export default function App() {
  // App UI modes: 'dashboard' | 'candidate' | 'explorer' | 'results_checker'
  const [appMode, setAppMode] = useState<'dashboard' | 'candidate' | 'explorer' | 'results_checker'>('dashboard');
  
  // Database states
  const [quizzes, setQuizzes] = useState<Quiz[]>(() => {
    const saved = localStorage.getItem("ceq_quizzes");
    return saved ? JSON.parse(saved) : INITIAL_QUIZZES;
  });

  const [questions, setQuestions] = useState<Question[]>(() => {
    const saved = localStorage.getItem("ceq_questions");
    return saved ? JSON.parse(saved) : INITIAL_QUESTIONS;
  });

  const [results, setResults] = useState<Result[]>(() => {
    const saved = localStorage.getItem("ceq_results");
    return saved ? JSON.parse(saved) : INITIAL_RESULTS;
  });

  // Keep in local storage
  useEffect(() => {
    localStorage.setItem("ceq_quizzes", JSON.stringify(quizzes));
  }, [quizzes]);

  useEffect(() => {
    localStorage.setItem("ceq_questions", JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem("ceq_results", JSON.stringify(results));
  }, [results]);

  // Admin states
  const [adminMenu, setAdminMenu] = useState<'quizzes' | 'questions' | 'results'>('quizzes');
  const [selectedQuizId, setSelectedQuizId] = useState<number>(1);
  const [formMode, setFormMode] = useState<'create' | 'edit'>('edit');
  const [newQuizTitle, setNewQuizTitle] = useState("");
  const [newQuizSubjectCode, setNewQuizSubjectCode] = useState("");
  const [newQuizSections, setNewQuizSections] = useState("");
  const [newQuizDuration, setNewQuizDuration] = useState(15);
  const [newQuizPassing, setNewQuizPassing] = useState(33);
  const [newQuizPositive, setNewQuizPositive] = useState(2);
  const [newQuizNegative, setNewQuizNegative] = useState(0.5);
  const [newQuizStartsAt, setNewQuizStartsAt] = useState("");
  const [newQuizStatus, setNewQuizStatus] = useState<'published' | 'draft'>('published');
  const [newQuizRestrictByPhone, setNewQuizRestrictByPhone] = useState<number>(0);
  const [newQuizAllowedPhones, setNewQuizAllowedPhones] = useState<string>("");
  const [newQuizSectionSettings, setNewQuizSectionSettings] = useState<string>(""); // JSON string with format: { [sectionName]: { positive_marks, negative_marks } }

  const [newQSection, setNewQSection] = useState("");
  const [newQText, setNewQText] = useState("");
  const [newQOptions, setNewQOptions] = useState<string[]>(["", "", "", ""]);
  const [newQCorrect, setNewQCorrect] = useState(0);
  const [newQExplanation, setNewQExplanation] = useState("");
  const [newQPositive, setNewQPositive] = useState<string>(""); // input as string (blank means use default)
  const [newQNegative, setNewQNegative] = useState<string>(""); // input as string (blank means use default)
  const [newQImage, setNewQImage] = useState("");
  const [newQOptionImages, setNewQOptionImages] = useState<string[]>(["", "", "", ""]);
  const [editingQId, setEditingQId] = useState<number | null>(null);

  const [bulkEditSection, setBulkEditSection] = useState("");
  const [bulkSectionPos, setBulkSectionPos] = useState("");
  const [bulkSectionNeg, setBulkSectionNeg] = useState("");

  const [bulkEditQNumber, setBulkEditQNumber] = useState("");
  const [bulkQNumPos, setBulkQNumPos] = useState("");
  const [bulkQNumNeg, setBulkQNumNeg] = useState("");

  const [csvUploadText, setCsvUploadText] = useState("");
  const [csvDemoNotice, setCsvDemoNotice] = useState(false);

  // Candidate/Exam States
  const [examState, setExamState] = useState<'setup' | 'instructions' | 'active' | 'grading'>('setup');
  const [candName, setCandName] = useState("");
  const [candFatherName, setCandFatherName] = useState("");
  const [candEmail, setCandEmail] = useState("");
  const [candPhone, setCandPhone] = useState("");
  const [candLang, setCandLang] = useState<"EN" | "HI">("EN");
  const [candQuizId, setCandQuizId] = useState<number>(1);

  // Keep candidate selected quiz pointing to an active published exam
  useEffect(() => {
    const publishedQuizzes = quizzes.filter(q => q.status !== 'draft');
    if (publishedQuizzes.length > 0) {
      if (!publishedQuizzes.some(q => q.id === candQuizId)) {
        setCandQuizId(publishedQuizzes[0].id);
      }
    } else if (candQuizId !== 0) {
      setCandQuizId(0);
    }
  }, [quizzes, candQuizId]);
  
  // Running exam simulation state
  const [currQIndex, setCurrQIndex] = useState(0);
  const [candAnswers, setCandAnswers] = useState<Record<number, number>>({}); // { question_id: option_index }
  const [paletteStatus, setPaletteStatus] = useState<Record<number, string>>({}); // { question_id: status }
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [totalSeconds, setTotalSeconds] = useState(0);
  const [cheatWarnings, setCheatWarnings] = useState(0);
  const [showCheatModal, setShowCheatModal] = useState(false);
  const [cheatHistory, setCheatHistory] = useState<Array<{type: string, time: string}>>([]);
  
  // Grading states
  const [gradedResult, setGradedResult] = useState<Result | null>(null);

  const [candCountdown, setCandCountdown] = useState<string | null>(null);

  useEffect(() => {
    const active = quizzes.find(q => q.id === candQuizId);
    if (!active || !active.starts_at) {
      setCandCountdown(null);
      return;
    }

    const check = () => {
      const targetTime = new Date(active.starts_at!.replace(" ", "T")).getTime();
      const currentNow = Date.now();
      const diff = targetTime - currentNow;

      if (isNaN(targetTime) || diff <= 0) {
        setCandCountdown(null);
      } else {
        const d = Math.floor(diff / (1000 * 60 * 60 * 24));
        const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((diff % (1000 * 60)) / 1000);
        
        const pad = (n: number) => n < 10 ? '0' + n : n;
        if (d > 0) {
          setCandCountdown(`${d}d ${pad(h)}h ${pad(m)}m ${pad(s)}s`);
        } else {
          setCandCountdown(`${pad(h)}:${pad(m)}:${pad(s)}`);
        }
      }
    };

    check();
    const timer = setInterval(check, 1000);
    return () => clearInterval(timer);
  }, [candQuizId, quizzes]);

  // Code Explorer states
  const [selectedFile, setSelectedFile] = useState<string>("competitive-exam-quiz.php");
  const [copySuccess, setCopySuccess] = useState<string | null>(null);
  const [zippingState, setZippingState] = useState(false);

  // Online results checker states
  const [checkerPhone, setCheckerPhone] = useState("");
  const [checkerResults, setCheckerResults] = useState<Result[] | null>(null);
  const [checkerError, setCheckerError] = useState("");
  const [selectedCheckResult, setSelectedCheckResult] = useState<Result | null>(null);
  const [showCheckerSolutions, setShowCheckerSolutions] = useState(false);

  const handleCheckerSearch = () => {
    setSelectedCheckResult(null);
    setShowCheckerSolutions(false);
    if (!checkerPhone.trim()) {
      setCheckerError("Please enter your registered mobile number.");
      setCheckerResults(null);
      return;
    }
    setCheckerError("");
    const cleanEntered = checkerPhone.replace(/\D/g, "");
    if (!cleanEntered) {
      setCheckerError("Please enter a valid phone number containing digits.");
      setCheckerResults(null);
      return;
    }

    const matches = results.filter(r => {
      const dbPhoneClean = r.candidate_phone ? r.candidate_phone.replace(/\D/g, "") : "";
      return dbPhoneClean === cleanEntered || r.candidate_phone === checkerPhone;
    });

    if (matches.length === 0) {
      setCheckerError("No examination records found matching this mobile number.");
      setCheckerResults([]);
    } else {
      setCheckerResults(matches);
    }
  };

  // Active quiz questions list
  const activeQuizQuestions = questions.filter(q => q.quiz_id === selectedQuizId);
  const activeExamQuestions = questions.filter(q => q.quiz_id === candQuizId);

  // Auto scroll effect
  const countdownRef = useRef<number | null>(null);

  // Timer interval Hook
  useEffect(() => {
    if (appMode === 'candidate' && examState === 'active') {
      countdownRef.current = window.setInterval(() => {
        setSecondsLeft(prev => {
          if (prev <= 1) {
            clearInterval(countdownRef.current!);
            triggerAutoSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [appMode, examState]);

  // Anti-cheat window blur listener
  useEffect(() => {
    const handleBlur = () => {
      if (appMode === 'candidate' && examState === 'active') {
        const time = new Date().toLocaleTimeString();
        setCheatWarnings(prev => {
          const next = prev + 1;
          setCheatHistory(curr => [...curr, {type: `Tab blur event detected`, time}]);
          if (next >= 3) {
            triggerAutoSubmit(true);
            return 3;
          } else {
            setShowCheatModal(true);
            return next;
          }
        });
      }
    };

    window.addEventListener("blur", handleBlur);
    return () => {
      window.removeEventListener("blur", handleBlur);
    };
  }, [appMode, examState]);

  // Synchronize dynamic form states when active quiz selection transitions
  useEffect(() => {
    if (formMode !== 'edit') return;
    const active = quizzes.find(qz => qz.id === selectedQuizId);
    if (active) {
      setNewQuizTitle(active.title);
      setNewQuizSubjectCode(active.subject_code || "");
      setNewQuizSections(active.sections || "");
      setNewQuizDuration(active.duration_mins);
      setNewQuizPassing(active.passing_score);
      setNewQuizPositive(active.positive_marks);
      setNewQuizNegative(active.negative_marks);
      setNewQuizStartsAt(active.starts_at || "");
      setNewQuizStatus(active.status || "published");
      setNewQuizRestrictByPhone(active.restrict_by_phone || 0);
      setNewQuizAllowedPhones(active.allowed_phones || "");
      setNewQuizSectionSettings(active.section_settings || "");
    }
  }, [selectedQuizId, formMode, quizzes]);

  // Handle standard simulation CSV question builder
  const handleCSVImportSim = () => {
    if (!csvUploadText.trim()) return;
    try {
      const rows = csvUploadText.split("\n");
      let added = 0;
      const importedSections: string[] = [];
      const newQuestionsList: Question[] = [];

      rows.forEach(row => {
        if (!row.trim()) return;
        const cols = row.split(",");
        if (cols.length < 7) return;

        const section_name = cols[0].trim();
        if (section_name && !importedSections.includes(section_name)) {
          importedSections.push(section_name);
        }

        const question_text = cols[1].trim();
        const options = [cols[2].trim(), cols[3].trim(), cols[4].trim(), cols[5].trim()];
        const correct_option_index = parseInt(cols[6].trim(), 10);
        const explanation = cols[7] ? cols[7].trim() : "";
        
        const posMarkRaw = cols[8] ? cols[8].trim() : "";
        const negMarkRaw = cols[9] ? cols[9].trim() : "";
        const positive_marks = posMarkRaw && !isNaN(parseFloat(posMarkRaw)) ? parseFloat(posMarkRaw) : undefined;
        const negative_marks = negMarkRaw && !isNaN(parseFloat(negMarkRaw)) ? parseFloat(negMarkRaw) : undefined;

        const newQ: Question = {
          id: Date.now() + Math.floor(Math.random() * 1000) + added,
          quiz_id: selectedQuizId,
          section_name,
          question_text,
          options,
          correct_option_index,
          explanation,
          positive_marks,
          negative_marks
        };

        newQuestionsList.push(newQ);
        added++;
      });

      setQuestions(prev => [...prev, ...newQuestionsList]);

      // Automatically register any imported sections back to the active quiz
      if (importedSections.length > 0) {
        setQuizzes(prev => prev.map(qz => {
          if (qz.id === selectedQuizId) {
            const existing = qz.sections ? qz.sections.split(",").map(s => s.trim()).filter(Boolean) : [];
            const merged = Array.from(new Set([...existing, ...importedSections]));
            return {
              ...qz,
              sections: merged.join(",")
            };
          }
          return qz;
        }));

        // Dynamically update form text field for editing
        setNewQuizSections(prev => {
          const existing = prev ? prev.split(",").map(s => s.trim()).filter(Boolean) : [];
          const merged = Array.from(new Set([...existing, ...importedSections]));
          return merged.join(",");
        });
      }

      setCsvUploadText("");
      setCsvDemoNotice(true);
      setTimeout(() => setCsvDemoNotice(false), 4000);
      alert(`Success: ${added} questions imported, auto-registered sections: ${importedSections.join(", ")}`);
    } catch (err) {
      alert("Error parsing CSV template. Please double check the column structures.");
    }
  };

  // Add sample placeholder for CSV testing
  const populateCSVSamplePlaceholder = () => {
    setCsvUploadText(
      "Quantitative Aptitude,A merchant marks an elegant accessory 40% above cost and offers 20% discount. What is his net gain percent?,20%,12%,15%,18%,1,Discount = 20% on 140% of Cost. Sell = 0.8 * 140 = 112%. Net gain is exactly 12%.\n" +
      "English Language,Choose the correctly spelt vocabulary option:,Inadvertent,Inadverttent,Inadvertant,Inadvertunt,0,The exact primary standard spelling is 'Inadvertent' which refers to unintentional actions."
    );
  };

  // Save new manually crafted quiz or update existing
  const handleSaveQuiz = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuizTitle.trim()) return;

    if (formMode === 'edit') {
      setQuizzes(prev => prev.map(qz => {
        if (qz.id === selectedQuizId) {
          return {
            ...qz,
            title: newQuizTitle,
            subject_code: newQuizSubjectCode,
            sections: newQuizSections,
            duration_mins: newQuizDuration,
            passing_score: newQuizPassing,
            positive_marks: newQuizPositive,
            negative_marks: newQuizNegative,
            starts_at: newQuizStartsAt,
            status: newQuizStatus,
            restrict_by_phone: newQuizRestrictByPhone,
            allowed_phones: newQuizAllowedPhones,
            section_settings: newQuizSectionSettings
          };
        }
        return qz;
      }));
      alert("Exam Settings successfully updated in the database!");
    } else {
      const nQuiz: Quiz = {
        id: Date.now(),
        title: newQuizTitle,
        subject_code: newQuizSubjectCode,
        sections: newQuizSections, // Starts empty (no sections by default)
        duration_mins: newQuizDuration,
        passing_score: newQuizPassing,
        positive_marks: newQuizPositive,
        negative_marks: newQuizNegative,
        starts_at: newQuizStartsAt,
        status: newQuizStatus,
        restrict_by_phone: newQuizRestrictByPhone,
        allowed_phones: newQuizAllowedPhones,
        section_settings: newQuizSectionSettings,
        created_at: new Date().toISOString().replace('T', ' ').substring(0, 19)
      };

      setQuizzes(prev => [nQuiz, ...prev]);
      setSelectedQuizId(nQuiz.id);
      setFormMode('edit');
      alert("WordPress database successfully provisioned with new exam definition!");
    }
  };

  const setNewEditingQFieldsToBlank = () => {
    setEditingQId(null);
    setNewQSection("");
    setNewQText("");
    setNewQOptions(["", "", "", ""]);
    setNewQOptionImages(["", "", "", ""]);
    setNewQCorrect(0);
    setNewQExplanation("");
    setNewQPositive("");
    setNewQNegative("");
    setNewQImage("");
  };

  // Save individual question manual form submit
  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQSection.trim()) {
      alert("Please provide or touch a valid Section Name for the question.");
      return;
    }
    const isOptionTextValid = newQOptions.every((opt, i) => {
      const hasText = opt && opt.trim() !== "";
      const hasImage = newQOptionImages[i] && newQOptionImages[i].trim() !== "";
      return hasText || hasImage;
    });
    if (!newQText.trim() || !isOptionTextValid) {
      alert("All questions must have a question stem. Each option must have either text, an uploaded image, or both.");
      return;
    }

    const trimmedSec = newQSection.trim();
    const pMarks = newQPositive.trim() && !isNaN(parseFloat(newQPositive)) ? parseFloat(newQPositive) : undefined;
    const nMarks = newQNegative.trim() && !isNaN(parseFloat(newQNegative)) ? parseFloat(newQNegative) : undefined;

    if (editingQId !== null) {
      setQuestions(prev => prev.map(q => {
        if (q.id === editingQId) {
          return {
            ...q,
            section_name: trimmedSec,
            question_text: newQText,
            options: [...newQOptions],
            correct_option_index: newQCorrect,
            explanation: newQExplanation,
            positive_marks: pMarks,
            negative_marks: nMarks,
            question_image: newQImage,
            option_images: [...newQOptionImages]
          };
        }
        return q;
      }));
      setEditingQId(null);
      alert(`Question updated successfully inside ${trimmedSec}!`);
    } else {
      const nQuestion: Question = {
        id: Date.now(),
        quiz_id: selectedQuizId,
        section_name: trimmedSec,
        question_text: newQText,
        options: [...newQOptions],
        correct_option_index: newQCorrect,
        explanation: newQExplanation,
        positive_marks: pMarks,
        negative_marks: nMarks,
        question_image: newQImage,
        option_images: [...newQOptionImages]
      };
      setQuestions(prev => [...prev, nQuestion]);
      alert(`New question logged in ${trimmedSec}!`);
    }

    // Automatically check if this section needs to be appended to the active quiz
    setQuizzes(prev => prev.map(qz => {
      if (qz.id === selectedQuizId) {
        const existing = qz.sections ? qz.sections.split(",").map(s => s.trim()).filter(Boolean) : [];
        if (!existing.includes(trimmedSec)) {
          const merged = [...existing, trimmedSec];
          return {
            ...qz,
            sections: merged.join(",")
          };
        }
      }
      return qz;
    }));

    // Align local state too
    setNewQuizSections(prev => {
      const existing = prev ? prev.split(",").map(s => s.trim()).filter(Boolean) : [];
      if (!existing.includes(trimmedSec)) {
        return [...existing, trimmedSec].join(",");
      }
      return prev;
    });

    setNewQText("");
    setNewQOptions(["", "", "", ""]);
    setNewQOptionImages(["", "", "", ""]);
    setNewQCorrect(0);
    setNewQExplanation("");
    setNewQPositive("");
    setNewQNegative("");
    setNewQImage("");
  };

  const handleBulkSectionChange = () => {
    if (!bulkEditSection) {
      alert("Please select a section first.");
      return;
    }
    const pos = bulkSectionPos.trim() === "" ? undefined : parseFloat(bulkSectionPos);
    const neg = bulkSectionNeg.trim() === "" ? undefined : parseFloat(bulkSectionNeg);
    
    setQuestions(prev => prev.map(q => {
      if (q.quiz_id === selectedQuizId && q.section_name === bulkEditSection) {
        return {
          ...q,
          positive_marks: pos === undefined || isNaN(pos) ? undefined : pos,
          negative_marks: neg === undefined || isNaN(neg) ? undefined : neg
        };
      }
      return q;
    }));
    alert(`Successfully updated marks for all questions in section: "${bulkEditSection}"`);
  };

  const handleBulkQNumberChange = () => {
    if (!bulkEditQNumber.trim()) {
      alert("Please enter a question number or range (e.g., 5, or 1-5, or 2,4,6).");
      return;
    }
    const pos = bulkQNumPos.trim() === "" ? undefined : parseFloat(bulkQNumPos);
    const neg = bulkQNumNeg.trim() === "" ? undefined : parseFloat(bulkQNumNeg);

    const activeQuizQuestions = questions.filter(q => q.quiz_id === selectedQuizId);
    if (activeQuizQuestions.length === 0) {
      alert("No questions found in this quiz.");
      return;
    }

    // Parse the input pattern
    const indicesToUpdate: number[] = [];
    const parts = bulkEditQNumber.split(",");
    
    parts.forEach(part => {
      const trimmed = part.trim();
      if (trimmed.includes("-")) {
        const range = trimmed.split("-");
        const start = parseInt(range[0].trim(), 10);
        const end = parseInt(range[1].trim(), 10);
        if (!isNaN(start) && !isNaN(end)) {
          for (let i = Math.min(start, end); i <= Math.max(start, end); i++) {
            indicesToUpdate.push(i - 1); // convert to 0-indexed
          }
        }
      } else {
        const single = parseInt(trimmed, 10);
        if (!isNaN(single)) {
          indicesToUpdate.push(single - 1); // convert to 0-indexed
        }
      }
    });

    // Extract the list of valid question IDs to update
    const targetIds = activeQuizQuestions
      .filter((_, idx) => indicesToUpdate.includes(idx))
      .map(q => q.id);

    if (targetIds.length === 0) {
      alert("No valid question numbers found matching your query in the current quiz.");
      return;
    }

    setQuestions(prev => prev.map(q => {
      if (targetIds.includes(q.id)) {
        return {
          ...q,
          positive_marks: pos === undefined || isNaN(pos) ? undefined : pos,
          negative_marks: neg === undefined || isNaN(neg) ? undefined : neg
        };
      }
      return q;
    }));

    alert(`Successfully updated marks for ${targetIds.length} question(s) by their numbers!`);
  };

  // Delete specific quiz and related parameters
  const handleDeleteQuiz = (id: number) => {
    if (confirm("Deleting this quiz from the WordPress DB will erase all of its questions and results. Proceed?")) {
      setQuizzes(prev => prev.filter(q => q.id !== id));
      setQuestions(prev => prev.filter(q => q.quiz_id !== id));
      setResults(prev => prev.filter(r => r.quiz_id !== id));
      if (selectedQuizId === id) {
        setSelectedQuizId(quizzes.find(q => q.id !== id)?.id || 0);
      }
    }
  };

  // Exam state launcher
  const initiateExamTake = () => {
    if (candQuizId === 0) {
      alert("No active, published examinations are available to take.");
      return;
    }
    if (!candName.trim()) {
      alert("Candidate Full Name is required to initialize security protocols.");
      return;
    }
    if (!candFatherName.trim()) {
      alert("Father's Name is required to initialize security protocols.");
      return;
    }
    if (!candPhone.trim()) {
      alert("Mobile Number is required to initialize security protocols.");
      return;
    }

    const quizObj = quizzes.find(q => q.id === candQuizId);
    if (quizObj && quizObj.restrict_by_phone === 1) {
      const cleanEnteredPhone = candPhone.replace(/\D/g, "");
      if (!cleanEnteredPhone) {
        alert("Please enter a valid mobile number.");
        return;
      }
      
      const allowedCSVString = quizObj.allowed_phones || "";
      const allowedList = allowedCSVString.replace(/[^\d,\+]/g, "").split(",").map(p => p.replace(/\D/g, "")).filter(Boolean);
      
      if (!allowedList.includes(cleanEnteredPhone)) {
        alert("Your mobile number is not registered for this examination. Please contact the administrator.");
        return;
      }

      // Check if student with this mobile number already completed this exam
      const alreadyTaken = results.some(r => r.quiz_id === candQuizId && r.candidate_phone && r.candidate_phone.replace(/\D/g, "") === cleanEnteredPhone);
      if (alreadyTaken) {
        alert("You have already given / participation completed for this exam using the registered mobile number.");
        return;
      }
    }

    const qCount = questions.filter(q => q.quiz_id === candQuizId).length;
    if (qCount === 0) {
      alert("Selected exam has target quiz ID with no questions. Please add questions first.");
      return;
    }

    setExamState('instructions');
  };

  const handleStartExamTimer = () => {
    const quizObj = quizzes.find(q => q.id === candQuizId);
    if (!quizObj) return;

    const valSeconds = quizObj.duration_mins * 60;
    setTotalSeconds(valSeconds);
    setSecondsLeft(valSeconds);
    setCheatWarnings(0);
    setCheatHistory([]);
    setCandAnswers({});
    
    // Auto populate status labels
    const tracker: Record<number, string> = {};
    const qList = questions.filter(q => q.quiz_id === candQuizId);
    qList.forEach(q => {
      tracker[q.id] = 'not-visited';
    });
    setPaletteStatus(tracker);
    setCurrQIndex(0);
    setExamState('active');
  };

  const triggerAutoSubmit = (forcedDq = false) => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    
    // Handle calculations
    const quizObj = quizzes.find(q => q.id === candQuizId);
    if (!quizObj) return;

    const qList = questions.filter(q => q.quiz_id === candQuizId);
    
    let score = 0;
    let correct = 0;
    let incorrect = 0;
    let unanswered = 0;

    const sScores: Record<string, { score: number, correct: number, incorrect: number, unanswered: number }> = {};

    qList.forEach(q => {
      const selected = candAnswers[q.id];
      const sec = q.section_name;
      
      if (!sScores[sec]) {
        sScores[sec] = { score: 0, correct: 0, incorrect: 0, unanswered: 0 };
      }

      const { positive, negative } = getQuestionMarks(q, quizObj);

      if (selected === undefined) {
        unanswered++;
        sScores[sec].unanswered++;
      } else if (selected === q.correct_option_index) {
        correct++;
        score += positive;
        sScores[sec].correct++;
        sScores[sec].score += positive;
      } else {
        incorrect++;
        score -= negative;
        sScores[sec].incorrect++;
        sScores[sec].score -= negative;
      }
    });

    if (forcedDq) {
      score = 0; // Forced disqualification triggers absolute zero marks
    }

    const nResult: Result = {
      id: Date.now(),
      quiz_id: candQuizId,
      candidate_name: candName,
      candidate_father_name: candFatherName,
      candidate_email: candEmail || "guest-assessment@domain.in",
      candidate_phone: candPhone,
      score,
      answers: { ...candAnswers },
      time_taken_seconds: totalSeconds - secondsLeft,
      cheating_alerts_count: forcedDq ? 3 : cheatWarnings,
      section_scores: sScores,
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 19).replace('Z', '')
    };

    setResults(prev => [nResult, ...prev]);
    setGradedResult(nResult);
    setShowCheatModal(false);
    setExamState('grading');
  };

  // Option select trigger inside CBT
  const handleSelectOptionInCBT = (qId: number, oIdx: number) => {
    setCandAnswers(prev => ({
      ...prev,
      [qId]: oIdx
    }));
    setPaletteStatus(prev => ({
      ...prev,
      [qId]: 'answered'
    }));
  };

  // Actions for CBT Bottom buttons
  const ctrlSaveAndNext = () => {
    const currentQ = activeExamQuestions[currQIndex];
    if (candAnswers[currentQ.id] === undefined) {
      setPaletteStatus(prev => ({ ...prev, [currentQ.id]: 'not-answered' }));
    } else {
      setPaletteStatus(prev => ({ ...prev, [currentQ.id]: 'answered' }));
    }

    if (currQIndex < activeExamQuestions.length - 1) {
      setCurrQIndex(prev => prev + 1);
    } else {
      alert("You have traversed all questions. Click Submit Examination when completed.");
    }
  };

  const ctrlMarkForReview = () => {
    const currentQ = activeExamQuestions[currQIndex];
    if (candAnswers[currentQ.id] === undefined) {
      setPaletteStatus(prev => ({ ...prev, [currentQ.id]: 'marked' }));
    } else {
      setPaletteStatus(prev => ({ ...prev, [currentQ.id]: 'answered-marked' }));
    }

    if (currQIndex < activeExamQuestions.length - 1) {
      setCurrQIndex(prev => prev + 1);
    }
  };

  const ctrlClearResponse = () => {
    const currentQ = activeExamQuestions[currQIndex];
    setCandAnswers(prev => {
      const next = { ...prev };
      delete next[currentQ.id];
      return next;
    });
    setPaletteStatus(prev => ({ ...prev, [currentQ.id]: 'not-answered' }));
  };

  // Convert seconds values to stopwatch
  const formatStopwatch = (sec: number) => {
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${hrs < 10 ? '0' + hrs : hrs}:${mins < 10 ? '0' + mins : mins}:${s < 10 ? '0' + s : s}`;
  };

  // Multi line code copy sequence
  const handleCopyClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopySuccess(selectedFile);
    setTimeout(() => setCopySuccess(null), 3000);
  };

  // Compile active zip archive
  const handleZipGeneration = async () => {
    setZippingState(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder("competitive-exam-quiz");

      if (folder) {
        // Core roots
        folder.file("competitive-exam-quiz.php", FILE_CONTENTS["competitive-exam-quiz.php"]);
        folder.file("readme.txt", FILE_CONTENTS["readme.txt"]);

        // includes/
        const incFolder = folder.folder("includes");
        if (incFolder) {
          incFolder.file("class-quiz-db.php", FILE_CONTENTS["includes/class-quiz-db.php"]);
          incFolder.file("class-quiz-ajax.php", FILE_CONTENTS["includes/class-quiz-ajax.php"]);
        }

        // admin/
        const adminFolder = folder.folder("admin");
        if (adminFolder) {
          adminFolder.file("class-quiz-admin.php", FILE_CONTENTS["admin/class-quiz-admin.php"]);
        }

        // public/
        const pubFolder = folder.folder("public");
        if (pubFolder) {
          pubFolder.file("class-quiz-public.php", FILE_CONTENTS["public/class-quiz-public.php"]);
          
          const cssFolder = pubFolder.folder("css");
          if (cssFolder) {
            cssFolder.file("quiz-style.css", FILE_CONTENTS["public/css/quiz-style.css"]);
          }

          const jsFolder = pubFolder.folder("js");
          if (jsFolder) {
            jsFolder.file("quiz-engine.js", FILE_CONTENTS["public/js/quiz-engine.js"]);
          }
        }
      }

      const content = await zip.generateAsync({ type: "blob" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(content);
      link.download = "competitive-exam-quiz.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      alert("ZIP assembly failed. Please copy source files manually.");
    } finally {
      setZippingState(false);
    }
  };

  // Generate jsPDF certificate reporting
  const handleClientPDFDownload = () => {
    if (!gradedResult) return;
    const currentQuiz = quizzes.find(q => q.id === gradedResult.quiz_id);
    if (!currentQuiz) return;

    const doc = new jsPDF("p", "mm", "a4");

    // 1. Double Border Frame
    // Outer border (thick dark blue)
    doc.setDrawColor(26, 54, 93);
    doc.setLineWidth(0.8);
    doc.rect(8, 8, 194, 281);

    // Inner border (thin orange/red)
    doc.setDrawColor(197, 48, 48);
    doc.setLineWidth(0.3);
    doc.rect(9.5, 9.5, 191, 278);

    // 2. MD DEFENCE ACADEMY Header Banner Block (Dark Blue)
    doc.setFillColor(26, 54, 93);
    doc.rect(12, 12, 186, 36, "F");

    doc.setTextColor(255, 255, 255);
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(20);
    doc.text("MD DEFENCE ACADEMY", 105, 21, { align: "center" });

    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9);
    doc.text("Apollo Road, Opposite Old Satsang Bhavan, Jind, Haryana (126102)", 105, 27, { align: "center" });

    doc.setFont("Helvetica", "bold");
    doc.setTextColor(255, 215, 0); // Gold/yellow color for primary contacts
    doc.text("Phone: +91 9991200989 | Email: mdsshighschool1991@gmail.com", 105, 33, { align: "center" });

    // 3. Sub-header bar "SCHOLASTIC ACADEMIC PERFORMANCE REPORT CARD"
    doc.setFillColor(235, 248, 255);
    doc.setDrawColor(144, 205, 244);
    doc.setLineWidth(0.3);
    doc.rect(12, 51, 186, 12, "FD");

    doc.setTextColor(26, 54, 93);
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(11);
    doc.text("SCHOLASTIC ACADEMIC PERFORMANCE REPORT CARD", 105, 58.5, { align: "center" });

    // 4. Candidate & Exam specifications block
    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.rect(12, 67, 186, 36, "FD");
    doc.line(105, 67, 105, 103); // Vertical divider

    // Left Column: Candidate Profile Records
    doc.setTextColor(221, 107, 32); // Orange title
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(10);
    doc.text("CANDIDATE PROFILE RECORDS", 15, 73);

    doc.setFontSize(9);
    doc.setTextColor(74, 85, 104);
    doc.setFont("Helvetica", "normal");
    doc.text("Candidate Name:", 15, 80);
    doc.text("Mobile Number:", 15, 86);
    doc.text("E-Mail Address:", 15, 92);

    doc.setTextColor(26, 32, 44);
    doc.setFont("Helvetica", "bold");
    doc.text(gradedResult.candidate_name, 48, 80);
    doc.text(gradedResult.candidate_phone || "+919462481088", 48, 86);
    doc.text(gradedResult.candidate_email, 48, 92);

    // Right Column: Examination Specifications
    doc.setTextColor(221, 107, 32);
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(10);
    doc.text("EXAMINATION SPECIFICATIONS", 108, 73);

    doc.setFontSize(9);
    doc.setTextColor(74, 85, 104);
    doc.setFont("Helvetica", "normal");
    doc.text("Assessed Title:", 108, 80);
    doc.text("Subject Code:", 108, 86);
    doc.text("Report Date:", 108, 92);

    doc.setTextColor(26, 32, 44);
    doc.setFont("Helvetica", "bold");
    doc.text(currentQuiz.title, 138, 80);
    doc.text(currentQuiz.subject_code || "CEQ-CBT-WP", 138, 86);
    doc.text(gradedResult.created_at ? new Date(gradedResult.created_at).toLocaleString() : new Date().toLocaleString(), 138, 92);

    // 5. Aggregate Status Card
    const passingScore = currentQuiz.passing_score || 33;
    const isPassed = gradedResult.score >= passingScore;

    if (isPassed) {
      doc.setFillColor(240, 255, 244); // Light Green
      doc.setDrawColor(198, 246, 213);
    } else {
      doc.setFillColor(255, 245, 245); // Light Pink
      doc.setDrawColor(254, 215, 215);
    }
    doc.setLineWidth(0.3);
    doc.rect(12, 107, 186, 36, "FD");
    doc.line(75, 107, 75, 143); // Compartment line

    // Left Compartment text
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(10);
    if (isPassed) {
      doc.setTextColor(34, 84, 61); // dark green
      doc.text("AGGREGATE STATUS", 43.5, 117, { align: "center" });
      doc.setFontSize(11);
      doc.text("PASSED / QUALIFIED", 43.5, 128, { align: "center" });
    } else {
      doc.setTextColor(116, 42, 42); // dark red
      doc.text("AGGREGATE STATUS", 43.5, 117, { align: "center" });
      doc.setFontSize(11);
      doc.text("FAILED / DID NOT QUALIFY", 43.5, 128, { align: "center" });
    }

    // Right Compartment text
    doc.setFontSize(9.5);
    doc.setTextColor(74, 85, 104);
    doc.setFont("Helvetica", "normal");
    doc.text("Final Points Obtained:", 80, 116);
    doc.text("Total Correct Keys:", 80, 124);
    doc.text("Incorrect Responses:", 80, 132);

    let correctTotal = 0;
    let incorrectTotal = 0;
    let unansweredTotal = 0;
    Object.values(gradedResult.section_scores).forEach((val: any) => {
      correctTotal += val.correct || 0;
      incorrectTotal += val.incorrect || 0;
      unansweredTotal += val.unanswered || 0;
    });

    doc.setTextColor(26, 32, 44);
    doc.setFont("Helvetica", "bold");
    doc.text(`${gradedResult.score} Marks`, 128, 116);
    doc.text(`${correctTotal} Questions Passed`, 128, 124);
    doc.text(`${incorrectTotal} Incorrect / ${unansweredTotal} Blank`, 128, 132);

    // 6. Section-wise scores table
    doc.setTextColor(26, 54, 93);
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(11);
    doc.text("SECTION-WISE LEDGER SUMMARY OF SCHOLASTIC SCORES", 12, 152);

    // Table Header
    doc.setFillColor(26, 54, 93);
    doc.rect(12, 156, 186, 8, "F");

    doc.setTextColor(255, 255, 255);
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(8.5);
    doc.text("SECTION GROUP", 15, 161.5);
    doc.text("CORRECT CHECKS", 95, 161.5, { align: "center" });
    doc.text("INCORRECT ATTEMPTS", 142, 161.5, { align: "center" });
    doc.text("SECTION SCORE", 192, 161.5, { align: "right" });

    // Table Rows
    let rY = 164;
    Object.entries(gradedResult.section_scores).forEach(([secName, val]: [string, any]) => {
      // Horizontal cell lines
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.2);
      doc.line(12, rY + 8.5, 198, rY + 8.5);

      doc.setTextColor(45, 55, 72);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(9);
      doc.text(secName, 15, rY + 5.5);

      doc.setFont("Helvetica", "normal");
      doc.text(String(val.correct || 0), 95, rY + 5.5, { align: "center" });
      doc.text(String(val.incorrect || 0), 142, rY + 5.5, { align: "center" });

      doc.setFont("Helvetica", "bold");
      doc.setTextColor(26, 54, 93);
      doc.text(`${val.score} Marks`, 192, rY + 5.5, { align: "right" });

      rY += 8.5;
    });

    // 7. Anti-cheat integrity block
    if (gradedResult.cheating_alerts_count > 0) {
      doc.setFillColor(255, 251, 235); // Light Yellow
      doc.setDrawColor(254, 243, 199);
      doc.rect(12, rY + 6, 186, 11, "FD");
      doc.setTextColor(180, 83, 9);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(8.5);
      doc.text("ANTI-CHEAT INTEGRITY STATUS:", 15, rY + 13.5);
      doc.text(`PROCTOR NOTICE: DETECTED ${gradedResult.cheating_alerts_count} SUSPICIOUS EVENT(S)`, 71, rY + 13.5);
    } else {
      doc.setFillColor(236, 253, 245); // Light Green
      doc.setDrawColor(209, 250, 229);
      doc.rect(12, rY + 6, 186, 11, "FD");
      doc.setTextColor(4, 120, 87);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(8.5);
      doc.text("ANTI-CHEAT INTEGRITY STATUS:", 15, rY + 13.5);
      doc.text("NO SUSPICIOUS ACTIVITIES DETECTED - SECURE & ETHICAL PARTICIPATION", 71, rY + 13.5);
    }

    // 8. Signatures Block
    doc.setDrawColor(74, 85, 104);
    doc.setLineWidth(0.4);
    // Draw sign rules
    doc.line(20, rY + 39, 80, rY + 39);
    doc.line(130, rY + 39, 190, rY + 39);

    doc.setTextColor(74, 85, 104);
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(9.5);
    doc.text("Exam Incharge's Sign", 50, rY + 44, { align: "center" });
    doc.text("Principal's Sign", 160, rY + 44, { align: "center" });

    doc.setFont("Helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(113, 128, 150);
    doc.text("(MD Defence Academy Seals)", 160, rY + 49, { align: "center" });

    doc.save(`ceq_report_card_${gradedResult.candidate_name.replace(/\s+/g, '_')}.pdf`);
  };

  // Grouped category list inside CBT exam taking simulator
  const activeSections = Array.from(new Set(activeExamQuestions.map(q => q.section_name)));
  const currentSection = activeExamQuestions[currQIndex]?.section_name || "";

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 flex flex-col antialiased">
      
      {/* GLOBAL NAVBAR */}
      <header className="bg-slate-900 text-white shadow-md border-b-4 border-amber-500 shrink-0">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-amber-500 text-slate-950 p-2 rounded-lg font-extrabold text-lg tracking-wider flex items-center justify-center shadow-md">
              CBT
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-white flex items-center gap-2">
                Competitive Exam Quiz System <span className="text-amber-400 text-xs px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 font-normal">WP Plugin Simulator</span>
              </h1>
              <p className="text-xs text-slate-400">SSC, UPSC, NTA style professional Online Exam CBT module for WordPress</p>
            </div>
          </div>

          <div className="flex bg-slate-800 p-1 rounded-lg border border-slate-700 overflow-x-auto max-w-full">
            <button 
              id="nav-btn-admin"
              onClick={() => { setAppMode('dashboard'); if (countdownRef.current) clearInterval(countdownRef.current); }}
              className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${appMode === 'dashboard' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700'}`}
            >
              <Settings className="w-3.5 h-3.5" /> Simulated wp-admin
            </button>
            <button 
              id="nav-btn-exam"
              onClick={() => setAppMode('candidate')}
              className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${appMode === 'candidate' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700'}`}
            >
              <FileText className="w-3.5 h-3.5" /> Candidate Exam Portal
            </button>
            <button 
              id="nav-btn-checker"
              onClick={() => { setAppMode('results_checker'); if (countdownRef.current) clearInterval(countdownRef.current); }}
              className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${appMode === 'results_checker' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700'}`}
            >
              <CheckCircle className="w-3.5 h-3.5" /> Check Online Results
            </button>
            <button 
              id="nav-btn-explorer"
              onClick={() => { setAppMode('explorer'); if (countdownRef.current) clearInterval(countdownRef.current); }}
              className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${appMode === 'explorer' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:text-white hover:bg-slate-700'}`}
            >
              <Code className="w-3.5 h-3.5" /> Source Code & Zip
            </button>
          </div>
        </div>
      </header>

      {/* CORE DISPLAY WINDOW */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 flex flex-col">
        
        {/* VIEW 1: WORDPRESS WP-ADMIN BACKEND DASHBOARD */}
        {appMode === 'dashboard' && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden min-h-[750px]">
            
            {/* WordPress Left Control Sidebar */}
            <div className="lg:col-span-1 bg-slate-900 text-slate-300 p-4 border-r border-slate-800 flex flex-col gap-1 shrink-0">
              <div className="p-2 bg-slate-850 rounded-lg border border-slate-800 mb-4 text-center">
                <span className="text-sm font-bold text-slate-100 flex items-center justify-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block animate-pulse"></span> WordPress Console
                </span>
                <p className="text-[10px] text-slate-400 mt-1">Simulated Administration</p>
              </div>

              <button 
                id="sidebar-quizzes"
                onClick={() => setAdminMenu('quizzes')}
                className={`w-full py-2 px-3 text-left rounded-md text-xs font-bold flex items-center gap-2.5 transition-all ${adminMenu === 'quizzes' ? 'bg-blue-600 text-white font-extrabold shadow-md' : 'hover:bg-slate-800 hover:text-white'}`}
              >
                <Layers className="w-4 h-4 shadow-sm" /> Active Exam Instances
              </button>

              <button 
                id="sidebar-questions"
                onClick={() => setAdminMenu('questions')}
                className={`w-full py-2 px-3 text-left rounded-md text-xs font-bold flex items-center gap-2.5 transition-all ${adminMenu === 'questions' ? 'bg-blue-600 text-white font-extrabold shadow-md' : 'hover:bg-slate-800 hover:text-white'}`}
              >
                <Plus className="w-4 h-4 shadow-sm" /> Question Manager & CSV
              </button>

              <button 
                id="sidebar-results"
                onClick={() => setAdminMenu('results')}
                className={`w-full py-2 px-3 text-left rounded-md text-xs font-bold flex items-center gap-2.5 transition-all ${adminMenu === 'results' ? 'bg-blue-600 text-white font-extrabold shadow-md' : 'hover:bg-slate-800 hover:text-white'}`}
              >
                <Archive className="w-4 h-4 shadow-sm" /> Performance & Rank Lists
              </button>

              <div className="mt-auto bg-slate-950 p-3 rounded-lg border border-slate-850 text-slate-400 text-xs">
                <h4 className="font-semibold text-slate-200">Shortcode Integration</h4>
                <p className="text-[11px] mt-1 text-slate-400 leading-relaxed">
                  Embed active tests inside real posts using:
                </p>
                <code className="block mt-2 p-1.5 bg-slate-900 text-yellow-400 rounded text-center text-[10px] font-mono border border-slate-800">
                  [competitive_quiz id="{selectedQuizId}"]
                </code>
              </div>
            </div>

            {/* WordPress Main Content Area */}
            <div className="lg:col-span-3 p-6 bg-slate-50 flex flex-col gap-6 overflow-y-auto">
              
              {/* ADMIN VIEW 1: QUIZZES AND PORTAL DETAILS */}
              {adminMenu === 'quizzes' && (
                <div id="admin-quizzes-view" className="flex flex-col gap-6">
                  {/* Info alert block */}
                  <div className="bg-slate-900 border-l-4 border-slate-600 p-4 text-white rounded shadow-md flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm">Competitive Exam Quiz Dashboard (WordPress Simulation)</h4>
                      <p className="text-xs text-slate-300 mt-1">
                        Configure exam parameters below. These controls simulate the WordPress back-end menu where you create test categories, set positive and negative markings, and manage time parameters.
                      </p>
                    </div>
                  </div>

                  {/* Top Creator Forms & Active Portals in WordPress */}
                  <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
                    {/* Creator/Editor box */}
                    <div className="xl:col-span-2 bg-white rounded-lg border border-slate-200 shadow-sm p-4 flex flex-col">
                      <div className="flex gap-2 p-1 bg-slate-100 rounded-md mb-3">
                        <button 
                          type="button"
                          onClick={() => {
                            setFormMode('create');
                            setNewQuizTitle("");
                            setNewQuizSubjectCode("");
                            setNewQuizSections("");
                            setNewQuizDuration(15);
                            setNewQuizPassing(33);
                            setNewQuizPositive(2);
                            setNewQuizNegative(0.5);
                            setNewQuizStartsAt("");
                            setNewQuizStatus('published');
                          }}
                          className={`flex-1 text-center font-bold text-[10px] py-1 px-2 rounded transition-all ${formMode === 'create' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600 hover:text-slate-950'}`}
                        >
                          ➕ Create New Mode
                        </button>
                        <button 
                          type="button"
                          onClick={() => {
                            setFormMode('edit');
                            const active = quizzes.find(q => q.id === selectedQuizId);
                            if (active) {
                              setNewQuizTitle(active.title);
                              setNewQuizSubjectCode(active.subject_code || "");
                              setNewQuizSections(active.sections || "");
                              setNewQuizDuration(active.duration_mins);
                              setNewQuizPassing(active.passing_score);
                              setNewQuizPositive(active.positive_marks);
                              setNewQuizNegative(active.negative_marks);
                              setNewQuizStartsAt(active.starts_at || "");
                              setNewQuizStatus(active.status || 'published');
                            }
                          }}
                          className={`flex-1 text-center font-bold text-[10px] py-1 px-2 rounded transition-all ${formMode === 'edit' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600 hover:text-slate-950'}`}
                        >
                          ✏️ Edit Selected Mode
                        </button>
                      </div>

                      <h3 className="font-bold text-sm text-slate-900 border-b pb-2 mb-3 flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <Plus className="w-4 h-4 text-blue-600" />
                          {formMode === 'edit' ? 'Edit Online Exam Settings' : 'Create Custom Online Exam'}
                        </span>
                        {formMode === 'edit' && (
                          <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-mono font-bold">
                            ID: {selectedQuizId.toString().substring(0, 4)}
                          </span>
                        )}
                      </h3>

                      <form onSubmit={handleSaveQuiz} className="flex flex-col gap-3">
                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">Exam Title *</label>
                          <input 
                            type="text" 
                            required 
                            placeholder="e.g. SSC General Aptitude Mock"
                            value={newQuizTitle}
                            onChange={e => setNewQuizTitle(e.target.value)}
                            className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-bold text-slate-600 mb-1">Subject Code</label>
                            <input 
                              type="text" 
                              placeholder="e.g. SSC-CGL-2026, CS-101"
                              value={newQuizSubjectCode}
                              onChange={e => setNewQuizSubjectCode(e.target.value)}
                              className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-600 mb-1">Duration (Mins)</label>
                            <input 
                              type="number" 
                              required 
                              min="1" 
                              value={newQuizDuration}
                              onChange={e => setNewQuizDuration(parseInt(e.target.value) || 15)}
                              className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">Exam Sections (comma-separated)</label>
                          <input 
                            type="text" 
                            placeholder="e.g. Physics, Chemistry, Maths"
                            value={newQuizSections}
                            onChange={e => setNewQuizSections(e.target.value)}
                            className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none"
                          />
                          <p className="text-[10px] text-slate-400 mt-1">Leave blank to start with no sections by default. Sections will be auto-generated upon importing CSV.</p>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">Scheduled Start Time (WordPress simulation)</label>
                          <input 
                            type="datetime-local" 
                            value={newQuizStartsAt}
                            onChange={e => setNewQuizStartsAt(e.target.value)}
                            className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none font-mono"
                          />
                          <p className="text-[10px] text-slate-400 mt-1">Leave blank for immediate availability, or select a future time to trigger count-down lock simulation.</p>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">Exam Status</label>
                          <select 
                            value={newQuizStatus}
                            onChange={e => setNewQuizStatus(e.target.value as 'published' | 'draft')}
                            className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none bg-white font-semibold text-slate-800"
                          >
                            <option value="published">🟢 Published</option>
                            <option value="draft">🔘 Draft</option>
                          </select>
                          <p className="text-[10px] text-slate-400 mt-1">Draft exams will be hidden from candidates but accessible to the administrator for questions/results editing.</p>
                        </div>

                        {/* PHONE RESTRICTION CONFIGURATION */}
                        <div className="border border-indigo-100 bg-indigo-50/50 p-3.5 rounded-lg flex flex-col gap-3">
                          <label className="flex items-center gap-2 cursor-pointer select-none">
                            <input 
                              type="checkbox"
                              checked={newQuizRestrictByPhone === 1}
                              onChange={e => setNewQuizRestrictByPhone(e.target.checked ? 1 : 0)}
                              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                            />
                            <span className="text-xs font-extrabold text-indigo-950">
                              Restrict by Pre-registered Mobile Numbers (Optional)
                            </span>
                          </label>
                          
                          {newQuizRestrictByPhone === 1 && (
                            <div className="flex flex-col gap-2">
                              <label className="block text-[10px] font-bold text-indigo-900">
                                Pre-registered Mobile Numbers (comma-separated or CSV list)
                              </label>
                              <textarea
                                value={newQuizAllowedPhones}
                                onChange={e => setNewQuizAllowedPhones(e.target.value)}
                                placeholder="e.g. 9876543210, +919999999999, 1234567890"
                                className="w-full text-xs p-2.5 border border-indigo-200 rounded outline-none font-mono bg-white min-h-[60px]"
                              />
                              <div className="flex items-center justify-between">
                                <span className="text-[10px] text-slate-500 font-medium">
                                  Allowed list: <strong>{newQuizAllowedPhones ? newQuizAllowedPhones.split(",").filter(Boolean).length : 0} numbers</strong>
                                </span>
                                <label className="text-[10px] text-indigo-600 font-bold hover:underline cursor-pointer">
                                  📂 Upload CSV File
                                  <input 
                                    type="file" 
                                    accept=".csv"
                                    className="hidden"
                                    onChange={e => {
                                      const file = e.target.files?.[0];
                                      if (file) {
                                        const reader = new FileReader();
                                        reader.onload = (evt) => {
                                          const text = evt.target?.result as string;
                                          if (text) {
                                            const matches = text.match(/[+\d]+/g);
                                            if (matches) {
                                              const cleaned = matches.map(m => m.trim()).filter(m => m.length >= 8);
                                              const uniq = Array.from(new Set(cleaned));
                                              setNewQuizAllowedPhones(uniq.join(", "));
                                              alert(`Parsed and imported ${uniq.length} allowed mobile numbers!`);
                                            } else {
                                              alert("Could not find any phone-like numbers in the selected CSV file.");
                                            }
                                          }
                                        };
                                        reader.readAsText(file);
                                      }
                                    }}
                                  />
                                </label>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-600 mb-1">Pass Mark %</label>
                            <input 
                              type="number" 
                              required 
                              min="0.1" 
                              max="100" 
                              value={newQuizPassing}
                              onChange={e => setNewQuizPassing(parseFloat(e.target.value) || 33)}
                              className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-600 mb-1">Correct Mark</label>
                            <input 
                              type="number" 
                              step="0.1" 
                              required 
                              value={newQuizPositive}
                              onChange={e => setNewQuizPositive(parseFloat(e.target.value) || 2)}
                              className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none text-green-700 font-bold"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-600 mb-1">Wrong Mark</label>
                            <input 
                              type="number" 
                              step="0.1" 
                              required 
                              value={newQuizNegative}
                              onChange={e => setNewQuizNegative(parseFloat(e.target.value) || 0.5)}
                              className="w-full text-xs p-2 border rounded focus:border-blue-500 outline-none text-red-700 font-bold"
                            />
                          </div>
                        </div>

                        {/* SECTION WISE DEFAULT OVERRIDES */}
                        {(() => {
                          const activeSecs = newQuizSections.split(",").map(s => s.trim()).filter(Boolean);
                          if (activeSecs.length === 0) return null;
                          
                          let parsedSectionScoreConf: Record<string, { positive_marks?: number, negative_marks?: number }> = {};
                          try {
                            if (newQuizSectionSettings) {
                              parsedSectionScoreConf = typeof newQuizSectionSettings === 'string' 
                                ? JSON.parse(newQuizSectionSettings) 
                                : newQuizSectionSettings;
                            }
                          } catch (ex) {}

                          const updateSecConf = (sec: string, key: 'positive_marks' | 'negative_marks', rawVal: string) => {
                            const clone = { ...parsedSectionScoreConf };
                            if (!clone[sec]) clone[sec] = {};
                            
                            const val = rawVal.trim() === "" ? undefined : parseFloat(rawVal);
                            if (val === undefined || isNaN(val)) {
                              delete clone[sec][key];
                            } else {
                              clone[sec][key] = val;
                            }

                            if (clone[sec].positive_marks === undefined && clone[sec].negative_marks === undefined) {
                              delete clone[sec];
                            }
                            setNewQuizSectionSettings(JSON.stringify(clone));
                          };

                          return (
                            <div className="border border-indigo-100 bg-indigo-50/20 p-3.5 rounded-lg flex flex-col gap-2">
                              <span className="text-xs font-extrabold text-indigo-950 flex items-center justify-between">
                                <span>Section-Wise Default Marks Override (Optional)</span>
                                <span className="text-[10px] font-normal text-slate-500">Overrules general Correct/Wrong marks</span>
                              </span>
                              
                              <p className="text-[9px] text-slate-500 leading-relaxed mb-1">
                                Enter custom marks specifically for individual exam sections. Leave fields blank to inherit general correct/wrong marks.
                              </p>

                              <div className="flex flex-col gap-2 max-h-48 overflow-y-auto pr-1">
                                {activeSecs.map(secName => {
                                  const config = parsedSectionScoreConf[secName] || {};
                                  return (
                                    <div key={secName} className="flex items-center justify-between gap-3 bg-white p-2 border border-slate-100 rounded shadow-sm">
                                      <span className="text-[11px] font-bold text-slate-700 truncate w-1/2" title={secName}>
                                        📁 {secName}
                                      </span>
                                      
                                      <div className="flex items-center gap-1.5 w-1/2 justify-end">
                                        <div className="flex items-center gap-1">
                                          <span className="text-[10px] text-green-700 font-extrabold">+</span>
                                          <input 
                                            type="number"
                                            step="0.1"
                                            placeholder={`Inherit (${newQuizPositive})`}
                                            value={config.positive_marks ?? ""}
                                            onChange={e => updateSecConf(secName, 'positive_marks', e.target.value)}
                                            className="w-16 p-1 border rounded text-[11px] text-center font-bold text-green-700 placeholder-slate-400 outline-none focus:ring-1 focus:ring-indigo-400"
                                          />
                                        </div>
                                        <div className="flex items-center gap-1">
                                          <span className="text-[10px] text-red-650 font-extrabold">-</span>
                                          <input 
                                            type="number"
                                            step="0.1"
                                            placeholder={`Inherit (${newQuizNegative})`}
                                            value={config.negative_marks ?? ""}
                                            onChange={e => updateSecConf(secName, 'negative_marks', e.target.value)}
                                            className="w-16 p-1 border rounded text-[11px] text-center font-bold text-red-650 placeholder-slate-400 outline-none focus:ring-1 focus:ring-indigo-400"
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })()}

                        <button 
                          type="submit"
                          className={`w-full text-white font-bold py-2 px-4 rounded text-xs transition duration-150 shadow-sm ${formMode === 'edit' ? 'bg-amber-600 hover:bg-amber-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                        >
                          {formMode === 'edit' ? 'Update Selected Exam' : 'Register New WP Exam Instance'}
                        </button>
                      </form>
                    </div>

                    {/* Active Portals table */}
                    <div className="xl:col-span-3 bg-white rounded-lg border border-slate-200 shadow-sm p-4 flex flex-col">
                      <h3 className="font-bold text-sm text-slate-900 border-b pb-2 mb-3 flex items-center justify-between">
                        <span className="flex items-center gap-2"><List className="w-4 h-4 text-blue-600" /> Active Mock Portals</span>
                        <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded font-normal text-slate-500">Live database sync</span>
                      </h3>

                      <div className="overflow-x-auto">
                        <table className="w-full text-xs text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-105 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                              <th className="py-2 px-2 text-[10px] text-center w-12">ID</th>
                              <th className="py-2 px-2">Exam Title</th>
                              <th className="py-2 px-2 text-center w-14">Time</th>
                              <th className="py-2 px-2 text-center w-16">Marking</th>
                              <th className="py-2 px-2 text-center w-24">Shortcode</th>
                              <th className="py-2 px-2 text-center w-12">Trash</th>
                            </tr>
                          </thead>
                          <tbody>
                            {quizzes.map(qz => (
                              <tr 
                                key={qz.id} 
                                className={`border-b border-slate-100 hover:bg-slate-50 transition cursor-pointer ${selectedQuizId === qz.id ? 'bg-blue-50 border-l-4 border-l-blue-600' : ''}`}
                                onClick={() => {
                                  setSelectedQuizId(qz.id);
                                  setFormMode('edit');
                                }}
                              >
                                <td className="py-2.5 px-2 text-slate-400 text-center font-mono">{qz.id.toString().substring(0, 4)}</td>
                                <td className="py-2.5 px-2">
                                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                                    {qz.title}
                                  </div>
                                  <div className="flex flex-wrap gap-1.5 mt-1 text-[10px] items-center text-slate-500">
                                    {qz.status === 'draft' ? (
                                      <span className="bg-slate-200 text-slate-800 font-bold px-1.5 py-0.5 border border-slate-300 rounded">
                                        🔘 Draft
                                      </span>
                                    ) : (
                                      <span className="bg-green-100 text-green-800 font-bold px-1.5 py-0.5 border border-green-200 rounded">
                                        🟢 Published
                                      </span>
                                    )}
                                    {qz.subject_code && (
                                      <span className="bg-slate-105 text-slate-700 px-1 py-0.5 rounded border border-slate-200 font-mono">
                                        Subject: {qz.subject_code}
                                      </span>
                                    )}
                                    <span className="text-[10px] bg-sky-50 text-sky-850 border border-sky-100 rounded px-1.5 py-0.5">
                                      Sections: {qz.sections ? qz.sections : "None (empty by default)"}
                                    </span>
                                    {qz.starts_at && (
                                      <span className="text-[10px] bg-amber-50 text-amber-800 border border-amber-200 rounded px-1.5 py-0.5 font-semibold">
                                        🕒 Schedule: {qz.starts_at.replace('T', ' ')}
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="py-2.5 px-2 text-center text-slate-600">{qz.duration_mins}m</td>
                                <td className="py-2.5 px-2 text-center text-[11px] font-mono">
                                  <span className="text-green-700 font-bold">+{qz.positive_marks}</span>/
                                  <span className="text-red-650 font-bold">-{qz.negative_marks}</span>
                                </td>
                                <td className="py-2.5 px-2 text-center">
                                  <code className="bg-slate-100 text-blue-850 px-1.5 py-0.5 rounded text-[10px] font-mono">
                                    [ceq id={qz.id.toString().substring(0,2)}]
                                  </code>
                                </td>
                                <td className="py-2.5 px-2 text-center" onClick={(e) => e.stopPropagation()}>
                                  <button 
                                    onClick={() => handleDeleteQuiz(qz.id)}
                                    className="p-1 text-slate-400 hover:text-red-500 rounded hover:bg-red-50 transition-colors"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      <div className="mt-4 p-3 bg-blue-50 rounded border border-blue-100 text-[11px] text-blue-900 leading-relaxed">
                        <strong>Simulation hint:</strong> Click on any exam row above to change the target exam for the Question Manager and Results tabs on this simulated WP control panel!
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ADMIN VIEW 2: QUESTION MANAGER & CSV IMPORTERS */}
              {adminMenu === 'questions' && (
                <div id="admin-questions-view" className="flex flex-col gap-6">
                  
                  {/* Selector Header Bar */}
                  <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div>
                      <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Currently Managing Quest Data</span>
                      <h3 className="font-extrabold text-slate-800 text-base">
                        {quizzes.find(q => q.id === selectedQuizId)?.title || "Select an active test"}
                      </h3>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-600">Select Exam Context:</span>
                      <select 
                        value={selectedQuizId} 
                        onChange={e => {
                          setSelectedQuizId(parseInt(e.target.value) || 1);
                          setFormMode('edit');
                        }}
                        className="text-xs p-1.5 border rounded bg-white font-semibold text-slate-800 outline-none"
                      >
                        {quizzes.map(qz => (
                          <option key={qz.id} value={qz.id}>
                            {qz.title} {qz.status === 'draft' ? ' (Draft)' : ''}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
                    {/* CSV Importer & Manual Form Left Columns */}
                    <div className="xl:col-span-2 flex flex-col gap-6">
                      
                      {/* CSV upload simulation */}
                      <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
                        <h3 className="font-bold text-sm text-slate-900 border-b pb-2 mb-3 flex items-center justify-between">
                          <span className="flex items-center gap-2"><UploadCloud className="w-4 h-4 text-blue-600" /> Excel/CSV Importer Simulator</span>
                          <button 
                            onClick={populateCSVSamplePlaceholder}
                            className="text-[10px] text-blue-600 font-bold hover:underline"
                          >
                            Generate Template
                          </button>
                        </h3>

                        <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
                          Paste raw comma-separated rows below inside the simulation, then click Import. Columns order represents: 
                          <code className="text-blue-800 font-semibold block bg-slate-50 p-1 rounded font-mono text-[9px] mt-1 text-center">
                            Section Name, Question text, Option 1, Option 2, Option 3, Option 4, Correct Option Index (0-3), Explanation
                          </code>
                        </p>

                        <div className="flex flex-col gap-2">
                          <textarea 
                            rows={4} 
                            placeholder="Paste CSV contents here..."
                            value={csvUploadText}
                            onChange={e => setCsvUploadText(e.target.value)}
                            className="w-full text-xs p-2 font-mono border rounded outline-none h-24 focus:border-blue-500"
                          />
                          
                          <button 
                            onClick={handleCSVImportSim}
                            className="bg-slate-900 text-white font-bold py-1.5 rounded text-xs hover:bg-slate-800 transition"
                          >
                            Simulate CSV Questions Load
                          </button>

                          {csvDemoNotice && (
                            <div className="mt-2 bg-green-50 border border-green-200 p-2 text-green-800 text-[11px] rounded text-center">
                              ✔ Questions parsed successfully and added to the selected Exam!
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Manual Form Component */}
                      <div id="manual-question-form-scroll-anchor" className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 scroll-mt-6">
                        <div className="flex justify-between items-center border-b pb-2 mb-3">
                          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                            {editingQId !== null ? (
                              <>
                                <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" /> Edit Question Entry
                              </>
                            ) : (
                              <>
                                <Plus className="w-4 h-4 text-blue-600" /> Manual Question Entry
                              </>
                            )}
                          </h3>
                          {editingQId !== null && (
                            <button
                              type="button"
                              onClick={() => {
                                setNewEditingQFieldsToBlank();
                              }}
                              className="text-[10px] text-red-600 hover:text-red-800 font-extrabold uppercase border border-red-200 bg-red-50/50 hover:bg-red-50 px-2 py-0.5 rounded cursor-pointer"
                            >
                              Cancel Edit
                            </button>
                          )}
                        </div>

                        <form onSubmit={handleSaveQuestion} className="flex flex-col gap-3">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 uppercase">Section Name *</label>
                            <input 
                              type="text" 
                              required
                              placeholder="e.g. General Intelligence, History"
                              value={newQSection}
                              onChange={e => setNewQSection(e.target.value)}
                              className="w-full text-xs p-1.5 border rounded outline-none focus:border-blue-500 font-medium"
                            />
                            {(() => {
                              const activeQ = quizzes.find(q => q.id === selectedQuizId);
                              const sList = activeQ?.sections ? activeQ.sections.split(',').map(s => s.trim()).filter(Boolean) : [];
                              if (sList.length > 0) {
                                return (
                                  <div className="mt-1 flex flex-wrap gap-1 items-center">
                                    <span className="text-[9px] text-slate-400 font-semibold mr-1">Existing sections (click to select):</span>
                                    {sList.map(sec => (
                                      <button
                                        key={sec}
                                        type="button"
                                        onClick={() => setNewQSection(sec)}
                                        className={`text-[9px] font-bold px-2 py-0.5 rounded transition ${newQSection === sec ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                                      >
                                        {sec}
                                      </button>
                                    ))}
                                  </div>
                                );
                              } else {
                                return (
                                  <p className="text-[10px] text-slate-400 mt-1 font-normal uppercase-none normal-case">This quiz starts with no sections by default. Type a section name to assign one, or load a CSV file to import sections automatically.</p>
                                );
                              }
                            })()}
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 uppercase">Question Text *</label>
                            <textarea 
                              required 
                              rows={2} 
                              placeholder="Type question stem..."
                              value={newQText}
                              onChange={e => setNewQText(e.target.value)}
                              className="w-full text-xs p-2 border rounded outline-none focus:border-blue-500"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            {newQOptions.map((opt, i) => (
                              <div key={i} className="bg-slate-50/50 p-2 rounded border border-slate-200 flex flex-col gap-1.5">
                                <div>
                                  <label className="block text-[10px] font-bold text-slate-500">Option {String.fromCharCode(65 + i)} Text</label>
                                  <input 
                                    type="text" 
                                    placeholder={`Option ${String.fromCharCode(65 + i)} text`}
                                    value={opt}
                                    onChange={e => {
                                      const next = [...newQOptions];
                                      next[i] = e.target.value;
                                      setNewQOptions(next);
                                    }}
                                    className="w-full text-xs p-1.5 bg-white border rounded outline-none focus:border-blue-500"
                                  />
                                </div>
                                <div className="mt-0.5">
                                  <label className="block text-[9px] font-bold text-slate-400 flex justify-between items-center">
                                    <span>Option {String.fromCharCode(65 + i)} Image (URL/Base64)</span>
                                    {newQOptionImages[i] && (
                                      <button 
                                        type="button" 
                                        onClick={() => {
                                          const next = [...newQOptionImages];
                                          next[i] = "";
                                          setNewQOptionImages(next);
                                        }}
                                        className="text-[8px] text-red-500 hover:underline cursor-pointer uppercase font-extrabold"
                                      >
                                        Delete Image
                                      </button>
                                    )}
                                  </label>
                                  <div className="flex gap-1 items-center mt-0.5">
                                    <input 
                                      type="text" 
                                      placeholder="https://example.com/image.jpg"
                                      value={newQOptionImages[i] || ""}
                                      onChange={e => {
                                        const next = [...newQOptionImages];
                                        next[i] = e.target.value;
                                        setNewQOptionImages(next);
                                      }}
                                      className="flex-1 text-[10px] p-1 bg-white border rounded outline-none focus:border-blue-500 font-mono"
                                    />
                                    <label className="bg-blue-50 hover:bg-blue-100 text-[10px] text-blue-700 font-bold px-2 py-1 rounded border border-blue-200 cursor-pointer text-center select-none whitespace-nowrap">
                                      Upload File
                                      <input 
                                        type="file" 
                                        accept="image/*" 
                                        className="hidden" 
                                        onChange={e => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            const rdr = new FileReader();
                                            rdr.onload = () => {
                                              const next = [...newQOptionImages];
                                              next[i] = rdr.result as string;
                                              setNewQOptionImages(next);
                                            };
                                            rdr.readAsDataURL(file);
                                          }
                                        }}
                                      />
                                    </label>
                                  </div>
                                  {newQOptionImages[i] && (
                                    <div className="mt-1 bg-white p-1 rounded border border-slate-100 max-w-fit shadow-xs">
                                      <img src={newQOptionImages[i]} className="max-h-20 max-w-full rounded object-contain" alt="" />
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase">Correct option index</label>
                              <select 
                                value={newQCorrect}
                                onChange={e => setNewQCorrect(parseInt(e.target.value) || 0)}
                                className="w-full text-xs p-1.5 border rounded outline-none m-0 focus:border-blue-500 font-bold"
                              >
                                <option value={0}>Option A</option>
                                <option value={1}>Option B</option>
                                <option value={2}>Option C</option>
                                <option value={3}>Option D</option>
                              </select>
                            </div>

                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase">Explanation helper text</label>
                              <input 
                                type="text"
                                placeholder="Why this option is correct..."
                                value={newQExplanation}
                                onChange={e => setNewQExplanation(e.target.value)}
                                className="w-full text-xs p-1.5 border rounded outline-none focus:border-blue-500"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 uppercase">Question Image URL or Base64 (Optional)</label>
                            <div className="flex gap-2">
                              <input 
                                type="text"
                                placeholder="e.g. https://domain.com/image.png or upload below..."
                                value={newQImage}
                                onChange={e => setNewQImage(e.target.value)}
                                className="flex-1 text-xs p-1.5 border rounded outline-none focus:border-blue-500 font-semibold"
                              />
                              <label className="bg-slate-100 border border-slate-200 hover:bg-slate-200 text-slate-700 text-[10px] px-2.5 py-1.5 rounded cursor-pointer font-bold select-none text-center">
                                Upload File
                                <input 
                                  type="file" 
                                  accept="image/*"
                                  className="hidden" 
                                  onChange={e => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onload = (evt) => {
                                        if (evt.target?.result) {
                                          setNewQImage(evt.target.result as string);
                                        }
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  }}
                                />
                              </label>
                            </div>
                            {newQImage && (
                              <div className="mt-2 text-center bg-slate-50 border p-1.5 rounded relative inline-block">
                                <img src={newQImage} className="max-h-20 rounded" alt="Preview Question Image" />
                                <button 
                                  type="button" 
                                  onClick={() => setNewQImage("")} 
                                  className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full p-1 text-[8px] font-bold line-height-none"
                                >
                                  ✕
                                </button>
                              </div>
                            )}
                          </div>

                          {/* OPTIONAL QUESTION-SPECIFIC MARKS OVERRIDE */}
                          <div className="border border-purple-100 bg-purple-50/25 p-3 rounded-md grid grid-cols-2 gap-2.5">
                            <div className="col-span-2">
                              <span className="text-[10px] font-extrabold text-purple-950 uppercase block">
                                Question-Specific Marks Override (Optional)
                              </span>
                              <span className="text-[9px] text-zinc-500">
                                Leave blank to automatically inherit the section-specific or general correct / wrong marks.
                              </span>
                            </div>
                            
                            <div>
                              <label className="block text-[9px] font-bold text-purple-800">Custom Positive Mark</label>
                              <input 
                                type="number"
                                step="0.1"
                                placeholder="Inherit default"
                                value={newQPositive}
                                onChange={e => setNewQPositive(e.target.value)}
                                className="w-full text-xs p-1.5 border border-purple-200 bg-white rounded outline-none focus:ring-1 focus:ring-purple-400 font-bold text-green-700"
                              />
                            </div>

                            <div>
                              <label className="block text-[9px] font-bold text-purple-800">Custom Wrong Mark Penalty</label>
                              <input 
                                type="number"
                                step="0.1"
                                placeholder="Inherit default"
                                value={newQNegative}
                                onChange={e => setNewQNegative(e.target.value)}
                                className="w-full text-xs p-1.5 border border-purple-200 bg-white rounded outline-none focus:ring-1 focus:ring-purple-400 font-bold text-red-600"
                              />
                            </div>
                          </div>

                          <button 
                            type="submit"
                            className={`font-semibold py-2 rounded text-xs transition shadow-sm text-white ${editingQId !== null ? 'bg-amber-600 hover:bg-amber-700 font-extrabold text-[11px] uppercase tracking-wide' : 'bg-blue-600 hover:bg-blue-700'}`}
                          >
                            {editingQId !== null ? "Update Question Entry" : "Save Question to Bank"}
                          </button>
                        </form>
                      </div>

                    </div>

                    {/* Question Inventory Right Columns */}
                    <div className="xl:col-span-3 bg-white rounded-lg border border-slate-200 shadow-sm p-4 flex flex-col">
                      <h3 className="font-bold text-sm text-slate-900 border-b pb-2 mb-3 flex items-center justify-between">
                        <span className="flex items-center gap-2"><List className="w-4 h-4 text-blue-600" /> Active Question Bank ({activeQuizQuestions.length} Questions)</span>
                      </h3>

                      {/* BULK MARKS MANAGEMENT PANEL */}
                      {activeQuizQuestions.length > 0 && (
                        <div className="bg-slate-50 border border-slate-200/80 rounded-lg p-3.5 mb-4 flex flex-col gap-3">
                          <div className="flex items-center gap-1.5 border-b border-slate-200 pb-1.5 justify-between">
                            <div className="flex items-center gap-1.5">
                              <span className="bg-blue-600 text-white px-1.5 py-0.5 rounded text-[8px] uppercase font-black tracking-wide">Bulk Tool</span>
                              <span className="text-xs font-extrabold text-slate-800">Dynamic Score Override Manager</span>
                            </div>
                            <span className="text-[10px] font-mono text-slate-400">Quiz ID: CEQ-{selectedQuizId}</span>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Panel 1: By Section */}
                            <div className="bg-white p-3 rounded border border-slate-150 flex flex-col gap-2">
                              <span className="text-[11px] font-black uppercase text-indigo-950 block">🏷️ Overrides By Section</span>
                              <p className="text-[9px] text-slate-500 leading-tight">Modify marks of all questions belonging to a specific section.</p>
                              
                              <div className="flex flex-col gap-1.5 mt-1">
                                <label className="text-[9px] font-bold text-slate-600">Select Section</label>
                                <select
                                  value={bulkEditSection}
                                  onChange={e => setBulkEditSection(e.target.value)}
                                  className="w-full text-xs p-1.5 border rounded outline-none m-0 bg-white"
                                >
                                  <option value="">-- Select Section --</option>
                                  {Array.from(new Set(activeQuizQuestions.map(q => q.section_name))).filter(Boolean).map(sec => (
                                    <option key={sec} value={sec}>{sec}</option>
                                  ))}
                                </select>
                              </div>

                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <label className="text-[9px] font-bold text-green-700 block">Correct (+) Marks</label>
                                  <input 
                                    type="number"
                                    step="0.1"
                                    placeholder="Inherit standard"
                                    value={bulkSectionPos}
                                    onChange={e => setBulkSectionPos(e.target.value)}
                                    className="w-full text-xs p-1 border rounded text-center font-bold text-green-750 outline-none"
                                  />
                                </div>
                                <div>
                                  <label className="text-[9px] font-bold text-red-600 block">Wrong (-) Penalty</label>
                                  <input 
                                    type="number"
                                    step="0.1"
                                    placeholder="Inherit standard"
                                    value={bulkSectionNeg}
                                    onChange={e => setBulkSectionNeg(e.target.value)}
                                    className="w-full text-xs p-1 border rounded text-center font-bold text-red-650 outline-none"
                                  />
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={handleBulkSectionChange}
                                className="w-full bg-indigo-600 hover:bg-indigo-750 text-white font-bold text-[9px] py-2 rounded transition uppercase mt-1 tracking-wider shadow-sm"
                              >
                                Apply Section Overrides
                              </button>
                            </div>

                            {/* Panel 2: By Question Numbers */}
                            <div className="bg-white p-3 rounded border border-slate-150 flex flex-col gap-2">
                              <span className="text-[11px] font-black uppercase text-purple-950 block">🔢 Overrides By Question Numbers</span>
                              <p className="text-[9px] text-slate-500 leading-tight">Modify marks for single numbers or ranges, e.g., <strong>5</strong>, <strong>1-10</strong>, or <strong>2,4,6</strong></p>

                              <div className="flex flex-col gap-1.5 mt-1">
                                <label className="text-[9px] font-bold text-slate-600">Define Question No.(s)</label>
                                <input 
                                  type="text"
                                  placeholder="e.g. 5 or 1-10 or 3,5,7"
                                  value={bulkEditQNumber}
                                  onChange={e => setBulkEditQNumber(e.target.value)}
                                  className="w-full text-xs p-1.5 border rounded outline-none font-mono"
                                />
                              </div>

                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <label className="text-[9px] font-bold text-green-700 block">Correct (+) Marks</label>
                                  <input 
                                    type="number"
                                    step="0.1"
                                    placeholder="Inherit standard"
                                    value={bulkQNumPos}
                                    onChange={e => setBulkQNumPos(e.target.value)}
                                    className="w-full text-xs p-1 border rounded text-center font-bold text-green-750 outline-none"
                                  />
                                </div>
                                <div>
                                  <label className="text-[9px] font-bold text-red-600 block">Wrong (-) Penalty</label>
                                  <input 
                                    type="number"
                                    step="0.1"
                                    placeholder="Inherit standard"
                                    value={bulkQNumNeg}
                                    onChange={e => setBulkQNumNeg(e.target.value)}
                                    className="w-full text-xs p-1 border rounded text-center font-bold text-red-650 outline-none"
                                  />
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={handleBulkQNumberChange}
                                className="w-full bg-purple-600 hover:bg-purple-750 text-white font-bold text-[9px] py-2 rounded transition uppercase mt-1 tracking-wider shadow-sm"
                              >
                                Apply Spec Q# Overrides
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      <div className="flex-1 overflow-y-auto max-h-[600px] border border-slate-100 rounded p-1 divide-y divide-slate-100">
                        {activeQuizQuestions.length === 0 ? (
                          <div className="text-center p-12 text-slate-400">
                            <AlertCircle className="w-8 h-8 text-slate-350 mx-auto mb-2" />
                            <p className="text-xs">No questions loaded in this exam context yet.</p>
                            <p className="text-[10px] mt-1 text-slate-400">Add questions or paste simulated CSV to inspect the grid.</p>
                          </div>
                        ) : (
                          activeQuizQuestions.map((q, idx) => (
                            <div key={q.id} className="py-3">
                              <div className="flex justify-between items-start gap-2 mb-1">
                                <span className="bg-blue-50 text-blue-700 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                                  {q.section_name}
                                </span>
                                <div className="flex items-center gap-1.5">
                                  {(() => {
                                    const activeQz = quizzes.find(qz => qz.id === selectedQuizId);
                                    if (activeQz) {
                                      const { positive, negative } = getQuestionMarks(q, activeQz);
                                      const isQuestionOverride = q.positive_marks !== undefined;
                                      return (
                                        <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded border ${
                                          isQuestionOverride 
                                            ? 'bg-purple-50 text-purple-700 border-purple-200' 
                                            : 'bg-slate-50 text-slate-600 border-slate-200'
                                        }`}>
                                          Marks: +{positive}/-{negative} {isQuestionOverride && "★"}
                                        </span>
                                      );
                                    }
                                    return null;
                                  })()}
                                  <span className="text-[10px] font-mono font-bold text-slate-400">
                                    Q# {idx + 1}
                                  </span>
                                </div>
                              </div>
                              <p className="text-xs font-bold text-slate-900 leading-relaxed mb-2">
                                {q.question_text}
                              </p>
                              {q.question_image && (
                                <div className="mb-3 max-w-xs border border-slate-200 rounded p-1 bg-slate-50">
                                  <img 
                                    src={q.question_image} 
                                    alt="Question Visual" 
                                    className="max-h-24 rounded object-contain" 
                                    referrerPolicy="no-referrer"
                                  />
                                </div>
                              )}
                              <div className="grid grid-cols-2 gap-2 text-[11px] pl-3 border-l-2 border-slate-200 mb-2">
                                {q.options.map((opt, oIdx) => (
                                  <div 
                                    key={oIdx} 
                                    className={`${oIdx === q.correct_option_index ? 'text-green-600 font-bold' : 'text-slate-500'} flex flex-col gap-1`}
                                  >
                                    <div>{String.fromCharCode(65 + oIdx)}. {opt || "No Text (Visual Option)"} {oIdx === q.correct_option_index && " ✔"}</div>
                                    {q.option_images?.[oIdx] && (
                                      <div className="border border-slate-100 rounded p-0.5 bg-slate-50 max-w-fit mt-0.5">
                                        <img src={q.option_images[oIdx]} className="max-h-14 max-w-full rounded object-contain" referrerPolicy="no-referrer" />
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                              {q.explanation && (
                                <div className="bg-slate-50 p-2 border-l border-amber-500 text-[10px] text-slate-600 rounded mb-2">
                                  <strong>Explanation:</strong> {q.explanation}
                                </div>
                              )}

                              {/* INLINE QUESTION MARKS MANUAL OVERRIDE */}
                              <div className="bg-purple-50/40 p-2 rounded border border-purple-100 flex flex-wrap items-center justify-between gap-2.5 text-[11px]">
                                <span className="font-extrabold text-purple-950 uppercase text-[9px] tracking-wide">Q# {idx + 1} Marks:</span>
                                <div className="flex items-center gap-2">
                                  <div className="flex items-center gap-1">
                                    <span className="text-[10px] font-bold text-green-700">+</span>
                                    <input 
                                      type="number"
                                      step="0.1"
                                      placeholder="Inherit"
                                      value={q.positive_marks ?? ""}
                                      onChange={e => {
                                        const val = e.target.value.trim() === "" ? undefined : parseFloat(e.target.value);
                                        setQuestions(prev => prev.map(item => {
                                          if (item.id === q.id) {
                                            return { ...item, positive_marks: val !== undefined && !isNaN(val) ? val : undefined };
                                          }
                                          return item;
                                        }));
                                      }}
                                      className="w-16 p-0.5 bg-white border border-purple-200 rounded text-[11px] font-bold text-green-700 text-center outline-none focus:ring-1 focus:ring-purple-450"
                                    />
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <span className="text-[10px] font-bold text-red-600">-</span>
                                    <input 
                                      type="number"
                                      step="0.1"
                                      placeholder="Inherit"
                                      value={q.negative_marks ?? ""}
                                      onChange={e => {
                                        const val = e.target.value.trim() === "" ? undefined : parseFloat(e.target.value);
                                        setQuestions(prev => prev.map(item => {
                                          if (item.id === q.id) {
                                            return { ...item, negative_marks: val !== undefined && !isNaN(val) ? val : undefined };
                                          }
                                          return item;
                                        }));
                                      }}
                                      className="w-16 p-0.5 bg-white border border-purple-200 rounded text-[11px] font-bold text-red-600 text-center outline-none focus:ring-1 focus:ring-purple-450"
                                    />
                                  </div>
                                  
                                  {/* Edit Details Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setEditingQId(q.id);
                                      setNewQSection(q.section_name);
                                      setNewQText(q.question_text);
                                      setNewQOptions([...q.options]);
                                      setNewQCorrect(q.correct_option_index);
                                      setNewQExplanation(q.explanation || "");
                                      setNewQPositive(q.positive_marks !== undefined ? String(q.positive_marks) : "");
                                      setNewQNegative(q.negative_marks !== undefined ? String(q.negative_marks) : "");
                                      setNewQImage(q.question_image || "");
                                      setNewQOptionImages(q.option_images ? [...q.option_images] : ["", "", "", ""]);
                                      document.getElementById("manual-question-form-scroll-anchor")?.scrollIntoView({ behavior: 'smooth' });
                                    }}
                                    className="ml-1 text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-[9px] font-bold px-2 py-1 rounded cursor-pointer select-none"
                                    title="Edit Question details"
                                  >
                                    Edit Details
                                  </button>

                                  {/* Delete Question Helper Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (confirm(`Are you sure you want to remove Question #${idx + 1}?`)) {
                                        setQuestions(prev => prev.filter(item => item.id !== q.id));
                                      }
                                    }}
                                    className="ml-1 text-red-500 hover:text-red-700 p-1 cursor-pointer hover:bg-red-50 rounded"
                                    title="Delete this question from bank"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>

                </div>
              )}

              {/* ADMIN VIEW 3: RESULTS AND LEADERBOARDS */}
              {adminMenu === 'results' && (
                <div id="admin-results-view" className="flex flex-col gap-6">
                  
                  {/* Results filter */}
                  <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div>
                      <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Audit Assessment Submissions</span>
                      <h3 className="font-extrabold text-slate-800 text-base">
                        {quizzes.find(q => q.id === selectedQuizId)?.title || "Select an active test"}
                      </h3>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <select 
                        value={selectedQuizId} 
                        onChange={e => {
                          setSelectedQuizId(parseInt(e.target.value) || 1);
                          setFormMode('edit');
                        }}
                        className="text-xs p-1.5 border rounded bg-white font-semibold text-slate-800 outline-none"
                      >
                        {quizzes.map(qz => (
                          <option key={qz.id} value={qz.id}>
                            {qz.title} {qz.status === 'draft' ? ' (Draft)' : ''}
                          </option>
                        ))}
                      </select>

                      <button 
                        onClick={() => {
                          const matchingResults = results.filter(r => r.quiz_id === selectedQuizId);
                          if (matchingResults.length === 0) {
                            alert("No records to export.");
                            return;
                          }
                          const csvLines = [
                            "Name,Email,Score,Time Taken,Warns logged",
                            ...matchingResults.map(r => `${r.candidate_name},${r.candidate_email},${r.score},${r.time_taken_seconds}s,${r.cheating_alerts_count}`)
                          ].join("\n");
                          
                          const blob = new Blob([csvLines], { type: "text/csv" });
                          const link = document.createElement("a");
                          link.href = URL.createObjectURL(blob);
                          link.download = `ceq-results-${selectedQuizId}.csv`;
                          link.click();
                        }}
                        className="bg-slate-900 border border-slate-800 text-white font-bold py-1.5 px-3 rounded text-xs hover:bg-slate-800 flex items-center gap-1 transition"
                      >
                        <Download className="w-3.5 h-3.5" /> Simulated CSV Export
                      </button>
                    </div>
                  </div>

                  {/* Submission lists table */}
                  <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
                    <h3 className="font-bold text-sm text-slate-900 border-b pb-2 mb-3 flex items-center justify-between">
                      <span className="flex items-center gap-2">👤 Candidate Submissions & Anti-Cheat Records</span>
                      <span className="text-[10px] bg-red-50 text-red-600 font-bold px-2 py-0.5 rounded">Active telemetry audit logger</span>
                    </h3>

                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left border-collapse">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                            <th className="py-2.5 px-3">Candidate name</th>
                            <th className="py-2.5 px-3">Email Address</th>
                            <th className="py-2.5 px-3 text-center">Score Obtained</th>
                            <th className="py-2.5 px-3 text-center">Duration</th>
                            <th className="py-2.5 px-3 text-center">Anti-Cheat Flags</th>
                            <th className="py-2.5 px-3 text-center">Certification</th>
                          </tr>
                        </thead>
                        <tbody>
                          {results.filter(r => r.quiz_id === selectedQuizId).length === 0 ? (
                            <tr>
                              <td colSpan={6} className="text-center py-10 text-slate-400">
                                No candidate assessment submissions logged for this exam instance.
                              </td>
                            </tr>
                          ) : (
                            results.filter(r => r.quiz_id === selectedQuizId).map(row => {
                              const activeQuiz = quizzes.find(q => q.id === selectedQuizId);
                              const hasPassed = activeQuiz ? (row.score >= activeQuiz.passing_score) : false;
                              return (
                                <tr key={row.id} className="border-b border-slate-100 hover:bg-slate-50">
                                  <td className="py-3 px-3 font-bold text-slate-900">
                                    <div>{row.candidate_name}</div>
                                    {row.candidate_father_name && <div className="text-[10px] text-slate-400 font-normal">S/O: {row.candidate_father_name}</div>}
                                  </td>
                                  <td className="py-3 px-3 text-slate-500 font-mono text-[10px]">{row.candidate_email}</td>
                                  <td className="py-3 px-3 text-center">
                                    <span className={`font-extrabold ${hasPassed ? 'text-green-600' : 'text-red-500'}`}>
                                      {row.score} pts
                                    </span>
                                    <span className="block text-[9px] text-slate-400">{hasPassed ? "PASSED" : "FAILED"}</span>
                                  </td>
                                  <td className="py-3 px-3 text-center text-slate-650">{formatStopwatch(row.time_taken_seconds)}</td>
                                  <td className="py-3 px-3 text-center">
                                    {row.cheating_alerts_count > 0 ? (
                                      <span className="p-1 px-2 text-[10px] bg-red-100 text-red-700 rounded font-bold">
                                        ⚠ {row.cheating_alerts_count} blur warnings
                                      </span>
                                    ) : (
                                      <span className="text-green-600 font-bold">✔ Secured</span>
                                    )}
                                  </td>
                                  <td className="py-3 px-3 text-center">
                                    <button 
                                      onClick={() => {
                                        setGradedResult(row);
                                        setTimeout(() => handleClientPDFDownload(), 100);
                                      }}
                                      className="text-blue-600 hover:underline text-[10px] font-bold"
                                    >
                                      Compile Cert
                                    </button>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

            </div>
          </div>
        )}

        {/* VIEW 2: HIGH-FIDELITY CANDIDATE EXAM PORTAL CBT OVERLAY */}
        {appMode === 'candidate' && (
          <div className="flex-1 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden min-h-[750px] flex flex-col">
            
            {/* INSTRUCTIONS SCREEN */}
            {examState === 'setup' && (
              <div className="flex-1 max-w-lg mx-auto w-full flex flex-col justify-center py-10 px-6 gap-6">
                <div className="text-center">
                  <span className="inline-block p-3 bg-blue-100 rounded-full text-blue-600 mb-2">
                    <User className="w-8 h-8" />
                  </span>
                  <h3 className="text-xl font-black text-slate-900 border-b pb-2 mb-1 uppercase tracking-tight">SSC/NTA CBT Exam Entry</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">Enter candidate details and verify subject options to load examination instructions sheets.</p>
                </div>

                <div className="bg-slate-50 p-5 rounded-lg border border-slate-200 flex flex-col gap-4">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">Candidate Full Name *</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Rahul Pandey"
                      value={candName}
                      onChange={e => setCandName(e.target.value)}
                      className="w-full text-xs p-2.5 border rounded outline-none bg-white font-bold text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">Father's Name *</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Anand Pandey"
                      value={candFatherName}
                      onChange={e => setCandFatherName(e.target.value)}
                      className="w-full text-xs p-2.5 border rounded outline-none bg-white font-bold text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">Candidate Email Identifier</label>
                    <input 
                      type="email" 
                      placeholder="rahulpandey7392@gmail.com"
                      value={candEmail}
                      onChange={e => setCandEmail(e.target.value)}
                      className="w-full text-xs p-2.5 border rounded outline-none bg-white text-slate-800 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">Mobile Number *</label>
                    <input 
                      type="tel" 
                      placeholder="e.g. 9876543210 (or matching CSV allowed number)"
                      value={candPhone}
                      onChange={e => setCandPhone(e.target.value)}
                      className="w-full text-xs p-2.5 border rounded outline-none bg-white font-bold text-slate-800"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1">Select Examination Subject</label>
                      <select 
                        value={candQuizId}
                        onChange={e => setCandQuizId(parseInt(e.target.value) || 0)}
                        className="w-full text-xs p-2.5 border rounded bg-white outline-none font-semibold text-slate-800"
                      >
                        {quizzes.filter(q => q.status !== 'draft').map(qz => (
                          <option key={qz.id} value={qz.id}>{qz.title}</option>
                        ))}
                        {quizzes.filter(q => q.status !== 'draft').length === 0 && (
                          <option value="0">❌ No Published Exams Available</option>
                        )}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1">Exam Language</label>
                      <select 
                        value={candLang}
                        onChange={e => setCandLang(e.target.value as "EN" | "HI")}
                        className="w-full text-xs p-2.5 border rounded bg-white outline-none font-semibold text-slate-800"
                      >
                        <option value="EN">English</option>
                        <option value="HI">Hindi / हिंदी</option>
                      </select>
                    </div>
                  </div>

                  {candCountdown && (
                    <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-3 text-center shadow-sm">
                      <span className="block text-xs font-bold text-blue-800 uppercase tracking-wider mb-1">🕒 Scheduled Examination Portal</span>
                      <span className="block text-xs text-slate-600 mb-2 font-medium">This exam is scheduled for a specific time. Countdown:</span>
                      <div className="font-mono text-xl font-black text-blue-900 bg-white border border-blue-100 rounded-md py-1.5 px-4 inline-block tracking-widest shadow-inner">
                        {candCountdown}
                      </div>
                    </div>
                  )}

                  <button 
                    onClick={initiateExamTake}
                    disabled={candCountdown !== null}
                    className={`w-full text-white font-extrabold text-sm py-2 px-4 rounded transition duration-155 shadow-md ${candCountdown !== null ? 'bg-slate-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'}`}
                  >
                    {candCountdown !== null ? 'Waiting for Scheduled Start...' : 'Acknowledge & Proceed Steps'}
                  </button>
                </div>
              </div>
            )}

            {/* FULL DETAILED INSTRUCTION LIST */}
            {examState === 'instructions' && (
              <div className="flex-1 p-6 flex flex-col gap-6 overflow-y-auto">
                <div className="bg-slate-900 text-white p-4 rounded-t-lg flex items-center justify-between border-b-4 border-blue-500">
                  <h3 className="font-extrabold text-white text-base">General Instructions for Online Examination</h3>
                  <span className="text-xs font-mono font-bold text-amber-400 uppercase bg-slate-800 border border-slate-700 py-1 px-2.5 rounded">
                    Subject: {quizzes.find(q => q.id === candQuizId)?.title}
                  </span>
                </div>

                <div className="flex-1 bg-white p-6 border rounded-b-lg shadow-sm leading-relaxed text-sm text-slate-700 flex flex-col gap-4">
                  <h4 className="font-bold text-slate-900 text-sm">Please review the active protocol constraints carefully prior to initializing live clocks:</h4>
                  <ol className="list-decimal pl-5 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <li className="bg-slate-50 p-2.5 rounded border border-slate-100">
                      <strong>Countdown Timer:</strong> The server timer defaults to <strong>{quizzes.find(q => q.id === candQuizId)?.duration_mins} Minutes</strong>. The running timer shows remaining counts on the top right-hand side.
                    </li>
                    <li className="bg-slate-50 p-2.5 rounded border border-slate-100 text-red-600 font-semibold border-red-200">
                      <strong>Automatic Submit Action:</strong> When the countdown hit 00:00:00, the system automatically submits all answer values logged up to that exact interval.
                    </li>
                    <li className="bg-slate-50 p-2.5 rounded border border-slate-100 col-span-1 md:col-span-2">
                      <strong className="text-slate-900 block mb-1">Grading Schema & Section-wise Marks:</strong>
                      <p className="text-[11px] text-slate-600 mb-2">
                        Each question awards standard positive marks (e.g. up to <strong className="text-green-600">+{quizzes.find(q => q.id === candQuizId)?.positive_marks} Marks</strong>). Incorrect answers trigger a penalty (e.g. <strong className="text-red-600">-{quizzes.find(q => q.id === candQuizId)?.negative_marks} Marks</strong>). Unanswered answers carry zero penalty. If custom section-wise guidelines or specific question overrides apply, they will govern as listed below:
                      </p>
                      {(() => {
                        const activeQz = quizzes.find(q => q.id === candQuizId);
                        if (!activeQz) return null;
                        
                        let secRules: Record<string, { positive_marks?: string | number; negative_marks?: string | number }> = {};
                        if (activeQz.section_settings) {
                          try {
                            secRules = typeof activeQz.section_settings === 'string' 
                              ? JSON.parse(activeQz.section_settings) 
                              : activeQz.section_settings;
                          } catch (e) {
                            console.error("Failed to parse section settings:", e);
                          }
                        }

                        const sectionNames = Array.from(new Set(
                          questions.filter(q => q.quiz_id === candQuizId).map(q => q.section_name)
                        )).filter(Boolean);

                        if (sectionNames.length === 0 && Object.keys(secRules).length === 0) {
                          return (
                            <div className="bg-white p-2 border rounded text-[11px] font-mono text-slate-500">
                              Standard Marking Schema: +{activeQz.positive_marks} (Correct) | -{activeQz.negative_marks} (Wrong) applies uniformly.
                            </div>
                          );
                        }

                        // Merge section names from questions and settings JSON
                        const allSections: string[] = Array.from(new Set([
                          ...sectionNames,
                          ...Object.keys(secRules)
                        ])).filter(Boolean) as string[];

                        return (
                          <div className="overflow-x-auto mt-2 border border-slate-200 rounded max-h-[220px]">
                            <table className="w-full text-left text-[11px] border-collapse bg-white">
                              <thead>
                                <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-extrabold sticky top-0">
                                  <th className="p-1.5 px-3">Section Name</th>
                                  <th className="p-1.5 px-3 text-center text-green-700">Correct (+) Marks</th>
                                  <th className="p-1.5 px-3 text-center text-red-600">Wrong (-) Penalty</th>
                                </tr>
                              </thead>
                              <tbody>
                                {allSections.map(secName => {
                                  const secConf = secRules[secName] || {};
                                  const pos = secConf.positive_marks !== undefined && secConf.positive_marks !== null && secConf.positive_marks !== ""
                                    ? Number(secConf.positive_marks) 
                                    : activeQz.positive_marks;
                                  const neg = secConf.negative_marks !== undefined && secConf.negative_marks !== null && secConf.negative_marks !== ""
                                    ? Number(secConf.negative_marks) 
                                    : activeQz.negative_marks;

                                  return (
                                    <tr key={secName} className="border-b last:border-0 hover:bg-slate-50/50">
                                      <td className="p-1.5 px-3 font-bold text-slate-800">{secName}</td>
                                      <td className="p-1.5 px-3 text-center text-green-700 font-extrabold font-mono">+{pos}</td>
                                      <td className="p-1.5 px-3 text-center text-red-600 font-extrabold font-mono">-{neg}</td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        );
                      })()}
                    </li>
                    <li className="bg-slate-50 p-2.5 rounded border border-slate-100 text-orange-700 border-orange-200 font-bold">
                      <strong>Anti-Cheat Active (Strike Limits):</strong> Window blur actions (minimize, clicking on another browser app, or closing tabs) trigger automated log warning alert banners on client screen. <strong>Exceeding 3 blur warning events triggers automatic test foreclosure (zero marking disqualification).</strong>
                    </li>
                  </ol>

                  <div className="border bg-amber-50 p-4 border-amber-200 rounded text-amber-900 text-xs mt-4">
                    <strong>Acknowledge Box:</strong> By clicking the button below, you confirm that your hardware is secure, your tab switching blur triggers are verified, and you are ready to undergo SSC CBT assessment standards under strict monitoring.
                  </div>

                  <div className="flex items-center gap-3 mt-4">
                    <button 
                      onClick={() => setExamState('setup')}
                      className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-2 px-6 rounded text-xs transition"
                    >
                      Go Back
                    </button>
                    <button 
                      onClick={handleStartExamTimer}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-2 px-8 rounded text-xs transition shadow-md uppercase tracking-wider text-center"
                    >
                      Acknowledge & Start Live-Test
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* LIVE THE CBT WORKSPACE */}
            {examState === 'active' && activeExamQuestions.length > 0 && (
              <div className="flex-1 flex flex-col min-h-[600px] bg-slate-100 overflow-hidden" style={{ contentVisibility: "auto" }}>
                
                {/* Header info */}
                <div className="bg-white border-b border-slate-200 p-4 shrink-0 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xs">
                  <div>
                    <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-tight flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" /> {quizzes.find(q => q.id === candQuizId)?.title}
                    </h2>
                    <span className="text-[10px] bg-red-100 text-red-600 font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                      ● Examination Shield Logs Active
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                    <span className="text-slate-400">Duration: {quizzes.find(q => q.id === candQuizId)?.duration_mins}m</span>
                    <span className="h-4 w-px bg-slate-200 inline-block"></span>
                    <div className="flex items-center gap-2 px-4 py-2 border border-red-200 bg-red-50 text-red-700 font-mono text-base font-extrabold rounded-lg shadow-inner">
                      <Timer className="w-5 h-5 text-red-600 animate-pulse" /> {formatStopwatch(secondsLeft)}
                    </div>
                  </div>
                </div>

                {/* Section selection bar on front-end CBT */}
                <div className="bg-blue-750 shrink-0 border-b-4 border-slate-900 text-white flex items-center overflow-x-auto">
                  {activeSections.map((sec, idx) => (
                    <button 
                      key={idx}
                      onClick={() => {
                        const targetIdx = activeExamQuestions.findIndex(q => q.section_name === sec);
                        if (targetIdx !== -1) setCurrQIndex(targetIdx);
                      }}
                      className={`px-4 py-3 text-xs font-extrabold tracking-wide border-r border-slate-900 transition-colors uppercase whitespace-nowrap ${currentSection === sec ? 'bg-slate-900 text-white border-b-2 border-b-yellow-400 font-black' : 'text-slate-300 hover:text-white hover:bg-slate-900/30'}`}
                    >
                      {sec}
                    </button>
                  ))}
                </div>

                {/* Core CBT Layout Splitted columns */}
                <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 overflow-hidden">
                  
                  {/* Left Column Questionnaire panel */}
                  <div className="lg:col-span-3 bg-white p-6 flex flex-col justify-between overflow-y-auto border-r border-slate-200">
                    <div>
                      {/* Q badge number header */}
                      <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                        <span id="cbt-q-number" className="text-sm font-black text-slate-900 uppercase">
                          Question No. {currQIndex + 1}
                        </span>
                        
                        {(() => {
                          const quizObj = quizzes.find(q => q.id === candQuizId);
                          if (!quizObj) return null;
                          const qObj = activeExamQuestions[currQIndex];
                          const { positive, negative } = getQuestionMarks(qObj, quizObj);
                          const isOverride = qObj.positive_marks !== undefined;
                          return (
                            <div className="flex items-center gap-2 text-[10px]">
                              <span className="bg-green-50 text-green-700 border border-green-200 px-2.5 py-0.5 rounded font-extrabold uppercase">
                                Correct: +{positive}
                              </span>
                              <span className="bg-red-50 text-red-600 border border-red-200 px-2.5 py-0.5 rounded font-extrabold uppercase">
                                Incorrect: -{negative}
                              </span>
                              {isOverride && (
                                <span className="bg-purple-50 text-purple-700 border border-purple-200 px-2 py-0.5 rounded font-black text-[9px] uppercase">
                                  Override
                                </span>
                              )}
                            </div>
                          );
                        })()}
                      </div>

                      {/* Question Text */}
                      <div className="text-sm font-bold text-slate-800 leading-relaxed mb-6">
                        <div>{activeExamQuestions[currQIndex].question_text}</div>
                        {activeExamQuestions[currQIndex].question_image && (
                          <div className="mt-4 p-2 bg-slate-50 border border-slate-200 rounded-lg inline-block">
                            <img 
                              src={activeExamQuestions[currQIndex].question_image} 
                              alt="Question Attachment" 
                              className="max-h-[250px] max-w-full rounded object-contain" 
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                      </div>

                      {/* Options lists */}
                      <div className="flex flex-col gap-3">
                        {activeExamQuestions[currQIndex].options.map((optionText, oIdx) => {
                          const questionId = activeExamQuestions[currQIndex].id;
                          const isSelected = candAnswers[questionId] === oIdx;
                          return (
                            <button
                              key={oIdx}
                              onClick={() => handleSelectOptionInCBT(questionId, oIdx)}
                              className={`w-full py-3 px-4 rounded-lg text-left text-xs border transition duration-100 flex items-start gap-4 ${isSelected ? 'bg-blue-50 border-blue-600 font-extrabold shadow-xs text-blue-900' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300'}`}
                            >
                              <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] shadow-sm shrink-0 ${isSelected ? 'bg-blue-600 text-white' : 'bg-white text-slate-400 border border-slate-200'}`}>
                                {String.fromCharCode(65 + oIdx)}
                              </span>
                              <div className="flex-1 flex flex-col gap-1.5">
                                {optionText && <span>{optionText}</span>}
                                {activeExamQuestions[currQIndex].option_images?.[oIdx] && (
                                  <div className="p-1 border border-slate-200 bg-white rounded-lg inline-block w-fit shadow-xs">
                                    <img 
                                      src={activeExamQuestions[currQIndex].option_images[oIdx]} 
                                      alt="" 
                                      className="max-h-[140px] max-w-full rounded object-contain" 
                                      referrerPolicy="no-referrer"
                                    />
                                  </div>
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* CBT bottom row actions */}
                    <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <button 
                          onClick={ctrlMarkForReview}
                          className="flex-1 sm:flex-initial bg-indigo-650 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded text-xs tracking-wider transition-colors"
                        >
                          Mark for Review & Next
                        </button>
                        <button 
                          onClick={ctrlClearResponse}
                          className="flex-1 sm:flex-initial bg-slate-250 hover:bg-slate-350 text-slate-700 border border-slate-200 font-bold py-2 px-4 rounded text-xs tracking-wider transition-colors"
                        >
                          Clear Response
                        </button>
                      </div>

                      <button 
                        onClick={ctrlSaveAndNext}
                        className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white font-extrabold py-2 px-8 rounded text-xs tracking-wider transition-colors shadow"
                      >
                        Save & Next
                      </button>
                    </div>
                  </div>

                  {/* Right Column CBT Palette indices */}
                  <div className="lg:col-span-1 bg-slate-50 p-4 flex flex-col justify-between overflow-y-auto">
                    <div>
                      {/* Mock avatar panel */}
                      <div className="bg-white border rounded-lg p-3 flex items-center gap-3 mb-4 shadow-xs">
                        <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center font-black text-slate-600 shadow-inner">
                          👤
                        </div>
                        <div>
                          <h4 className="font-extrabold text-xs text-slate-900 truncate max-w-[150px]">{candName}</h4>
                          <small className="text-[10px] text-slate-400 block font-mono">Lang: {candLang === "EN" ? "English" : "Hindi"}</small>
                        </div>
                      </div>

                      {/* Status Legends matrix info */}
                      <div className="bg-white border border-slate-200 p-2.5 rounded-lg grid grid-cols-2 gap-1.5 text-[10px] mb-4 shadow-xxs">
                        <div className="flex items-center gap-1.5 font-bold text-slate-600">
                          <span className="w-6 h-5 bg-slate-100 border text-slate-500 rounded flex items-center justify-center font-bold">0</span> Not Visited
                        </div>
                        <div className="flex items-center gap-1.5 font-bold text-slate-650">
                          <span className="w-6 h-5 bg-red-500 text-white border-none rounded flex items-center justify-center font-bold">0</span> Not Answered
                        </div>
                        <div className="flex items-center gap-1.5 font-bold text-slate-650">
                          <span className="w-6 h-5 bg-green-500 text-white border-none rounded flex items-center justify-center font-bold">0</span> Answered
                        </div>
                        <div className="flex items-center gap-1.5 font-bold text-slate-650">
                          <span className="w-6 h-5 bg-purple-600 text-white border-none rounded flex items-center justify-center font-bold">0</span> Marked
                        </div>
                        <div className="flex items-center gap-1.5 font-bold text-slate-650 col-span-2">
                          <span className="w-6 h-5 bg-purple-600 text-white border-none rounded flex items-center justify-center font-bold relative">0<span className="absolute bottom-0 right-0 w-1.5 h-1.5 bg-green-500 rounded-full"></span></span> Answered & Marked
                        </div>
                      </div>

                      {/* Grid lists index */}
                      <div className="bg-white border border-slate-200 p-3 rounded-lg flex flex-col gap-2 shadow-xxs">
                        <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block border-b pb-1">Question Palette</span>
                        
                        <div className="grid grid-cols-4 gap-1.5 overflow-y-auto max-h-[180px] p-0.5">
                          {activeExamQuestions.map((q, idx) => {
                            const status = paletteStatus[q.id] || 'not-visited';
                            let statusClasses = "bg-slate-100 text-slate-500 border border-slate-250";
                            if (status === 'answered') statusClasses = "bg-green-500 text-white border-none";
                            if (status === 'not-answered') statusClasses = "bg-red-500 text-white border-none";
                            if (status === 'marked') statusClasses = "bg-purple-600 text-white border-none";
                            if (status === 'answered-marked') statusClasses = "bg-purple-600 text-white border-none relative";

                            const highlightBorder = currQIndex === idx ? "ring-2 ring-yellow-400 ring-offset-1 font-black transform scale-105" : "";

                            return (
                              <button
                                key={q.id}
                                onClick={() => setCurrQIndex(idx)}
                                className={`h-8 font-extrabold text-[11px] rounded transition duration-75 flex items-center justify-center ${statusClasses} ${highlightBorder}`}
                              >
                                {idx + 1}
                                {status === 'answered-marked' && (
                                  <span className="absolute bottom-0.5 right-0.5 w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Final submit section block */}
                    <div className="border-t border-slate-200 pt-3 mt-4">
                      <button 
                        onClick={() => {
                          const c = confirm(`Are you sure you want to finalize your exam sheet?\n\nQuestions Solved: ${Object.keys(candAnswers).length} / ${activeExamQuestions.length}\n\nPress OK to submit score card.`);
                          if (c) triggerAutoSubmit();
                        }}
                        className="w-full bg-blue-650 hover:bg-blue-700 text-white font-extrabold text-xs py-2 px-3 rounded shadow transition uppercase tracking-wider"
                      >
                        Submit Examination
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* RESULTS REPORT CARD AND CLIENT PDF DOWNLOAD */}
            {examState === 'grading' && gradedResult && (
              <div className="flex-1 p-6 flex flex-col gap-6 overflow-y-auto justify-center bg-slate-50 items-center">
                <div className="max-w-2xl w-full bg-white rounded-lg border border-slate-200 shadow-lg overflow-hidden">
                  
                  {/* Status Banner */}
                  <div className="bg-slate-900 border-b-4 border-amber-500 p-5 text-center text-white">
                    <span className="text-xl font-black text-amber-400 block tracking-widest uppercase">
                      🎉 ASSESSMENT RECORD COMPLETED 🎉
                    </span>
                    <p className="text-xs text-slate-400 mt-1">Simulated WordPress assessment node results logs generated instantly.</p>
                  </div>

                  <div className="p-6 flex flex-col gap-6 leading-relaxed">
                    <div className="flex items-center justify-between border-b pb-3 gap-4 flex-wrap">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Candidate profile logged</span>
                        <h4 className="font-extrabold text-slate-800 text-base">{gradedResult.candidate_name}</h4>
                        <span className="text-[11px] font-mono text-slate-500">{gradedResult.candidate_email}</span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Final status result</span>
                        <span className={`text-[11px] font-extrabold px-3 py-1 rounded inline-block ${gradedResult.score >= (quizzes.find(q => q.id === candQuizId)?.passing_score || 33) ? 'bg-green-100 text-green-800' : 'bg-red-105 text-red-700'}`}>
                          {gradedResult.score >= (quizzes.find(q => q.id === candQuizId)?.passing_score || 33) ? "PASSED (QUALIFIED)" : "FAILED (NOT QUALIFIED)"}
                        </span>
                      </div>
                    </div>

                    {/* Scorecard block numbers */}
                    <div className="grid grid-cols-4 gap-4 text-center">
                      <div className="bg-blue-50 border border-blue-200 rounded p-3">
                        <small className="block text-[10px] font-bold text-blue-800 uppercase">Total Score</small>
                        <h2 className="text-2xl font-black text-blue-900 mt-1">{gradedResult.score}</h2>
                      </div>
                      <div className="bg-green-50 border border-green-200 rounded p-3">
                        <small className="block text-[10px] font-bold text-green-800 uppercase">Correct choices</small>
                        <h2 className="text-2xl font-black text-green-950 mt-1">
                          {Object.values(gradedResult.section_scores).reduce((sum, s: any) => sum + s.correct, 0)}
                        </h2>
                      </div>
                      <div className="bg-red-50 border border-red-200 rounded p-3">
                        <small className="block text-[10px] font-bold text-red-800 uppercase">Incorrect answers</small>
                        <h2 className="text-2xl font-black text-red-950 mt-1">
                          {Object.values(gradedResult.section_scores).reduce((sum, s: any) => sum + s.incorrect, 0)}
                        </h2>
                      </div>
                      <div className="bg-slate-100 border border-slate-200 rounded p-3">
                        <small className="block text-[10px] font-bold text-slate-700 uppercase">Left skipped</small>
                        <h2 className="text-2xl font-black text-slate-900 mt-1">
                          {Object.values(gradedResult.section_scores).reduce((sum, s: any) => sum + s.unanswered, 0)}
                        </h2>
                      </div>
                    </div>

                    {/* Telemetry log alerts info */}
                    <div className="bg-slate-900 p-4 rounded text-white text-xs border border-slate-800">
                      <h5 className="font-bold text-amber-400 flex items-center gap-2 mb-2"><ShieldAlert className="w-4 h-4 text-amber-400" /> Assessment Security Log Analyzer:</h5>
                      <p className="text-[11px] text-slate-300">
                        Total out-of-focus tab blurs detected on candidate browser: <strong>{gradedResult.cheating_alerts_count} Events</strong>
                      </p>
                      {gradedResult.cheating_alerts_count > 0 ? (
                        <span className="block mt-1 text-[10px] bg-red-900/40 text-red-300 p-1 rounded font-mono">
                          🚨 COMPROMISED METRICS WARNING: Warnings trace triggered during exam navigation.
                        </span>
                      ) : (
                        <span className="block mt-1 text-[10px] text-green-400 font-bold">
                          ✔ VERIFIED INTEGRITY SHIELD: No suspicious window movements registered on this local terminal session.
                        </span>
                      )}
                    </div>

                    {/* PDF certificate builder action buttons */}
                    <div className="flex gap-4 items-center justify-center pt-2">
                      <button 
                        onClick={handleClientPDFDownload}
                        className="bg-emerald-650 hover:bg-emerald-700 text-white font-extrabold text-sm py-2 px-6 rounded shadow flex items-center gap-2 transition duration-150"
                      >
                        <Download className="w-4 h-4" /> Download PDF Statement
                      </button>
                      <button 
                        onClick={() => {
                          setExamState('setup');
                          setCandName("");
                          setCandEmail("");
                        }}
                        className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-2 px-6 rounded text-xs transition"
                      >
                        Launch New Exam Session
                      </button>
                    </div>

                  </div>
                </div>
              </div>
            )}
          </div>
        )}
                  {/* VIEW 4: ONLINE TEST RESULTS LOOKUP (SHORTCODE MATCH) */}
        {appMode === 'results_checker' && (
          <div className="flex-1 bg-slate-50 rounded-xl shadow-lg border border-slate-200 overflow-hidden max-w-4xl mx-auto w-full min-h-[600px] flex flex-col">
            
            {/* Header Content Section */}
            <div className="bg-slate-900 border-b-4 border-amber-500 p-6 text-center text-white shrink-0">
              <h2 className="text-lg md:text-xl font-black text-amber-400 tracking-widest uppercase mb-2">
                Check Online Test Results
              </h2>
              <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
                Enter the exact mobile number used during the exam setup.
              </p>
            </div>

            <div className="p-4 md:p-6 flex-1 flex flex-col gap-6">
              
              {/* Query Search Form: Stacked on mobile, side-by-side on desktop */}
              <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xxs flex flex-col gap-3">
                <label className="block text-xs font-black text-slate-700 uppercase tracking-wider">
                  Candidate Mobile Verification Search
                </label>
                <div className="flex flex-col sm:flex-row gap-3 w-full">
                  <div className="flex-1">
                    <input 
                      type="tel" 
                      value={checkerPhone}
                      onChange={(e) => setCheckerPhone(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleCheckerSearch(); }}
                      placeholder="e.g. 9876543210..."
                      className="w-full text-xs px-4 py-3 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-slate-800 font-semibold shadow-xs"
                    />
                  </div>
                  <button 
                    onClick={handleCheckerSearch}
                    className="bg-blue-650 hover:bg-blue-700 text-white font-extrabold text-xs uppercase tracking-wider py-3 px-6 rounded-lg shadow-md transition duration-150 inline-flex items-center justify-center gap-2 hover:scale-[1.01] shrink-0"
                  >
                    Check Results
                  </button>
                </div>
              </div>

              {checkerError && (
                <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs font-semibold shadow-xxs">
                  ⚠ {checkerError}
                </div>
              )}

              {/* DETAILED SCORECARD AND LEADER SCOREBOARD DISPLAY */}
              {selectedCheckResult ? (
                <div className="bg-white rounded-lg border border-slate-200 shadow-md overflow-hidden flex flex-col gap-5 p-4 md:p-6">
                  
                  {/* Detailed Back trigger action */}
                  <div className="flex justify-between items-center border-b pb-4 gap-4 flex-wrap">
                    <button
                      onClick={() => { setSelectedCheckResult(null); setShowCheckerSolutions(false); }}
                      className="text-xs text-slate-600 hover:text-slate-900 font-extrabold flex items-center gap-1.5 p-1 bg-slate-100 hover:bg-slate-200 rounded transition"
                    >
                      ← Back to Scorecards List
                    </button>

                    <button 
                      onClick={() => {
                        setGradedResult(selectedCheckResult);
                        setTimeout(() => {
                          handleClientPDFDownload();
                        }, 100);
                      }}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-2 px-4 rounded shadow flex items-center gap-1.5 transition whitespace-nowrap"
                    >
                      <Download className="w-3.5 h-3.5" /> Download PDF Report Card
                    </button>
                  </div>

                  {/* Profile Summary Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-lg border border-slate-150">
                    <div>
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Candidate Verification Profile</span>
                      <h4 className="font-extrabold text-slate-800 text-base">{selectedCheckResult.candidate_name}</h4>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">
                        📧 {selectedCheckResult.candidate_email} | 📞 {selectedCheckResult.candidate_phone || checkerPhone}
                      </p>
                    </div>

                    <div className="md:text-right flex flex-col justify-center">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block font-sans">Scholastic Status</span>
                      <div className="mt-1">
                        <span className={`text-[10.5px] font-black px-2.5 py-1 rounded-md inline-block ${selectedCheckResult.score >= (quizzes.find(q => q.id === selectedCheckResult.quiz_id)?.passing_score || 33) ? 'bg-emerald-100 text-emerald-800 border border-emerald-250' : 'bg-red-100 text-red-700 border border-red-200'}`}>
                          {selectedCheckResult.score >= (quizzes.find(q => q.id === selectedCheckResult.quiz_id)?.passing_score || 33) ? "PASSED (QUALIFIED)" : "FAILED (NOT QUALIFIED)"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Score Bento Metrics Block (Responsive Grid) */}
                  <div>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">
                      Grading Metrics Ledger
                    </span>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                        <small className="block text-[9px] font-black text-blue-800 uppercase tracking-wide">Total Score</small>
                        <h2 className="text-xl font-black text-blue-900 mt-0.5">{selectedCheckResult.score}</h2>
                      </div>
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                        <small className="block text-[9px] font-black text-green-800 uppercase tracking-wide">Correct answers</small>
                        <h2 className="text-xl font-black text-green-950 mt-0.5">
                          {Object.values(selectedCheckResult.section_scores || {}).reduce((sum: number, s: any) => sum + (s.correct || 0), 0)}
                        </h2>
                      </div>
                      <div className="bg-red-50 border border-red-250 rounded-lg p-3">
                        <small className="block text-[9px] font-black text-red-800 uppercase tracking-wide">Incorrect choices</small>
                        <h2 className="text-xl font-black text-red-955 mt-0.5">
                          {Object.values(selectedCheckResult.section_scores || {}).reduce((sum: number, s: any) => sum + (s.incorrect || 0), 0)}
                        </h2>
                      </div>
                      <div className="bg-slate-100 border border-slate-200 rounded-lg p-3">
                        <small className="block text-[9px] font-black text-slate-700 uppercase tracking-wide">Unanswered Left</small>
                        <h2 className="text-xl font-black text-slate-900 mt-0.5 font-sans">
                          {Object.values(selectedCheckResult.section_scores || {}).reduce((sum: number, s: any) => sum + (s.unanswered || 0), 0)}
                        </h2>
                      </div>
                    </div>
                  </div>

                  {/* Anti-cheat Proctor Warnings Logs */}
                  <div className="bg-slate-950 p-4 rounded-lg text-white text-xs border border-slate-800 shadow-sm leading-relaxed">
                    <h5 className="font-extrabold text-amber-400 flex items-center gap-1.5 mb-1.5">
                      <ShieldAlert className="w-4 h-4 text-amber-400" /> Secure CBT Proctor Monitoring Logs:
                    </h5>
                    <p className="text-[11px] text-slate-350">
                      We have detected <strong>{selectedCheckResult.cheating_alerts_count} out-of-focus tab blurs</strong> during the examination course of this candidate.
                    </p>
                    {selectedCheckResult.cheating_alerts_count > 0 ? (
                      <span className="block mt-1.5 text-[10px] bg-red-950/50 border border-red-900/60 text-red-300 p-1.5 rounded font-mono">
                        ⚠ PROCTOR INTEGRITY WARNING: Potential unauthorized web navigation logs registered on candidate terminal block.
                      </span>
                    ) : (
                      <span className="block mt-1.5 text-[10px] text-emerald-400 font-extrabold">
                        ✔ OK: Authentication logs verify healthy clean state. Full security compliance established.
                      </span>
                    )}
                  </div>

                  {/* Section-wise Grid Ledger */}
                  <div>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Section Scores Summary</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
                      {Object.entries(selectedCheckResult.section_scores || {}).map(([secName, val]: [string, any]) => (
                        <div key={secName} className="bg-slate-50 border border-slate-200 rounded p-3 text-[11px] hover:border-slate-350 transition">
                          <strong className="block text-slate-700 font-bold mb-1.5">📁 {secName}</strong>
                          <div className="flex flex-wrap gap-2 text-slate-500 justify-between items-center font-mono">
                            <span>Score: <strong className="text-blue-900">{val.score || 0} pts</strong></span>
                            <span>Correct: <span className="font-bold text-emerald-600">{val.correct || 0}</span></span>
                            <span>Wrong: <span className="font-bold text-red-500">{val.incorrect || 0}</span></span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* LEADER SCOREBOARD COMPONENT */}
                  <div>
                    <div className="flex justify-between items-center border-b border-slate-200 pb-2 mb-3">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                        Leader Scoreboard ranking
                      </span>
                      <span className="text-[10px] font-bold text-blue-700 uppercase">
                        {quizzes.find(q => q.id === selectedCheckResult.quiz_id)?.title}
                      </span>
                    </div>

                    <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                      {/* Responsive Grid layout for leaderboard on mobile and desktop table */}
                      <div className="hidden sm:block overflow-x-auto">
                        <table className="w-full text-left border-collapse text-[11px]">
                          <thead>
                            <tr className="bg-slate-100 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                              <th className="py-2.5 px-3">Rank No</th>
                              <th className="py-2.5 px-3">Candidate Full Name</th>
                              <th className="py-2.5 px-3 text-center">Marks Obtained</th>
                              <th className="py-2.5 px-3 text-center">Duration</th>
                              <th className="py-2.5 px-3 text-center">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {results
                              .filter(x => x.quiz_id === selectedCheckResult.quiz_id)
                              .sort((a, b) => b.score - a.score || a.time_taken_seconds - b.time_taken_seconds)
                              .map((entry, idx) => {
                                const isCurrent = entry.id === selectedCheckResult.id;
                                const hasPassed = entry.score >= (quizzes.find(q => q.id === selectedCheckResult.quiz_id)?.passing_score || 33);
                                return (
                                  <tr 
                                    key={entry.id} 
                                    className={`border-b last:border-0 border-slate-200 hover:bg-slate-100 transition ${isCurrent ? 'bg-amber-50 font-black border-2 border-amber-400' : ''}`}
                                  >
                                    <td className="py-2.5 px-3">
                                      <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[9px] font-black ${idx === 0 ? 'bg-yellow-400 text-yellow-950 font-black shadow-xxs' : idx === 1 ? 'bg-slate-300 text-slate-800' : idx === 2 ? 'bg-amber-600 text-white' : 'bg-slate-200 text-slate-700'}`}>
                                        {idx + 1}
                                      </span>
                                    </td>
                                    <td className="py-2.5 px-3 text-slate-800">
                                      {entry.candidate_name} {isCurrent && <span className="bg-amber-100 text-amber-800 text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded ml-1 tracking-wider border border-amber-200">You</span>}
                                    </td>
                                    <td className="py-2.5 px-3 text-center text-blue-900 font-bold">{entry.score} pts</td>
                                    <td className="py-2.5 px-3 text-center text-slate-500 font-mono text-[10px]">
                                      {Math.floor(entry.time_taken_seconds / 60)}m {entry.time_taken_seconds % 60}s
                                    </td>
                                    <td className="py-2.5 px-3 text-center">
                                      <span className={`text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider ${hasPassed ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-700'}`}>
                                        {hasPassed ? "PASSED" : "FAILED"}
                                      </span>
                                    </td>
                                  </tr>
                                );
                              })}
                          </tbody>
                        </table>
                      </div>

                      {/* Scoreboard Column stack for mobile responsive rendering */}
                      <div className="block sm:hidden space-y-2 p-3">
                        {results
                          .filter(x => x.quiz_id === selectedCheckResult.quiz_id)
                          .sort((a, b) => b.score - a.score || a.time_taken_seconds - b.time_taken_seconds)
                          .map((entry, idx) => {
                            const isCurrent = entry.id === selectedCheckResult.id;
                            const hasPassed = entry.score >= (quizzes.find(q => q.id === selectedCheckResult.quiz_id)?.passing_score || 33);
                            return (
                              <div 
                                key={entry.id} 
                                className={`p-3 rounded-lg border text-[11px] transition flex flex-col gap-1.5 ${isCurrent ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-300 font-bold' : 'bg-white border-slate-200'}`}
                              >
                                <div className="flex justify-between items-center">
                                  <div className="flex items-center gap-1.5">
                                    <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[9px] font-black ${idx === 0 ? 'bg-yellow-400 text-yellow-950 shadow-xxs' : idx === 1 ? 'bg-slate-300 text-slate-800' : idx === 2 ? 'bg-amber-600 text-white' : 'bg-slate-200 text-slate-700'}`}>
                                      {idx + 1}
                                    </span>
                                    <span className="font-extrabold text-slate-800">
                                      {entry.candidate_name}
                                    </span>
                                    {isCurrent && (
                                      <span className="bg-amber-100 text-amber-800 text-[8px] font-extrabold uppercase px-1 py-0.5 rounded tracking-wider border border-amber-200">
                                        You
                                      </span>
                                    )}
                                  </div>
                                  <span className={`text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider ${hasPassed ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-700'}`}>
                                    {hasPassed ? "PASSED" : "FAILED"}
                                  </span>
                                </div>
                                <div className="flex justify-between text-slate-500 font-mono text-[10px] border-t border-slate-100 pt-1.5 mt-0.5">
                                  <span>Marks: <strong className="text-blue-900 font-semibold">{entry.score} pts</strong></span>
                                  <span>Duration: <strong>{Math.floor(entry.time_taken_seconds / 60)}m {entry.time_taken_seconds % 60}s</strong></span>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  </div>

                </div>
              ) : (
                <div className="space-y-4">
                  {checkerResults === null ? (
                    <div className="bg-white border border-slate-200 rounded-lg p-8 text-center text-slate-400 text-xs italic shadow-xxs">
                      No search initialized yet. Enter the mobile contact number used during the exam setup.
                    </div>
                  ) : checkerResults.length === 0 ? (
                    <div className="bg-white border border-slate-200 rounded-lg p-8 text-center text-slate-400 text-xs italic shadow-xxs">
                      No previous exam submissions found matching this candidate phone contact.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">
                        Matched Examination Results ({checkerResults.length})
                      </span>
                      
                      <div className="grid grid-cols-1 gap-3">
                        {checkerResults.map((r) => {
                          const currentQuiz = quizzes.find(qz => qz.id === r.quiz_id);
                          const passingScore = currentQuiz?.passing_score || 33;
                          const hasPassed = r.score >= passingScore;

                          return (
                            <div 
                              key={r.id} 
                              className="bg-white border border-slate-200 hover:border-slate-300 rounded-lg overflow-hidden shadow-xs hover:shadow-sm transition flex flex-col sm:flex-row items-stretch justify-between"
                            >
                              {/* Left Colored status and details */}
                              <div className="p-4 flex-1 flex flex-col gap-1.5 justify-center">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className={`w-2 h-2 rounded-full ${hasPassed ? 'bg-emerald-500' : 'bg-red-500'}`} />
                                  <h4 className="font-extrabold text-slate-800 text-xs md:text-sm">
                                    {currentQuiz?.title || "Staff Selection Exam Unit"}
                                  </h4>
                                </div>
                                <div className="flex flex-wrap gap-x-4 gap-y-1 text-slate-500 text-[11px] font-sans">
                                  <span>Score: <strong className="text-slate-850 font-bold">{r.score} pts</strong></span>
                                  <span>Passed: <strong className={hasPassed ? "text-emerald-700" : "text-red-650"}>{hasPassed ? "YES" : "NO"}</strong></span>
                                  <span>Date: <strong className="font-mono">{r.created_at ? new Date(r.created_at).toLocaleDateString() : "Recently"}</strong></span>
                                </div>
                              </div>

                              {/* Right dynamic check button */}
                              <div className="bg-slate-50/50 border-t sm:border-t-0 sm:border-l border-slate-150 p-3.5 flex items-center justify-end shrink-0 sm:min-w-[140px]">
                                <button 
                                  onClick={() => setSelectedCheckResult(r)}
                                  className="w-full sm:w-auto bg-slate-900 text-white hover:bg-slate-800 font-extrabold text-[11px] tracking-wide py-2 px-4 rounded shadow-xs transition inline-flex items-center justify-center gap-1 hover:scale-[1.02]"
                                >
                                  Check Results
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 3: PLUGINS CORE FILE EXPLORER AND COMPILE CENTER */}
        {appMode === 'explorer' && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden min-h-[750px]">
            
            {/* File List Left panel */}
            <div className="lg:col-span-1 bg-slate-900 text-slate-300 p-4 border-r border-slate-800 flex flex-col gap-1.5 shrink-0">
              <div className="p-3 bg-slate-800 border border-slate-700 rounded-lg text-center mb-4 shadow">
                <span className="text-xs font-black text-slate-200 block tracking-wider uppercase mb-1">
                  📦 Installable ZIP Builder
                </span>
                <p className="text-[10px] text-slate-400 leading-relaxed">Assemble files below directly into WordPress upload format.</p>
                
                <button 
                  id="btn-download-zip"
                  onClick={handleZipGeneration}
                  disabled={zippingState}
                  className="w-full bg-amber-500 text-slate-950 font-black text-xs py-2 px-4 rounded shadow-md mt-3 hover:bg-amber-400 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <DownloadCloud className="w-4 h-4" /> 
                  {zippingState ? "Bundling Package..." : "Download Plugin (.ZIP)"}
                </button>
              </div>

              <span className="text-[10px] font-extrabold uppercase text-slate-500 tracking-wider block px-1">Plugin Files list</span>
              
              <div className="flex flex-col gap-1 overflow-y-auto max-h-[460px]">
                {PLUGIN_METADATA_FILES.map(f => (
                  <button
                    key={f.path}
                    onClick={() => setSelectedFile(f.path)}
                    className={`text-left text-[11px] p-2 rounded transition-all font-bold flex items-center justify-between border ${selectedFile === f.path ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'border-transparent text-slate-300 hover:bg-slate-800'}`}
                  >
                    <span className="truncate">{f.path}</span>
                    <span className={`text-[9px] font-mono px-1 rounded ${f.type === 'php' ? 'bg-blue-900 text-blue-300' : f.type === 'css' ? 'bg-pink-900 text-pink-300' : 'bg-emerald-900 text-emerald-300'}`}>
                      {f.type}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Code Code Content right panel */}
            <div className="lg:col-span-3 p-6 bg-slate-950 flex flex-col gap-4 overflow-hidden text-slate-200">
              <div className="flex items-center justify-between gap-4 border-b border-slate-800 pb-3 flex-wrap">
                <div>
                  <h4 className="text-base font-extrabold text-white flex items-center gap-2">
                    <Code className="w-4 h-4 text-amber-500" /> {selectedFile}
                  </h4>
                  <p className="text-[11px] mt-0.5 text-slate-400">
                    {PLUGIN_METADATA_FILES.find(f => f.path === selectedFile)?.description}
                  </p>
                </div>

                <button 
                  onClick={() => handleCopyClipboard(FILE_CONTENTS[selectedFile] || "")}
                  className="bg-slate-800 hover:bg-slate-750 text-amber-400 border border-slate-700 text-xs px-3.5 py-1.5 rounded transition duration-150 font-bold flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" /> 
                  {copySuccess === selectedFile ? "Copied Correctly!" : "Copy Code"}
                </button>
              </div>

              {/* Real Code blocks */}
              <div className="flex-1 overflow-auto border border-slate-800 rounded bg-slate-900/50 p-4 font-mono text-[11px] leading-relaxed relative">
                <pre className="text-left text-slate-300 whitespace-pre">
                  {FILE_CONTENTS[selectedFile]}
                </pre>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* ANTI-CHEAT FULLSCREEN DIALOG ALERT OVERLAYS IN ACTIVE TEST SIMULATION */}
      {showCheatModal && (
        <div id="cbt-blur-modal" className="fixed inset-0 bg-slate-950/90 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border-t-8 border-red-600 max-w-md w-full p-6 text-center select-none shadow-2xl">
            <span className="inline-block p-3 bg-red-100 text-red-650 rounded-full mb-3 animate-bounce">
              <ShieldAlert className="w-10 h-10" />
            </span>
            <h3 className="text-lg font-black text-red-700 uppercase tracking-tight">Security Alert Breach</h3>
            <p className="text-xs text-slate-600 leading-relaxed mt-2">
              You navigated off the active assessments browser console screen. Moving out of fullscreen or resizing elements is strictly monitored.
            </p>

            <div className="bg-red-50 text-red-950 p-3 rounded-lg border border-red-200 my-4 text-center">
              <span className="text-xs font-black block text-red-800">Violation Strike detected:</span>
              <span className="text-2xl font-black block text-red-700 mt-1">{cheatWarnings} / 3 Strikes Warning</span>
              <span className="text-[10px] text-slate-500 mt-1 block">Automatic test submit happens instantly at 3 Strikes.</span>
            </div>

            <button 
              onClick={() => setShowCheatModal(false)}
              className="w-full bg-slate-900 hover:bg-slate-800 text-amber-400 font-extrabold py-2 px-4 rounded text-xs transition uppercase tracking-wide"
            >
              Acknowledge & Resume exam
            </button>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-500 text-[11px] py-4 border-t border-slate-800 shrink-0 text-center">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2526 Competitive Exam Quiz System for WordPress. Crafted dynamically under NTA CBT specifications.</p>
        </div>
      </footer>

    </div>
  );
}
