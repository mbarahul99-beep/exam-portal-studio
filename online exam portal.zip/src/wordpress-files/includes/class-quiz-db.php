<?php
/**
 * Class CEQ_Quiz_DB
 * Handles custom database query methods for Competitive Exam Quiz System.
 */

if (!defined('ABSPATH')) {
    exit;
}

class CEQ_Quiz_DB {

    public function __construct() {
        // Handle custom DB-related administrative functions here if required.
    }

    /**
     * Fetch all available quizzes
     */
    public function get_quizzes() {
        global $wpdb;
        $table = $wpdb->prefix . 'ceq_quizzes';

        // Self-heal check: ensure subject_code, sections, starts_at, status, restrict_by_phone, and allowed_phones exist
        $columns = $wpdb->get_col("DESCRIBE $table");
        if (!empty($columns)) {
            if (!in_array('subject_code', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `subject_code` varchar(50) DEFAULT '' NOT NULL AFTER `title`");
            }
            if (!in_array('sections', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `sections` text NOT NULL AFTER `negative_marks`");
            }
            if (!in_array('starts_at', $columns)) {
                // Safely determine AFTER sections since we just checked/added sections
                @$wpdb->query("ALTER TABLE `$table` ADD `starts_at` varchar(50) DEFAULT '' NOT NULL AFTER `sections`");
            }
            if (!in_array('status', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `status` varchar(20) DEFAULT 'published' NOT NULL AFTER `starts_at`");
            }
            if (!in_array('restrict_by_phone', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `restrict_by_phone` tinyint(1) DEFAULT 0 NOT NULL AFTER `status`");
            }
            if (!in_array('allowed_phones', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `allowed_phones` longtext NOT NULL AFTER `restrict_by_phone`");
            }
            if (!in_array('section_settings', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `section_settings` longtext NOT NULL AFTER `allowed_phones`");
            }
        }

        return $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC", ARRAY_A);
    }

    /**
     * Fetch a single quiz by ID
     */
    public function get_quiz($id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ceq_quizzes';

        // Self-heal check: ensure subject_code, sections, starts_at, status, restrict_by_phone, and allowed_phones exist
        $columns = $wpdb->get_col("DESCRIBE $table");
        if (!empty($columns)) {
            if (!in_array('subject_code', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `subject_code` varchar(50) DEFAULT '' NOT NULL AFTER `title`");
            }
            if (!in_array('sections', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `sections` text NOT NULL AFTER `negative_marks`");
            }
            if (!in_array('starts_at', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `starts_at` varchar(50) DEFAULT '' NOT NULL AFTER `sections`");
            }
            if (!in_array('status', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `status` varchar(20) DEFAULT 'published' NOT NULL AFTER `starts_at`");
            }
            if (!in_array('restrict_by_phone', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `restrict_by_phone` tinyint(1) DEFAULT 0 NOT NULL AFTER `status`");
            }
            if (!in_array('allowed_phones', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `allowed_phones` longtext NOT NULL AFTER `restrict_by_phone`");
            }
            if (!in_array('section_settings', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `section_settings` longtext NOT NULL AFTER `allowed_phones`");
            }
        }

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id), ARRAY_A);
    }

    /**
     * Fetch all questions of a specific quiz
     */
    public function get_questions($quiz_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ceq_questions';

        // Self-heal check: ensure positive_marks, negative_marks, and question_image exist
        $columns = $wpdb->get_col("DESCRIBE $table");
        if (!empty($columns)) {
            if (!in_array('positive_marks', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `positive_marks` decimal(4,2) DEFAULT NULL AFTER `explanation`");
            }
            if (!in_array('negative_marks', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `negative_marks` decimal(4,2) DEFAULT NULL AFTER `positive_marks`");
            }
            if (!in_array('question_image', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `question_image` text DEFAULT NULL AFTER `negative_marks`");
            }
            if (!in_array('option_images', $columns)) {
                @$wpdb->query("ALTER TABLE `$table` ADD `option_images` text DEFAULT NULL AFTER `question_image`");
            }
        }

        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE quiz_id = %d ORDER BY id ASC", $quiz_id), ARRAY_A);
        
        // Decode options array from JSON automatically
        foreach ($results as &$row) {
            $row['options'] = json_decode($row['options'], true);
            // Decode option_images
            if (!empty($row['option_images'])) {
                $row['option_images'] = json_decode($row['option_images'], true);
            } else {
                $row['option_images'] = array("", "", "", "");
            }
            // Cast to float or keep as null for overrides
            $row['positive_marks'] = $row['positive_marks'] !== null ? floatval($row['positive_marks']) : null;
            $row['negative_marks'] = $row['negative_marks'] !== null ? floatval($row['negative_marks']) : null;
        }
        return $results;
    }

    /**
     * Submit/Save quiz result
     */
    public function save_result($data) {
        global $wpdb;
        $table = $wpdb->prefix . 'ceq_results';
        
        // Self-heal check: Make sure candidate_phone and candidate_father_name columns exist
        $has_phone = false;
        $has_father = false;
        $columns = $wpdb->get_col("DESCRIBE $table");
        if (!empty($columns)) {
            if (in_array('candidate_phone', $columns)) {
                $has_phone = true;
            }
            if (in_array('candidate_father_name', $columns)) {
                $has_father = true;
            }
        } else {
            $column_check = $wpdb->get_results("SHOW COLUMNS FROM `$table` LIKE 'candidate_phone'");
            if (!empty($column_check)) {
                $has_phone = true;
            }
            $father_check = $wpdb->get_results("SHOW COLUMNS FROM `$table` LIKE 'candidate_father_name'");
            if (!empty($father_check)) {
                $has_father = true;
            }
        }

        if (!$has_phone) {
            @$wpdb->query("ALTER TABLE `$table` ADD `candidate_phone` varchar(50) DEFAULT '' NOT NULL AFTER `candidate_email`");
            $has_phone = true;
        }

        if (!$has_father) {
            @$wpdb->query("ALTER TABLE `$table` ADD `candidate_father_name` varchar(255) DEFAULT '' NOT NULL AFTER `candidate_name`");
            $has_father = true;
        }

        $insert_data = array(
            'quiz_id'               => intval($data['quiz_id']),
            'candidate_name'        => sanitize_text_field($data['candidate_name']),
            'candidate_email'       => sanitize_email($data['candidate_email']),
            'score'                 => floatval($data['score']),
            'answers'               => wp_json_encode($data['answers']),
            'time_taken_seconds'    => intval($data['time_taken_seconds']),
            'cheating_incidents'    => wp_json_encode($data['cheating_incidents']),
            'cheating_alerts_count' => intval($data['cheating_alerts_count']),
            'section_scores'        => wp_json_encode($data['section_scores']),
            'created_at'            => current_time('mysql')
        );

        if ($has_father) {
            $insert_data['candidate_father_name'] = sanitize_text_field($data['candidate_father_name'] ?? '');
        }

        if ($has_phone) {
            $insert_data['candidate_phone'] = sanitize_text_field($data['candidate_phone'] ?? '');
        }

        $inserted = $wpdb->insert($table, $insert_data);

        // Graceful schema fail-safes
        if (!$inserted) {
            // Keep retrying fallbacks if column errors
            if (isset($insert_data['candidate_phone'])) {
                unset($insert_data['candidate_phone']);
            }
            if (isset($insert_data['candidate_father_name'])) {
                unset($insert_data['candidate_father_name']);
            }
            $inserted = $wpdb->insert($table, $insert_data);
        }

        if ($inserted) {
            return $wpdb->insert_id;
        }
        return false;
    }

    /**
     * Fetch Leaderboard for a quiz
     */
    public function get_leaderboard($quiz_id, $limit = 50) {
        global $wpdb;
        $table = $wpdb->prefix . 'ceq_results';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT id, candidate_name, score, time_taken_seconds, cheating_alerts_count, created_at 
             FROM $table 
             WHERE quiz_id = %d 
             ORDER BY score DESC, time_taken_seconds ASC 
             LIMIT %d", 
            $quiz_id, $limit
        ), ARRAY_A);
    }

    /**
     * Fetch all results for a candidate by phone number
     */
    public function get_results_by_phone($phone) {
        global $wpdb;
        $table_results = $wpdb->prefix . 'ceq_results';
        $table_quizzes = $wpdb->prefix . 'ceq_quizzes';

        $clean_phone = preg_replace('/\D/', '', $phone);
        if (empty($clean_phone)) {
            return array();
        }

        // Fetch matching records and load quiz titles securely
        $results = $wpdb->get_results(
            "SELECT r.*, q.title as quiz_title, q.passing_score 
             FROM $table_results r 
             LEFT JOIN $table_quizzes q ON r.quiz_id = q.id 
             ORDER BY r.id DESC", 
            ARRAY_A
        );

        $matched = array();
        foreach ($results as $row) {
            $db_phone_clean = preg_replace('/\D/', '', $row['candidate_phone']);
            if ($db_phone_clean === $clean_phone || $row['candidate_phone'] === $phone) {
                // Decode JSON fields for immediate frontend usability
                $row['answers'] = json_decode($row['answers'], true);
                if (isset($row['cheating_incidents'])) {
                    $row['cheating_incidents'] = json_decode($row['cheating_incidents'], true);
                }
                if (isset($row['section_scores'])) {
                    $row['section_scores'] = json_decode($row['section_scores'], true);
                }
                $matched[] = $row;
            }
        }
        return $matched;
    }

    /**
     * Compute total possible marks for a quiz
     */
    public function get_quiz_total_marks($quiz_id) {
        global $wpdb;
        $table_quizzes = $wpdb->prefix . 'ceq_quizzes';
        $table_questions = $wpdb->prefix . 'ceq_questions';

        $quiz = $wpdb->get_row($wpdb->prepare("SELECT positive_marks, negative_marks, section_settings FROM $table_quizzes WHERE id = %d", $quiz_id), ARRAY_A);
        if (!$quiz) {
            return 0;
        }

        $questions = $wpdb->get_results($wpdb->prepare("SELECT section_name, positive_marks FROM $table_questions WHERE quiz_id = %d", $quiz_id), ARRAY_A);
        
        $pos_marks = floatval($quiz['positive_marks']);
        $section_settings_raw = isset($quiz['section_settings']) ? $quiz['section_settings'] : '';
        $section_settings = array();
        if (!empty($section_settings_raw)) {
            $section_settings = json_decode($section_settings_raw, true);
            if (!is_array($section_settings)) {
                $section_settings = array();
            }
        }

        $total_marks = 0;
        foreach ($questions as $q) {
            $sec = $q['section_name'];
            $q_pos = $pos_marks;

            // SECTION LEVEL OVERRIDE
            if (isset($section_settings[$sec]) && isset($section_settings[$sec]['positive_marks'])) {
                $q_pos = floatval($section_settings[$sec]['positive_marks']);
            }

            // QUESTION LEVEL OVERRIDE
            if (isset($q['positive_marks']) && $q['positive_marks'] !== null && $q['positive_marks'] !== '') {
                $q_pos = floatval($q['positive_marks']);
            }

            $total_marks += $q_pos;
        }

        return $total_marks > 0 ? $total_marks : 100.0; // fallback to 100 default if no questions
    }

    /**
     * Delete an individual result entry safely
     */
    public function delete_result($result_id) {
        global $wpdb;
        $table_results = $wpdb->prefix . 'ceq_results';
        return $wpdb->delete($table_results, array('id' => $result_id), array('%d'));
    }

    /**
     * Delete Quiz and its questions safely
     */
    public function delete_quiz($quiz_id) {
        global $wpdb;
        $table_quizzes = $wpdb->prefix . 'ceq_quizzes';
        $table_questions = $wpdb->prefix . 'ceq_questions';
        $table_results = $wpdb->prefix . 'ceq_results';

        $wpdb->delete($table_questions, array('quiz_id' => $quiz_id), array('%d'));
        $wpdb->delete($table_results, array('quiz_id' => $quiz_id), array('%d'));
        return $wpdb->delete($table_quizzes, array('id' => $quiz_id), array('%d'));
    }
}
