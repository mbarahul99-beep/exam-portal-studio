/**
 * WordPress CBT Quiz Engine Controller
 * Manages full assessment cycle: authentication, fullscreen instructions, palette selectors, state caches, AJAX, anti-cheat, and jsPDF certificate exporter.
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Guard checking element presence
        if ($('#ceq-exam-portal-container').length === 0 && $('#ceq-results-checker-container').length === 0) {
            return;
        }

        // Global State Variables Object
        var State = {
            quiz_id: parseInt(CEQ_Exam_Context.quiz_id, 10),
            nonce: CEQ_Exam_Context.security,
            ajax_url: CEQ_Exam_Context.ajax_url,
            candidate_name: '',
            candidate_father_name: '',
            candidate_phone: '',
            candidate_email: '',
            questions: [],
            sections: [],
            answers: {},          // { question_id: option_index }
            palette_status: {},   // { question_id: 'not-visited' | 'not-answered' | 'answered' | 'marked' | 'answered-marked' }
            current_question_idx: 0,
            current_section: '',
            timer_total_seconds: 0,
            timer_seconds_left: 0,
            timer_interval_id: null,
            exam_end_timestamp: 0,
            cheating_alerts: 0,
            cheating_history: [],
            exam_submitted: false,
            wake_lock: null
        };

        // State Machine Initializer
        function initApp() {
            if ($('#ceq-exam-portal-container').length > 0) {
                bindWelcomeEvents();
                checkScheduledExam();
            }
            if ($('#ceq-results-checker-container').length > 0) {
                bindResultsSearchEvents();
            }
        }

        // Check if exam starts on a scheduled timing and count down
        function checkScheduledExam() {
            var container = $('#ceq-exam-portal-container');
            var startsAtStr = container.attr('data-starts-at') || '';
            if (!startsAtStr) {
                return;
            }

            var targetTime;
            try {
                // Support both ISO format and standard datetime-local representations
                targetTime = new Date(startsAtStr.replace(' ', 'T'));
            } catch (e) {
                console.warn('Could not parse scheduled datetime string:', startsAtStr);
                return;
            }

            if (isNaN(targetTime.getTime())) {
                return;
            }

            var now = new Date();
            if (targetTime.getTime() <= now.getTime()) {
                return; // Available immediately
            }

            var banner = $('#ceq-scheduled-banner');
            var countdownEl = $('#ceq-scheduled-countdown');
            var targetTimeEl = $('#ceq-scheduled-target-time');
            var startBtn = $('#ceq-btn-start-exam');

            banner.removeClass('ceq-hidden').show();
            targetTimeEl.text('Available From: ' + targetTime.toLocaleString());

            // Lock start button
            startBtn.prop('disabled', true)
                    .css({ 'background-color': '#9ca3af', 'cursor': 'not-allowed', 'border-color': '#9ca3af' })
                    .text('Waiting for Scheduled Start Time...');

            var schedIntervalId = setInterval(function() {
                var currentNow = new Date().getTime();
                var diff = targetTime.getTime() - currentNow;

                if (diff <= 0) {
                    clearInterval(schedIntervalId);
                    banner.fadeOut(500, function() {
                        $(this).addClass('ceq-hidden');
                    });
                    startBtn.prop('disabled', false)
                            .css({ 'background-color': '', 'cursor': '', 'border-color': '' })
                            .text('Acknowledge & Start Test');
                    return;
                }

                var days = Math.floor(diff / (1000 * 60 * 60 * 24));
                var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((diff % (1000 * 60)) / 1000);

                var pad = function(n) { return n < 10 ? '0' + n : n; };

                var countdownStr = '';
                if (days > 0) {
                    countdownStr += days + 'd ' + pad(hours) + 'h ' + pad(minutes) + 'm ' + pad(seconds) + 's';
                } else {
                    countdownStr += pad(hours) + ':' + pad(minutes) + ':' + pad(seconds);
                }

                countdownEl.text(countdownStr);
            }, 1000);
        }

        // Hook click triggers on Candidate screen
        function bindWelcomeEvents() {
            $('#ceq-btn-start-exam').on('click', function(e) {
                e.preventDefault();
                var name = $('#ceq-candidate-name').val().trim();
                var fatherName = $('#ceq-candidate-father-name').val().trim();
                var phone = $('#ceq-candidate-phone').val().trim();
                var email = $('#ceq-candidate-email').val().trim();

                if (!name) {
                    alert('Please enter your full Candidate Name before starting the examination.');
                    return;
                }
                if (!fatherName) {
                    alert('Please enter your Father\'s Name before starting the examination.');
                    return;
                }
                if (!phone) {
                    alert('Please enter your Mobile Number before starting the examination.');
                    return;
                }
                if (!email) {
                    alert('Please enter your Email Address before starting the examination.');
                    return;
                }

                State.candidate_name = name;
                State.candidate_father_name = fatherName;
                State.candidate_phone = phone;
                State.candidate_email = email;

                // Fire AJAX query to retrieve exam databank
                fetchExamQuestions();
            });
        }

        // Fetch Exam Questions securely
        function fetchExamQuestions() {
            var loaderBtn = $('#ceq-btn-start-exam');
            loaderBtn.html('Loading Exam Panel...').prop('disabled', true);

            $.ajax({
                url: State.ajax_url,
                method: 'POST',
                data: {
                    action: 'ceq_fetch_quiz_data',
                    security: State.nonce,
                    quiz_id: State.quiz_id,
                    candidate_phone: State.candidate_phone
                },
                success: function(response) {
                    if (response.success) {
                        State.questions = response.data.questions;
                        State.quiz = response.data.quiz;
                        var duration = parseInt(response.data.quiz.duration_mins, 10);
                        State.timer_total_seconds = duration * 60;
                        State.timer_seconds_left = State.timer_total_seconds;

                        // Process custom sections from response.data.quiz.sections dynamically
                        if (response.data.quiz.sections) {
                            State.sections = response.data.quiz.sections.split(',').map(function(s) { return s.trim(); });
                        } else {
                            // Fallback to sections discovered in questions
                            var sectionSet = new Set();
                            State.questions.forEach(function(q) {
                                if (q.section_name) {
                                    sectionSet.add(q.section_name);
                                }
                            });
                            State.sections = Array.from(sectionSet);
                        }

                        // Init state variables
                        State.questions.forEach(function(q) {
                            State.palette_status[q.id] = 'not-visited';
                        });

                        // Fire up assessment suite
                        launchAssessmentPortal();
                    } else {
                        alert('Error: ' + response.data.message);
                        loaderBtn.html('Acknowledge & Start Test').prop('disabled', false);
                    }
                },
                error: function() {
                    alert('Communication error occurred. Please refresh or try again.');
                    loaderBtn.html('Acknowledge & Start Test').prop('disabled', false);
                }
            });
        }

        // Screen Wake Lock API handler
        async function requestScreenWakeLock() {
            if ('wakeLock' in navigator) {
                try {
                    State.wake_lock = await navigator.wakeLock.request('screen');
                    console.log('Screen Wake Lock acquired successfully.');
                } catch (err) {
                    console.warn('Wake lock reservation blocked: ' + err.message);
                }
            }
        }

        function releaseScreenWakeLock() {
            if (State.wake_lock !== null) {
                try {
                    State.wake_lock.release().then(function() {
                        State.wake_lock = null;
                        console.log('Screen Wake Lock released.');
                    });
                } catch (err) {}
            }
        }

        // Renders primary exam workspace
        function launchAssessmentPortal() {
            // Install exit or reload prevention alarm triggers
            $(window).off('beforeunload.ceq_warn').on('beforeunload.ceq_warn', function(e) {
                if (!State.exam_submitted && State.questions.length > 0) {
                    var warningMsg = 'You have an active exam in progress. Are you sure you want to quit without submitting? Progress will be lost.';
                    e.originalEvent.returnValue = warningMsg;
                    return warningMsg;
                }
            });

            // Initialize Screen Wake Lock to keep screen awake
            requestScreenWakeLock();

            // Retain wake lock if visibility returns to tab
            $(document).off('visibilitychange.ceq_wake').on('visibilitychange.ceq_wake', function() {
                if (State.wake_lock !== null && document.visibilityState === 'visible') {
                    requestScreenWakeLock();
                }
            });

            // Hide candidate details page, display workspace
            $('#ceq-welcome-screen').addClass('ceq-hidden');
            $('#ceq-exam-workspace').removeClass('ceq-hidden');

            // Escape WordPress theme parent columns, sidebars, max-width wrappers, or transform constraints by appending directly to the body
            if ($('#ceq-exam-portal-placeholder').length === 0) {
                $('<div id="ceq-exam-portal-placeholder" style="display:none;"></div>').insertAfter('#ceq-exam-portal-container');
            }
            $('#ceq-exam-portal-container').appendTo('body');

            // Force fullscreen mode covering the entire view screen
            $('#ceq-exam-portal-container').addClass('ceq-fullscreen-active');
            $('body').addClass('ceq-body-lock');

            // Attempt native HTML5 browser full screen request
            try {
                var docEl = document.documentElement;
                if (docEl.requestFullscreen) docEl.requestFullscreen();
                else if (docEl.mozRequestFullScreen) docEl.mozRequestFullScreen();
                else if (docEl.webkitRequestFullscreen) docEl.webkitRequestFullscreen();
                else if (docEl.msRequestFullscreen) docEl.msRequestFullscreen();
            } catch (err) {
                console.log('Native fullscreen was bypassed or restricted. Stretched CSS container override active.');
            }

            // Populate live metadata
            $('#ceq-live-cand-name').text(State.candidate_name);
            
            // Build tabbed interfaces
            buildSectionTabs();
            
            // Render index question
            renderQuestion(0);

            // Turn on ticking clock timer
            startTickingClock();

            // Establish Anti-cheat blur telemetry triggers
            bindAntiCheatAuditors();

            // Intercept standard workspace navigation CTA click handles
            bindWorkspaceEvents();
        }

        // Categorized Category tabs
        function buildSectionTabs() {
            var container = $('#ceq-sections-bar');
            container.empty();
            
            State.sections.forEach(function(sec, idx) {
                var activeClass = (idx === 0) ? 'ceq-active-tab' : '';
                var tab = $('<div class="ceq-sec-tab ' + activeClass + '" data-section="' + sec + '">' + sec + '</div>');
                container.append(tab);

                tab.on('click', function() {
                    var targetSec = $(this).data('section');
                    // Find first question of this section
                    var targetIdx = State.questions.findIndex(function(q) {
                        return q.section_name === targetSec;
                    });
                    if (targetIdx !== -1) {
                        renderQuestion(targetIdx);
                    } else {
                        alert('No questions assigned to ' + targetSec + ' section inside this exam.');
                    }
                });
            });
        }

        // Unified Question Render Engine
        function renderQuestion(index) {
            if (index < 0 || index >= State.questions.length) return;

            // Highlight current index as visited if it was previously not-visited
            var prevQ = State.questions[State.current_question_idx];
            if (prevQ && State.palette_status[prevQ.id] === 'not-visited') {
                State.palette_status[prevQ.id] = 'not-answered';
            }

            State.current_question_idx = index;
            var q = State.questions[index];

            // Calculate dynamic ques-level / section-level override marks
            var positive = 2;
            var negative = 0.5;
            
            if (State.quiz) {
                if (State.quiz.positive_marks !== undefined && State.quiz.positive_marks !== null) {
                    positive = parseFloat(State.quiz.positive_marks);
                }
                if (State.quiz.negative_marks !== undefined && State.quiz.negative_marks !== null) {
                    negative = parseFloat(State.quiz.negative_marks);
                }
            }

            // 1. Process Section Level Overrides
            var sectionSettings = {};
            if (State.quiz && State.quiz.section_settings) {
                try {
                    sectionSettings = typeof State.quiz.section_settings === 'string' 
                        ? JSON.parse(State.quiz.section_settings) 
                        : State.quiz.section_settings;
                } catch(e) {}
            }
            if (sectionSettings && sectionSettings[q.section_name]) {
                var sSet = sectionSettings[q.section_name];
                if (sSet.positive_marks !== undefined && sSet.positive_marks !== null && sSet.positive_marks !== "") {
                    positive = parseFloat(sSet.positive_marks);
                }
                if (sSet.negative_marks !== undefined && sSet.negative_marks !== null && sSet.negative_marks !== "") {
                    negative = parseFloat(sSet.negative_marks);
                }
            }

            // 2. Process Question Level Overrides
            if (q.positive_marks !== undefined && q.positive_marks !== null && q.positive_marks !== "") {
                positive = parseFloat(q.positive_marks);
            }
            if (q.negative_marks !== undefined && q.negative_marks !== null && q.negative_marks !== "") {
                negative = parseFloat(q.negative_marks);
            }

            // Update badge displays
            $('.ceq-pos-badge').text('+' + positive);
            $('.ceq-neg-badge').text('-' + negative);

            // Activate section tab highlighting
            $('.ceq-sec-tab').removeClass('ceq-active-tab');
            $('.ceq-sec-tab[data-section="' + q.section_name + '"]').addClass('ceq-active-tab');

            // Set question title headers
            $('#ceq-question-number-badge').text('Question No. ' + (index + 1) + ' (' + q.section_name + ')');

            // Inject body
            var qContent = '<div class="ceq-q-text">' + q.question_text + '</div>';
            if (q.question_image && q.question_image.trim() !== '') {
                qContent += '<div class="ceq-q-image-wrap" style="margin-top: 15px; margin-bottom: 15px;">' +
                            '<img src="' + q.question_image + '" style="max-height: 250px; max-width: 100%; border: 1px solid #E2E8F0; border-radius: 4px; display: block;" alt="Question Attachment" />' +
                            '</div>';
            }
            $('#ceq-question-body-viewport').html(qContent);

            // Populate Multiple Choices list
            var optionsBox = $('#ceq-options-viewport');
            optionsBox.empty();

            var bulletLetters = ['A', 'B', 'C', 'D'];
            q.options.forEach(function(opt, idx) {
                var isSelected = (State.answers[q.id] === idx) ? 'selected' : '';
                
                var optImgHtml = '';
                if (q.option_images && q.option_images[idx] && q.option_images[idx].trim() !== '') {
                    optImgHtml = '<div class="ceq-opt-image-wrap" style="margin-top: 8px;">' +
                                     '<img src="' + q.option_images[idx] + '" style="max-height: 140px; max-width: 100%; border: 1px solid #E2E8F0; border-radius: 6px; padding: 4px; background: #fff;" alt="Option Attachment" />' +
                                 '</div>';
                }

                var optRow = $(
                    '<div class="ceq-opt-row ' + isSelected + '" data-index="' + idx + '" style="display: flex; flex-direction: column; align-items: flex-start; gap: 4px; width: 100%;">' +
                        '<div style="display: flex; align-items: center; width: 100%;">' +
                            '<span class="ceq-opt-bullet">' + bulletLetters[idx] + '</span>' +
                            '<span class="ceq-opt-text">' + (opt ? opt : '') + '</span>' +
                        '</div>' +
                        optImgHtml +
                    '</div>'
                );
                optionsBox.append(optRow);

                optRow.on('click', function() {
                    $('.ceq-opt-row').removeClass('selected');
                    $(this).addClass('selected');
                    State.answers[q.id] = idx;
                    State.palette_status[q.id] = 'answered';
                    updatePaletteGrid();
                });
            });

            // Set current state to not-answered if it is still not-visited
            if (State.palette_status[q.id] === 'not-visited') {
                State.palette_status[q.id] = 'not-answered';
            }

            // Sync visual button matrix grid palette highlights
            updatePaletteGrid();
        }

        // Active Button Palette Matrix update
        function updatePaletteGrid() {
            var grid = $('#ceq-palette-grid');
            grid.empty();

            var countNotVisited = 0;
            var countNotAnswered = 0;
            var countAnswered = 0;
            var countMarked = 0;
            var countAnsweredMarked = 0;

            State.questions.forEach(function(q, idx) {
                var status = State.palette_status[q.id];
                var statusClass = 'item-not-visited';

                if (status === 'not-visited') {
                    countNotVisited++;
                } else if (status === 'not-answered') {
                    statusClass = 'item-not-answered';
                    countNotAnswered++;
                } else if (status === 'answered') {
                    statusClass = 'item-answered';
                    countAnswered++;
                } else if (status === 'marked') {
                    statusClass = 'item-marked';
                    countMarked++;
                } else if (status === 'answered-marked') {
                    statusClass = 'item-answered-marked';
                    countAnsweredMarked++;
                }

                // Highlight active item border
                var borderStyle = (idx === State.current_question_idx) ? 'border: 2px solid #2B6CB0; outline:2px solid gold;' : '';
                var btn = $('<button class="ceq-palette-btn ' + statusClass + '" style="' + borderStyle + '" data-index="' + idx + '">' + (idx + 1) + '</button>');
                grid.append(btn);

                btn.on('click', function() {
                    renderQuestion(idx);
                });
            });

            // Update Legends badge counts
            $('.ceq-legend-item:nth-child(1) .legend-box').text(countNotVisited);
            $('.ceq-legend-item:nth-child(2) .legend-box').text(countNotAnswered);
            $('.ceq-legend-item:nth-child(3) .legend-box').text(countAnswered);
            $('.ceq-legend-item:nth-child(4) .legend-box').text(countMarked);
            $('.ceq-legend-item:nth-child(5) .legend-box').text(countAnsweredMarked);
        }

        // Start real-time digital timer decrements
        function startTickingClock() {
            // Keep actual Target End Timestamp to withstand mobile standby sleep / screens off
            State.exam_end_timestamp = Date.now() + (State.timer_seconds_left * 1000);

            State.timer_interval_id = setInterval(function() {
                var msLeft = State.exam_end_timestamp - Date.now();
                State.timer_seconds_left = Math.max(0, Math.ceil(msLeft / 1000));

                if (State.timer_seconds_left <= 0) {
                    State.timer_seconds_left = 0;
                    clearInterval(State.timer_interval_id);
                    alert('Time limit expired! Your examination is being submitted automatically.');
                    submitExam();
                }

                // Convert seconds value to hh:mm:ss format strings
                var hrs = Math.floor(State.timer_seconds_left / 3600);
                var mins = Math.floor((State.timer_seconds_left % 3600) / 60);
                var secs = State.timer_seconds_left % 60;

                var displayString = 
                    (hrs < 10 ? '0' + hrs : hrs) + ':' +
                    (mins < 10 ? '0' + mins : mins) + ':' +
                    (secs < 10 ? '0' + secs : secs);

                $('#ceq-countdown-timer').text(displayString);

                // Flash color alert when under 3 mins left
                if (State.timer_seconds_left < 180) {
                    $('#ceq-countdown-timer').css('color', '#E53E3E').addClass('flash-toggle');
                }
            }, 1000);
        }

        // Central Anti-cheat telemetry window listeners
        function bindAntiCheatAuditors() {
            $(window).off('blur.ceq').on('blur.ceq', function() {
                if (State.exam_submitted) return;

                State.cheating_alerts++;
                var timestamp = new Date().toLocaleTimeString();
                State.cheating_history.push({
                    type: 'Tab switch / Window blur action detected',
                    time: timestamp
                });

                // Display warning warning triggers
                displayCheatNotice(State.cheating_alerts);
            });
        }

        function displayCheatNotice(count) {
            var maxAllowedWarnings = 3;
            var remaining = maxAllowedWarnings - count;

            // Purge existing modal layers first
            $('#ceq-cheat-shroud').remove();

            if (remaining <= 0) {
                // Instantly auto-submit exam upon breach
                var submitedAlert = $(
                    '<div id="ceq-cheat-shroud" class="ceq-cheat-indicator-curtain">' +
                        '<div class="ceq-cheat-modal">' +
                            '<h2>🔴 Assessment Disqualified</h2>' +
                            '<p style="color:red; font-weight:700;">Cheat shield threshold breached! Multiple window out-of-focus tab movements detected.</p>' +
                            '<p>Your test scores are being archived for administrative review.</p>' +
                        '</div>' +
                    '</div>'
                );
                $('body').append(submitedAlert);
                submitExam();
            } else {
                var alertBox = $(
                    '<div id="ceq-cheat-shroud" class="ceq-cheat-indicator-curtain">' +
                        '<div class="ceq-cheat-modal">' +
                            '<h2>⚠️ Anti-Cheat Warning</h2>' +
                            '<p style="font-size:15px; font-weight:500;">You navigated outside the active assessment frame. Switch-tabs or minimizing the viewport are strictly forbidden.</p>' +
                            '<p style="font-size:18px; color:#c53030; font-weight:700;">Violation Strike: ' + count + '/' + maxAllowedWarnings + '</p>' +
                            '<p>Your exam contains sensitive anti-cheat log reporting. Autoclose triggers in 3 warnings.</p>' +
                            '<button id="ceq-btn-dismiss-cheat-warning" class="ceq-btn ceq-btn-primary" style="margin-top:15px;">Acknowledge & Resume</button>' +
                        '</div>' +
                    '</div>'
                );
                $('body').append(alertBox);

                // Exit native fullscreen temporarily on error screen so we grab attention
                $('#ceq-btn-dismiss-cheat-warning').on('click', function() {
                    $('#ceq-cheat-shroud').remove();
                    // Attempt native HTML5 browser full screen request again to return
                    try {
                        var docEl = document.documentElement;
                        if (docEl.requestFullscreen) docEl.requestFullscreen();
                    } catch (err) {}
                });
            }
        }

        // Action handles click events
        function bindWorkspaceEvents() {
            // "Save & Next" click handle
            $('#ceq-btn-save-next').off('click').on('click', function(e) {
                e.preventDefault();
                var q = State.questions[State.current_question_idx];

                if (State.answers[q.id] === undefined) {
                    State.palette_status[q.id] = 'not-answered';
                } else {
                    State.palette_status[q.id] = 'answered';
                }

                // Proceed to next numerical index
                if (State.current_question_idx < State.questions.length - 1) {
                    renderQuestion(State.current_question_idx + 1);
                } else {
                    alert('You have reached the end of the question bank. Click Submit when completed.');
                    updatePaletteGrid();
                }
            });

            // "Mark for Review & Next" click handle
            $('#ceq-btn-mark-review').off('click').on('click', function(e) {
                e.preventDefault();
                var q = State.questions[State.current_question_idx];

                if (State.answers[q.id] === undefined) {
                    State.palette_status[q.id] = 'marked';
                } else {
                    State.palette_status[q.id] = 'answered-marked';
                }

                // Proceed next
                if (State.current_question_idx < State.questions.length - 1) {
                    renderQuestion(State.current_question_idx + 1);
                } else {
                    updatePaletteGrid();
                    alert('You are on the final question. Review item is registered.');
                }
            });

            // "Clear Response" click handle
            $('#ceq-btn-clear-response').off('click').on('click', function(e) {
                e.preventDefault();
                var q = State.questions[State.current_question_idx];

                delete State.answers[q.id];
                State.palette_status[q.id] = 'not-answered';
                $('.ceq-opt-row').removeClass('selected');
                updatePaletteGrid();
            });

            // "Submit Examination" click handle
            $('#ceq-btn-final-submit').off('click').on('click', function(e) {
                e.preventDefault();
                var ansCount = Object.keys(State.answers).length;
                var total = State.questions.length;
                
                var confirmText = 
                    "Are you sure you want to finalize and submit the exam?\n\n" +
                    "Questions Solved: " + ansCount + " / " + total + "\n" +
                    "Time Remaining: " + $('#ceq-countdown-timer').text() + "\n\n" +
                    "Click OK to post grades permanently.";

                if (confirm(confirmText)) {
                    submitExam();
                }
            });
        }

        // Submits client grades via AJAX
        function submitExam() {
            if (State.exam_submitted) return;
            State.exam_submitted = true;

            // Turn off timers
            clearInterval(State.timer_interval_id);

            // Deregister beforeunload exit alerts and wake locks
            $(window).off('beforeunload.ceq_warn');
            $(document).off('visibilitychange.ceq_wake');
            releaseScreenWakeLock();

            // Restore the exam portal back inside its original location in the WordPress theme page template flow
            if ($('#ceq-exam-portal-placeholder').length > 0) {
                $('#ceq-exam-portal-container').insertAfter('#ceq-exam-portal-placeholder');
            }

            // Close fullscreen class styling
            $('#ceq-exam-portal-container').removeClass('ceq-fullscreen-active');
            $('body').removeClass('ceq-body-lock');
            try {
                if (document.exitFullscreen) document.exitFullscreen();
                else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
                else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
                else if (document.msExitFullscreen) document.msExitFullscreen();
            } catch (err) {}

            // Hide warning curtain windows
            $('#ceq-cheat-shroud').remove();

            var totalTimeTaken = State.timer_total_seconds - State.timer_seconds_left;

            // Post AJAX results payload block
            $('#ceq-exam-workspace').addClass('ceq-hidden');
            $('body').append('<div id="ceq-submitting-spinner" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(255,255,255,0.9); z-index:9999; display:flex; flex-direction:column; align-items:center; justify-content:center;"><h2>Processing assessment metrics safely...</h2></div>');

            $.ajax({
                url: State.ajax_url,
                method: 'POST',
                data: {
                    action: 'ceq_submit_quiz_answers',
                    security: State.nonce,
                    quiz_id: State.quiz_id,
                    candidate_name: State.candidate_name,
                    candidate_father_name: State.candidate_father_name,
                    candidate_email: State.candidate_email,
                    candidate_phone: State.candidate_phone,
                    answers: JSON.stringify(State.answers),
                    time_taken: totalTimeTaken,
                    cheat_alerts: State.cheating_alerts,
                    cheat_incidents: JSON.stringify(State.cheating_history)
                },
                success: function(response) {
                    $('#ceq-submitting-spinner').remove();

                    if (response.success) {
                        displayPerformanceReportCard(response.data);
                    } else {
                        alert('Critical submissions failed: ' + response.data.message);
                    }
                },
                error: function() {
                    $('#ceq-submitting-spinner').remove();
                    alert('Submission connection broken. Retrying endpoint sequence.');
                }
            });
        }

        // Displays detailed reports and public leaderboard updates
        function displayPerformanceReportCard(resData) {
            $('#ceq-results-screen').removeClass('ceq-hidden');
            
            // Set labels
            $('#ceq-report-name').text(resData.candidate_name);
            $('#ceq-report-grading').text(resData.has_passed ? 'PASSED (QUALIFIED)' : 'FAILED (NOT QUALIFIED)')
                .css('color', resData.has_passed ? '#48BB78' : '#F56565');

            $('#ceq-metric-score').text(resData.total_score);
            $('#ceq-metric-correct').text(resData.correct_count);
            $('#ceq-metric-incorrect').text(resData.incorrect_count);
            $('#ceq-metric-unanswered').text(resData.unanswered);

            // Render Answer explanations and solutions review
            var reviewList = $('#ceq-explanations-review-list');
            reviewList.empty();

            if (resData.questions_review && resData.questions_review.length > 0) {
                resData.questions_review.forEach(function(q, idx) {
                    var userAnsIdx = resData.user_answers[q.id];
                    var correctIdx = parseInt(q.correct_option_index, 10);
                    var isCorrect = (userAnsIdx !== undefined && parseInt(userAnsIdx, 10) === correctIdx);
                    
                    var statusBadge = '';
                    var statusBorder = '';
                    if (userAnsIdx === undefined || userAnsIdx === null || userAnsIdx === '') {
                        statusBadge = '<span class="ceq-pos-badge" style="background:#EDF2F7; color:#4A5568; border:1px solid #CBD5E0; border-radius:4px; padding:2px 8px; font-size:12px; font-weight:600;">Unanswered</span>';
                        statusBorder = 'border-left: 5px solid #A0AEC0;';
                    } else if (isCorrect) {
                        statusBadge = '<span class="ceq-pos-badge" style="background:#F0FFF4; color:#38A169; border:1px solid #C6F6D5; border-radius:4px; padding:2px 8px; font-size:12px; font-weight:600;">✓ Correct</span>';
                        statusBorder = 'border-left: 5px solid #48BB78;';
                    } else {
                        statusBadge = '<span class="ceq-pos-badge" style="background:#FFF5F5; color:#E53E3E; border:1px solid #FEB2B2; border-radius:4px; padding:2px 8px; font-size:12px; font-weight:600;">✗ Incorrect</span>';
                        statusBorder = 'border-left: 5px solid #F56565;';
                    }

                    var qBox = $('<div class="ceq-q-review-box" style="margin-bottom:20px; padding:15px; background:#F8FAFC; border-radius:6px; border:1px solid #E2E8F0; ' + statusBorder + '"></div>');
                    var qTitle = $('<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><strong style="color:#1A365D;">Question ' + (idx + 1) + ' (' + q.section_name + ')</strong>' + statusBadge + '</div>');
                    var qText = $('<div style="margin-bottom:12px; font-weight:500;">' + q.question_text + '</div>');
                    if (q.question_image && q.question_image.trim() !== '') {
                        qText.append('<div style="margin-top:10px; margin-bottom:10px;"><img src="' + q.question_image + '" style="max-height: 180px; max-width: 100%; border: 1px solid #E2E8F0; border-radius: 4px; display: block;" alt="Question Attachment" /></div>');
                    }
                    
                    var oList = $('<div style="display:grid; grid-template-columns:1fr; gap:8px; margin-bottom:12px;"></div>');
                    var bulletLetters = ['A', 'B', 'C', 'D'];
                    q.options.forEach(function(opt, oIdx) {
                        var oStyle = 'padding:8px 12px; border:1px solid #E2E8F0; border-radius:4px; font-size:13px; display:flex; flex-direction:column; align-items:flex-start; gap:6px;';
                        var prefixStyle = 'display:inline-block; font-weight:700; border-radius:12px; padding:2px 6px; background:#E2E8F0; font-size:11px;';
                        
                        if (oIdx === correctIdx) {
                            oStyle += 'background:#E6FFFA; border-color:#81E6D9; font-weight:600; color:#0D9488;';
                            prefixStyle = 'display:inline-block; font-weight:700; border-radius:12px; padding:2px 6px; background:#319795; color:#ffffff; font-size:11px;';
                        } else if (userAnsIdx !== undefined && parseInt(userAnsIdx, 10) === oIdx) {
                            oStyle += 'background:#FFF5F5; border-color:#FEB2B2; font-weight:600; color:#9B2C2C;';
                            prefixStyle = 'display:inline-block; font-weight:700; border-radius:12px; padding:2px 6px; background:#C53030; color:#ffffff; font-size:11px;';
                        }
                        
                        var optImgHtml = '';
                        if (q.option_images && q.option_images[oIdx] && q.option_images[oIdx].trim() !== '') {
                            optImgHtml = '<div class="ceq-opt-image-wrap" style="margin-top:4px;">' +
                                             '<img src="' + q.option_images[oIdx] + '" style="max-height:80px; max-width:100%; border:1px solid #E2E8F0; border-radius:4px; padding:2px; background:#fff;" />' +
                                         '</div>';
                        }

                        oList.append(
                            '<div style="' + oStyle + '">' +
                                '<div style="display:flex; align-items:center; gap:10px;">' +
                                    '<span style="' + prefixStyle + '">' + bulletLetters[oIdx] + '</span> ' + (opt ? opt : '') +
                                '</div>' +
                                optImgHtml +
                            '</div>'
                        );
                    });

                    var expPart = $('<div style="background:#EDF2F7; padding:12px; border-radius:4px; font-size:13px; color:#4A5568;"><strong style="color:#2D3748;">Explanation:</strong> ' + (q.explanation || 'No explanation provided for this question.') + '</div>');

                    qBox.append(qTitle).append(qText).append(oList).append(expPart);
                    reviewList.append(qBox);
                });
            } else {
                reviewList.append('<p style="color:#718096; text-align:center;">No question review details available.</p>');
            }

            // Initially collapse solutions review list behind toggle button
            $('#ceq-explanations-review-container').addClass('ceq-hidden');
            $('#ceq-btn-toggle-solutions').html('🔍 See Result Analysis').off('click').on('click', function() {
                var container = $('#ceq-explanations-review-container');
                if (container.hasClass('ceq-hidden')) {
                    container.removeClass('ceq-hidden');
                    $(this).html('❌ Hide Result Analysis');
                    // Smoothly scroll container into focus
                    container[0].scrollIntoView({ behavior: 'smooth' });
                } else {
                    container.addClass('ceq-hidden');
                    $(this).html('🔍 See Result Analysis');
                }
            });

            // Scroll report card view into focal perspective
            document.getElementById('ceq-results-screen').scrollIntoView({ behavior: 'smooth' });

            // Fetch latest real-time leaderboard ranking
            refreshLeaderboard();

            // Bind Certificate download Click Event
            $('#ceq-btn-download-pdf').off('click').on('click', function() {
                generatePDFReport(resData);
            });
        }

        // Refreshes public highscore leaders list
        function refreshLeaderboard() {
            $.ajax({
                url: State.ajax_url,
                method: 'POST',
                data: {
                    action: 'ceq_load_leaderboard',
                    quiz_id: State.quiz_id
                },
                success: function(response) {
                    if (response.success) {
                        var list = response.data;
                        var tBody = $('#ceq-leaderboard-table tbody');
                        tBody.empty();

                        list.forEach(function(row, idx) {
                            var dateObj = new Date(row.created_at);
                            var formattedDate = dateObj.toLocaleDateString() + ' ' + dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

                            var flagText = (parseInt(row.cheating_alerts_count) > 0) 
                                ? '<span style="color:#e53e3e; font-weight:700;">⚠ Blocked (' + row.cheating_alerts_count + ')</span>' 
                                : '<span style="color:#48bb78;">✔ Verified</span>';

                            var activeHighlight = (row.candidate_name === State.candidate_name) ? 'background: #ebf8ff; font-weight: 700;' : '';

                            var tableRow = $(
                                '<tr style="' + activeHighlight + '">' +
                                    '<td style="font-weight:700;">#' + (idx + 1) + '</td>' +
                                    '<td>' + row.candidate_name + '</td>' +
                                    '<td style="font-weight:700; color:#2B6CB0;">' + row.score + '</td>' +
                                    '<td>' + formatDuration(row.time_taken_seconds) + '</td>' +
                                    '<td>' + flagText + '</td>' +
                                '</tr>'
                            );
                            tBody.append(tableRow);
                        });
                    }
                }
            });
        }

        // Simple duration converter
        function formatDuration(seconds) {
            var m = Math.floor(seconds / 60);
            var s = seconds % 60;
            return (m < 10 ? '0' + m : m) + 'm ' + (s < 10 ? '0' + s : s) + 's';
        }

        // Production-quality multi-line jsPDF result certificate exporter
        function generatePDFReport(resData) {
            var { jsPDF } = window.jspdf;
            if (!jsPDF) {
                alert('jsPDF dependency was blocked. Certificate could not be compiled locally.');
                return;
            }

            var doc = new jsPDF('p', 'mm', 'a4');

            // 1. Double Border Frame
            // Outer border (thick dark blue)
            doc.setDrawColor(26, 54, 93);
            doc.setLineWidth(0.8);
            doc.rect(8, 8, 194, 281);

            // Inner border (thin orange/red)
            doc.setDrawColor(197, 48, 48);
            doc.setLineWidth(0.3);
            doc.rect(9.5, 9.5, 191, 278);

            // 2. MD DEFENCE ACADEMY Header Banner Block (Dark Blue)
            doc.setFillColor(26, 54, 93);
            doc.rect(12, 12, 186, 36, 'F');

            doc.setTextColor(255, 255, 255);
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(20);
            doc.text("MD DEFENCE ACADEMY", 105, 21, { align: 'center' });

            doc.setFont('Helvetica', 'normal');
            doc.setFontSize(9);
            doc.text("Apollo Road, Opposite Old Satsang Bhavan, Jind, Haryana (126102)", 105, 27, { align: 'center' });

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(255, 215, 0); // Gold/yellow color
            doc.text("Phone: +91 9991200989 | Email: mdsshighschool1991@gmail.com", 105, 33, { align: 'center' });

            // 3. Sub-header bar "SCHOLASTIC ACADEMIC PERFORMANCE REPORT CARD"
            doc.setFillColor(235, 248, 255);
            doc.setDrawColor(144, 205, 244);
            doc.setLineWidth(0.3);
            doc.rect(12, 51, 186, 12, 'FD');

            doc.setTextColor(26, 54, 93);
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(11);
            doc.text("SCHOLASTIC ACADEMIC PERFORMANCE REPORT CARD", 105, 58.5, { align: 'center' });

            // 4. Candidate & Exam specifications block
            doc.setFillColor(255, 255, 255);
            doc.setDrawColor(226, 232, 240);
            doc.setLineWidth(0.3);
            doc.rect(12, 67, 186, 36, 'FD');
            doc.line(105, 67, 105, 103); // Vertical divider

            // Left Column: Candidate Profile Records
            doc.setTextColor(221, 107, 32); // Orange title
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(10);
            doc.text("CANDIDATE PROFILE RECORDS", 15, 73);

            doc.setFontSize(9);
            doc.setTextColor(74, 85, 104);
            doc.setFont('Helvetica', 'normal');
            doc.text("Candidate Name:", 15, 80);
            doc.text("Mobile Number:", 15, 86);
            doc.text("E-Mail Address:", 15, 92);

            doc.setTextColor(26, 32, 44);
            doc.setFont('Helvetica', 'bold');
            doc.text(resData.candidate_name, 48, 80);
            doc.text(resData.candidate_phone || State.candidate_phone || "+919462481088", 48, 86);
            doc.text(resData.candidate_email || State.candidate_email || "test@test.com", 48, 92);

            // Right Column: Examination Specifications
            doc.setTextColor(221, 107, 32);
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(10);
            doc.text("EXAMINATION SPECIFICATIONS", 108, 73);

            doc.setFontSize(9);
            doc.setTextColor(74, 85, 104);
            doc.setFont('Helvetica', 'normal');
            doc.text("Assessed Title:", 108, 80);
            doc.text("Subject Code:", 108, 86);
            doc.text("Report Date:", 108, 92);

            var qTitle = resData.quiz_title || (State.quizzes && State.quizzes[State.selectedQuizId] ? State.quizzes[State.selectedQuizId].title : "Competitive Mock Examination");
            var qCode = resData.subject_code || (State.quizzes && State.quizzes[State.selectedQuizId] ? State.quizzes[State.selectedQuizId].subject_code : "CEQ-CBT-WP");

            doc.setTextColor(26, 32, 44);
            doc.setFont('Helvetica', 'bold');
            doc.text(String(qTitle), 138, 80);
            doc.text(String(qCode || "CEQ-CBT-WP"), 138, 86);
            doc.text(resData.created_at ? new Date(resData.created_at.replace(' ', 'T')).toLocaleString() : new Date().toLocaleString(), 138, 92);

            // 5. Aggregate Status Card
            var isPassed = !!resData.has_passed;

            if (isPassed) {
                doc.setFillColor(240, 255, 244); // Light Green
                doc.setDrawColor(198, 246, 213);
            } else {
                doc.setFillColor(255, 245, 245); // Light Pink
                doc.setDrawColor(254, 215, 215);
            }
            doc.setLineWidth(0.3);
            doc.rect(12, 107, 186, 36, 'FD');
            doc.line(75, 107, 75, 143); // Compartment line

            // Left Compartment text
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(10);
            if (isPassed) {
                doc.setTextColor(34, 84, 61); // dark green
                doc.text("AGGREGATE STATUS", 43.5, 117, { align: 'center' });
                doc.setFontSize(11);
                doc.text("PASSED / QUALIFIED", 43.5, 128, { align: 'center' });
            } else {
                doc.setTextColor(116, 42, 42); // dark red
                doc.text("AGGREGATE STATUS", 43.5, 117, { align: 'center' });
                doc.setFontSize(11);
                doc.text("FAILED / DID NOT QUALIFY", 43.5, 128, { align: 'center' });
            }

            // Right Compartment text
            doc.setFontSize(9.5);
            doc.setTextColor(74, 85, 104);
            doc.setFont('Helvetica', 'normal');
            doc.text("Final Points Obtained:", 80, 116);
            doc.text("Total Correct Keys:", 80, 124);
            doc.text("Incorrect Responses:", 80, 132);

            var correctCount = parseInt(resData.correct_count || 0, 10);
            var incorrectCount = parseInt(resData.incorrect_count || 0, 10);
            var unansweredCount = parseInt(resData.unanswered || 0, 10);

            doc.setTextColor(26, 32, 44);
            doc.setFont('Helvetica', 'bold');
            doc.text(resData.total_score + " Marks", 128, 116);
            doc.text(correctCount + " Questions Passed", 128, 124);
            doc.text(incorrectCount + " Incorrect / " + unansweredCount + " Blank", 128, 132);

            // 6. Section-wise scores table
            doc.setTextColor(26, 54, 93);
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(11);
            doc.text("SECTION-WISE LEDGER SUMMARY OF SCHOLASTIC SCORES", 12, 152);

            // Table Header
            doc.setFillColor(26, 54, 93);
            doc.rect(12, 156, 186, 8, 'F');

            doc.setTextColor(255, 255, 255);
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(8.5);
            doc.text("SECTION GROUP", 15, 161.5);
            doc.text("CORRECT CHECKS", 95, 161.5, { align: 'center' });
            doc.text("INCORRECT ATTEMPTS", 142, 161.5, { align: 'center' });
            doc.text("SECTION SCORE", 192, 161.5, { align: 'right' });

            // Table Rows
            var rY = 164;
            Object.keys(resData.section_scores).forEach(function(secName) {
                var val = resData.section_scores[secName];
                // Horizontal cell lines
                doc.setDrawColor(226, 232, 240);
                doc.setLineWidth(0.2);
                doc.line(12, rY + 8.5, 198, rY + 8.5);

                doc.setTextColor(45, 55, 72);
                doc.setFont('Helvetica', 'bold');
                doc.setFontSize(9);
                doc.text(secName, 15, rY + 5.5);

                doc.setFont('Helvetica', 'normal');
                doc.text(String(val.correct || 0), 95, rY + 5.5, { align: 'center' });
                doc.text(String(val.incorrect || 0), 142, rY + 5.5, { align: 'center' });

                doc.setFont('Helvetica', 'bold');
                doc.setTextColor(26, 54, 93);
                doc.text(val.score + " Marks", 192, rY + 5.5, { align: 'right' });

                rY += 8.5;
            });

            // 7. Anti-cheat integrity block
            var cheatsCount = parseInt(resData.cheating_alerts || State.cheating_alerts || 0, 10);
            if (cheatsCount > 0) {
                doc.setFillColor(255, 251, 235); // Light Yellow
                doc.setDrawColor(254, 243, 199);
                doc.rect(12, rY + 6, 186, 11, 'FD');
                doc.setTextColor(180, 83, 9);
                doc.setFont('Helvetica', 'bold');
                doc.setFontSize(8.5);
                doc.text("ANTI-CHEAT INTEGRITY STATUS:", 15, rY + 13.5);
                doc.text("PROCTOR NOTICE: DETECTED " + cheatsCount + " SUSPICIOUS EVENT(S)", 71, rY + 13.5);
            } else {
                doc.setFillColor(236, 253, 245); // Light Green
                doc.setDrawColor(209, 250, 229);
                doc.rect(12, rY + 6, 186, 11, 'FD');
                doc.setTextColor(4, 120, 87);
                doc.setFont('Helvetica', 'bold');
                doc.setFontSize(8.5);
                doc.text("ANTI-CHEAT INTEGRITY STATUS:", 15, rY + 13.5);
                doc.text("NO SUSPICIOUS ACTIVITIES DETECTED - SECURE & ETHICAL PARTICIPATION", 71, rY + 13.5);
            }

            // 8. Signatures Block
            doc.setDrawColor(74, 85, 104);
            doc.setLineWidth(0.4);
            // Draw sign rules
            doc.line(20, rY + 39, 80, rY + 39);
            doc.line(130, rY + 39, 190, rY + 39);

            doc.setTextColor(74, 85, 104);
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(9.5);
            doc.text("Exam Incharge's Sign", 50, rY + 44, { align: 'center' });
            doc.text("Principal's Sign", 160, rY + 44, { align: 'center' });

            doc.setFont('Helvetica', 'normal');
            doc.setFontSize(7.5);
            doc.setTextColor(113, 128, 150);
            doc.text("(MD Defence Academy Seals)", 160, rY + 49, { align: 'center' });

            doc.save("ceq_report_card_" + resData.candidate_name.replace(/\s+/g, '_') + ".pdf");
        }

        // --- RESULTS CHECKER EXTENSIONS ---
        function bindResultsSearchEvents() {
            $('#ceq-btn-search-results').on('click', function(e) {
                e.preventDefault();
                performResultsSearch();
            });

            $('#ceq-search-phone').on('keypress', function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    performResultsSearch();
                }
            });
        }

        function performResultsSearch() {
            var phone = $('#ceq-search-phone').val().trim();
            var errorDiv = $('#ceq-search-error');
            var viewport = $('#ceq-search-results-viewport');
            var btn = $('#ceq-btn-search-results');

            if (!phone) {
                errorDiv.text('Please enter your registered mobile number.').show();
                return;
            }

            errorDiv.hide();
            btn.prop('disabled', true).html('Searching...');
            viewport.html('<div style="text-align:center; padding:45px 15px;"><div class="ceq-loader" style="border:4px solid #e1e1e1; border-top:4px solid #1a365d; border-radius:50%; width:30px; height:30px; animation: spin 1s linear infinite; margin: 0 auto 15px;"></div>Retrieving candidate scorecards from our secure server...</div>');

            $.ajax({
                url: State.ajax_url,
                method: 'POST',
                data: {
                    action: 'ceq_check_online_results',
                    security: State.nonce,
                    candidate_phone: phone
                },
                success: function(response) {
                    btn.prop('disabled', false).html('🔍 Check Results');
                    if (response.success && response.data && response.data.length > 0) {
                        renderMatchedResultsHtml(response.data);
                    } else {
                        var msg = (response.data && response.data.message) ? response.data.message : 'No examination records found matching this mobile number.';
                        errorDiv.text(msg).show();
                        viewport.html('<div style="text-align: center; color: #a0aec0; padding: 40px; font-style: italic; font-size: 13px;">No results to display.</div>');
                    }
                },
                error: function() {
                    btn.prop('disabled', false).html('🔍 Check Results');
                    errorDiv.text('An error occurred during communication. Please try again.').show();
                    viewport.html('<div style="text-align: center; color: #a0aec0; padding: 40px; font-style: italic; font-size: 13px;">No results to display.</div>');
                }
            });
        }

        function renderMatchedResultsHtml(records) {
            var viewport = $('#ceq-search-results-viewport');
            viewport.empty();

            var wrapper = $('<div style="display:flex; flex-direction:column; gap:15px; margin-top:20px;"></div>');
            var topHeading = $('<span style="font-size: 11px; font-weight: 800; color: #718096; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 5px;">Matched Examination Results (' + records.length + ')</span>');
            viewport.append(topHeading);

            records.forEach(function(row) {
                var quizTitle = row.quiz_title || 'Competitive Mock Examination';
                var score = parseFloat(row.score);
                var passingScore = parseFloat(row.passing_score || 33);
                var hasPassed = score >= passingScore;

                var dateStr = 'Recently';
                if (row.created_at) {
                    try {
                        var dateObj = new Date(row.created_at.replace(' ', 'T'));
                        if (!isNaN(dateObj.getTime())) {
                            dateStr = dateObj.toLocaleDateString();
                        }
                    } catch(e) {}
                }

                var itemRow = $(
                    '<div class="ceq-matched-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; display: flex; flex-direction: row; justify-content: space-between; align-items: center; padding: 15px; transition: all 0.2s; gap: 15px; flex-wrap: wrap; box-shadow: 0 1px 3px rgba(0,0,0,0.02);">' +
                        '<div style="flex: 1; min-width: 200px; display: flex; flex-direction: column; gap: 6px;">' +
                            '<div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">' +
                                '<span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background-color: ' + (hasPassed ? '#48bb78' : '#f56565') + ';"></span>' +
                                '<h4 style="margin: 0; font-size: 13.5px; font-weight: 700; color: #2d3748; font-family: sans-serif;">' + quizTitle + '</h4>' +
                            '</div>' +
                            '<div style="display: flex; flex-wrap: wrap; gap: 15px; color: #718096; font-size: 12px; font-family: sans-serif;">' +
                                '<span>Score: <strong style="color: #2d3748; font-weight: bold;">' + score + ' pts</strong></span>' +
                                '<span>Passed: <strong style="color: ' + (hasPassed ? '#2f855a' : '#c53030') + '; font-weight: bold;">' + (hasPassed ? 'YES' : 'NO') + '</strong></span>' +
                                '<span>Date: <strong style="font-family: monospace;">' + dateStr + '</strong></span>' +
                            '</div>' +
                        '</div>' +
                        '<div style="text-align: right; display: flex; align-items: center; justify-content: flex-end; width: auto; min-width: 130px;">' +
                            '<button class="ceq-btn ceq-btn-primary ceq-btn-view-detail" style="font-size: 11.5px; font-weight: 800; padding: 8px 16px; border-radius: 6px; cursor: pointer; border: none; text-transform: uppercase; tracking-wider; display: inline-flex; align-items: center; gap: 4px; white-space: nowrap;">Check Results</button>' +
                        '</div>' +
                    '</div>'
                );

                itemRow.find('.ceq-btn-view-detail').on('click', function(e) {
                    e.preventDefault();
                    renderDetailedPerformanceHtml(row, records);
                });

                wrapper.append(itemRow);
            });

            viewport.append(wrapper);
        }

        function renderDetailedPerformanceHtml(row, records) {
            var viewport = $('#ceq-search-results-viewport');
            viewport.empty();

            var quizTitle = row.quiz_title || 'Competitive Mock Examination';
            var score = parseFloat(row.score);
            var passingScore = parseFloat(row.passing_score || 33);
            var hasPassed = score >= passingScore;

            var dateStr = 'Recently';
            if (row.created_at) {
                try {
                    var dateObj = new Date(row.created_at.replace(' ', 'T'));
                    if (!isNaN(dateObj.getTime())) {
                        dateStr = dateObj.toLocaleDateString() + ' ' + dateObj.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
                    }
                } catch(e) {}
            }

            var correct_count = 0;
            var incorrect_count = 0;
            var unanswered_count = 0;
            var secScoresObj = {};

            if (typeof row.section_scores === 'string') {
                try {
                    secScoresObj = JSON.parse(row.section_scores);
                } catch (e) {}
            } else if (row.section_scores) {
                secScoresObj = row.section_scores;
            }

            if (secScoresObj && typeof secScoresObj === 'object') {
                Object.values(secScoresObj).forEach(function(sec) {
                    correct_count += parseInt(sec.correct || 0, 10);
                    incorrect_count += parseInt(sec.incorrect || 0, 10);
                    unanswered_count += parseInt(sec.unanswered || 0, 10);
                });
            }

            var detailedPage = $('<div style="display: flex; flex-direction: column; gap: 24px; padding-top: 10px;"></div>');

            // 1. Back Navigation & PDF Trigger Header Row
            var actionHeader = $(
                '<div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px; flex-wrap: wrap; gap: 12px;">' +
                    '<button class="ceq-btn-back-to-list" style="background: #edf2f7; border: 1px solid #cbd5e0; color: #4a5568; padding: 8px 14px; border-radius: 6px; font-size: 12.5px; font-weight: 700; cursor: pointer; transition: all 0.15s; display: inline-flex; align-items: center; gap: 6px; outline: none; box-sizing: border-box; line-height: 1;">← Back to Scorecards List</button>' +
                    '<button class="ceq-btn ceq-btn-success ceq-btn-detail-download" style="font-size: 12.5px; font-weight: 800; padding: 10px 20px; border-radius: 6px; display: inline-flex; align-items: center; gap: 6px; cursor: pointer; outline: none;">📥 Download PDF Report Card</button>' +
                '</div>'
            );

            actionHeader.find('.ceq-btn-back-to-list').on('click', function(e) {
                e.preventDefault();
                renderMatchedResultsHtml(records);
            });

            actionHeader.find('.ceq-btn-detail-download').on('click', function(e) {
                e.preventDefault();
                var pdfData = {
                    candidate_name: row.candidate_name,
                    candidate_phone: row.candidate_phone,
                    candidate_email: row.candidate_email,
                    total_score: score,
                    correct_count: correct_count,
                    incorrect_count: incorrect_count,
                    unanswered: unanswered_count,
                    has_passed: hasPassed,
                    section_scores: secScoresObj,
                    cheating_alerts: parseInt(row.cheating_alerts_count, 10),
                    created_at: row.created_at,
                    quiz_title: quizTitle,
                    subject_code: row.subject_code || 'CEQ-CBT-WP'
                };
                
                var old_phone = State.candidate_phone;
                var old_email = State.candidate_email;
                var old_alerts = State.cheating_alerts;
                
                State.candidate_phone = row.candidate_phone;
                State.candidate_email = row.candidate_email;
                State.cheating_alerts = parseInt(row.cheating_alerts_count,10);
                
                generatePDFReport(pdfData);
                
                State.candidate_phone = old_phone;
                State.candidate_email = old_email;
                State.cheating_alerts = old_alerts;
            });

            detailedPage.append(actionHeader);

            // 2. Profile Summary Info card
            var isQual = score >= passingScore;
            var statusBg = isQual ? '#c6f6d5' : '#fed7d7';
            var statusTextCol = isQual ? '#22543d' : '#742a2a';
            var statusBorderCol = isQual ? '#98e6ad' : '#feb5b5';
            var statusDisplayStr = isQual ? 'PASSED / QUALIFIED' : 'FAILED / DID NOT QUALIFY';

            var profileSection = $(
                '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 15px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; align-items: center;">' +
                    '<div>' +
                        '<span style="font-size: 10px; font-weight: 850; color: #a0aec0; text-transform: uppercase; tracking-wider; display: block; margin-bottom: 4px;">Candidate Verification Profile</span>' +
                        '<h4 style="margin: 0; font-size: 16px; font-weight: 800; color: #2d3748; font-family: sans-serif;">' + row.candidate_name + '</h4>' +
                        '<p style="margin: 4px 0 0; font-size: 12px; color: #718096; font-family: monospace;">' +
                            '📧 ' + row.candidate_email + ' | 📞 ' + row.candidate_phone +
                        '</p>' +
                    '</div>' +
                    '<div style="text-align: right; display: flex; flex-direction: column; justify-content: center; align-items: flex-end;">' +
                        '<span style="font-size: 10px; font-weight: 850; color: #a0aec0; text-transform: uppercase; tracking-wider; display: block; margin-bottom: 6px; text-align: right;">Scholastic Status</span>' +
                        '<span style="background: ' + statusBg + '; color: ' + statusTextCol + '; border: 1px solid ' + statusBorderCol + '; padding: 4px 12px; border-radius: 6px; font-size: 11px; font-weight: 800; text-transform: uppercase; tracking-wider; display: inline-block;">' +
                            statusDisplayStr +
                        '</span>' +
                    '</div>' +
                '</div>'
            );
            detailedPage.append(profileSection);

            // 3. Score Bento Metrics Cards Grid (Responsive)
            var bentoGrid = $(
                '<div>' +
                    '<span style="font-size: 10px; font-weight: 850; color: #a0aec0; text-transform: uppercase; tracking-wider; display: block; margin-bottom: 8px;">Grading Metrics Ledger</span>' +
                    '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; justify-content: stretch; text-align: center;">' +
                        '<div style="background: #ebf8ff; border: 1px solid #bee3f8; border-radius: 8px; padding: 12px; display: flex; flex-direction: column; justify-content: center;">' +
                            '<small style="font-size: 9px; font-weight: 850; color: #2b6cb0; text-transform: uppercase; tracking-wider; display: block;">Total Score</small>' +
                            '<h2 style="margin: 4px 0 0; font-size: 20px; font-weight: 900; color: #2b6cb0;">' + score + ' Marks</h2>' +
                        '</div>' +
                        '<div style="background: #f0fff4; border: 1px solid #c6f6d5; border-radius: 8px; padding: 12px; display: flex; flex-direction: column; justify-content: center;">' +
                            '<small style="font-size: 9px; font-weight: 850; color: #2f855a; text-transform: uppercase; tracking-wider; display: block;">Correct Choices</small>' +
                            '<h2 style="margin: 4px 0 0; font-size: 20px; font-weight: 900; color: #2f855a;">' + correct_count + ' Passed</h2>' +
                        '</div>' +
                        '<div style="background: #fff5f5; border: 1px solid #fed7d7; border-radius: 8px; padding: 12px; display: flex; flex-direction: column; justify-content: center;">' +
                            '<small style="font-size: 9px; font-weight: 850; color: #c53030; text-transform: uppercase; tracking-wider; display: block;">Incorrect choices</small>' +
                            '<h2 style="margin: 4px 0 0; font-size: 20px; font-weight: 900; color: #c53030;">' + incorrect_count + '</h2>' +
                        '</div>' +
                        '<div style="background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px; display: flex; flex-direction: column; justify-content: center;">' +
                            '<small style="font-size: 9px; font-weight: 850; color: #475569; text-transform: uppercase; tracking-wider; display: block;">Unanswered Left</small>' +
                            '<h2 style="margin: 4px 0 0; font-size: 20px; font-weight: 900; color: #475569;">' + unanswered_count + '</h2>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
            detailedPage.append(bentoGrid);

            // 4. Proctor Monitoring Alerts Strip
            var cheatCount = parseInt(row.cheating_alerts_count, 10);
            var monitoringHtml = '';
            if (cheatCount > 0) {
                monitoringHtml = 
                    '<div style="background: #1a202c; border: 1px solid #2d3748; border-radius: 8px; padding: 15px; color: #fff; font-family: sans-serif; font-size: 12px;">' +
                        '<h5 style="margin: 0 0 6px 0; font-size: 13px; font-weight: bold; color: #f6ad55; display: flex; align-items: center; gap: 6px;">' +
                            '🛡 Secure CBT Proctor Monitoring Logs:' +
                        '</h5>' +
                        '<p style="margin: 0; color: #cbd5e0; line-height: 1.5;">' +
                            'We have detected <strong style="color: #fff;">' + cheatCount + ' out-of-focus tab blurs</strong> during the examination course of this candidate.' +
                        '</p>' +
                        '<span style="background: rgba(155, 44, 44, 0.4); border: 1px solid #e53e3e; color: #fc8181; padding: 6px 10px; border-radius: 4px; font-size: 11px; display: block; margin-top: 10px; font-family: monospace;">' +
                            '⚠ PROCTOR INTEGRITY WARNING: Potential unauthorized web navigation logs registered on candidate terminal block.' +
                        '</span>' +
                    '</div>';
            } else {
                monitoringHtml = 
                    '<div style="background: #1a202c; border: 1px solid #2d3748; border-radius: 8px; padding: 15px; color: #fff; font-family: sans-serif; font-size: 12px;">' +
                        '<h5 style="margin: 0 0 6px 0; font-size: 13px; font-weight: bold; color: #f6ad55; display: flex; align-items: center; gap: 6px;">' +
                            '🛡 Secure CBT Proctor Monitoring Logs:' +
                        '</h5>' +
                        '<p style="margin: 0; color: #cbd5e0; line-height: 1.5;">' +
                            'We have detected <strong style="color: #fff;">0 out-of-focus tab blurs</strong> during the examination course of this candidate.' +
                        '</p>' +
                        '<span style="color: #68d391; font-weight: bold; font-size: 11px; display: block; margin-top: 8px;">' +
                            '✔ OK: Authentication logs verify healthy clean state. Full security compliance established.' +
                        '</span>' +
                    '</div>';
            }
            detailedPage.append($(monitoringHtml));

            // 5. Section scores summary ledger
            var sectionScoresGrid = $('<div style="display: flex; flex-direction: column; gap:8px;"></div>');
            sectionScoresGrid.append('<span style="font-size: 10px; font-weight: 850; color: #a0aec0; text-transform: uppercase; tracking-wider; display: block;">Section Scores Summary</span>');
            
            var cardWrapperGrid = $('<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 10px;"></div>');
            Object.keys(secScoresObj).forEach(function(secName) {
                var sMetric = secScoresObj[secName];
                var subCard = $(
                    '<div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; font-size: 12px; display: flex; flex-direction: column; gap: 4px;">' +
                        '<strong style="color: #4a5568; display: block; font-family: sans-serif;">📁 ' + secName + '</strong>' +
                        '<div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 11.5px; color: #718096; border-top: 1px dashed #e2e8f0; padding-top: 6px; margin-top: 2px;">' +
                            '<span>Score: <strong style="color:#2b6cb0;">' + sMetric.score + '</strong></span>' +
                            '<span>Correct: <span style="color:#2f855a; font-weight:bold;">' + sMetric.correct + '</span></span>' +
                            '<span>Wrong: <span style="color:#c53030; font-weight:bold;">' + sMetric.incorrect + '</span></span>' +
                        '</div>' +
                    '</div>'
                );
                cardWrapperGrid.append(subCard);
            });
            sectionScoresGrid.append(cardWrapperGrid);
            detailedPage.append(sectionScoresGrid);

            // 6. Dynamic Live Leaderboard scoreboard ranking card block
            var scoreBoardContainer = $('<div style="display: flex; flex-direction: column; gap: 8px; margin-top: 10px;"></div>');
            scoreBoardContainer.append(
                '<div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #edf2f7; padding-bottom: 6px;">' +
                    '<span style="font-size: 10px; font-weight: 850; color: #a0aec0; text-transform: uppercase; tracking-wider; display: block;">Leader Scoreboard Ranking</span>' +
                    '<span style="font-size: 10.5px; font-weight: 700; color: #2b6cb0; font-family: sans-serif;">' + quizTitle + '</span>' +
                '</div>'
            );

            var scoreboardTableWrapper = $('<div style="border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #fff;"></div>');
            scoreboardTableWrapper.html('<div style="text-align: center; color: #a0aec0; padding: 25px; font-style: italic; font-size: 12px;">Retrieving live comparative ranking...</div>');
            scoreBoardContainer.append(scoreboardTableWrapper);
            detailedPage.append(scoreBoardContainer);

            // 7. Solutions review collapsible container
            var SolutionsReviewContainer = $(
                '<div style="display: flex; flex-direction: column; gap: 12px; margin-top: 15px;">' +
                    '<div style="text-align: center; margin: 15px 0 5px 0;">' +
                        '<button class="ceq-btn ceq-btn-blue ceq-btn-toggle-detail-solutions" style="font-weight: 700; padding: 12px 24px; font-size: 14px; cursor: pointer; border-radius: 6px; outline: none;">🔍 See Result Analysis</button>' +
                    '</div>' +
                    '<div class="ceq-detail-explanations-container ceq-hidden" style="margin: 15px 0; padding: 25px; background: #ffffff; border: 1px solid #e1e7ec; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); text-align: left;">' +
                        '<h3 style="border-bottom: 2px solid #2B6CB0; padding-bottom: 8px; color: #1A365D; margin-top: 0; font-weight: 700; font-size: 18px;">Question Review, Answer Keys & Explanations</h3>' +
                        '<div class="ceq-detail-explanations-list" style="margin-top: 20px;">' +
                            '<div style="text-align: center; color: #a0aec0; padding: 20px; font-style: italic; font-size: 12px;">Loading detailed solutions review...</div>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
            detailedPage.append(SolutionsReviewContainer);

            viewport.html(detailedPage);

            var toggleBtn = SolutionsReviewContainer.find('.ceq-btn-toggle-detail-solutions');
            var solutionsListContainer = SolutionsReviewContainer.find('.ceq-detail-explanations-container');
            var explanationsList = SolutionsReviewContainer.find('.ceq-detail-explanations-list');

            toggleBtn.on('click', function(e) {
                e.preventDefault();
                if (solutionsListContainer.hasClass('ceq-hidden')) {
                    solutionsListContainer.removeClass('ceq-hidden');
                    toggleBtn.html('❌ Hide Result Analysis');
                    solutionsListContainer[0].scrollIntoView({ behavior: 'smooth' });
                } else {
                    solutionsListContainer.addClass('ceq-hidden');
                    toggleBtn.html('🔍 See Result Analysis');
                }
            });

            // Fire AJAX to fetch solutions
            $.ajax({
                url: State.ajax_url,
                method: 'POST',
                data: {
                    action: 'ceq_fetch_quiz_solutions',
                    security: State.nonce,
                    quiz_id: row.quiz_id
                },
                success: function(response) {
                    if (response.success && response.data && response.data.questions) {
                        explanationsList.empty();
                        var questions = response.data.questions;
                        var answers = (typeof row.answers === 'string') ? JSON.parse(row.answers) : row.answers;
                        if (!answers) answers = {};

                        questions.forEach(function(q, idx) {
                            var userAnsIdx = answers[q.id];
                            var correctIdx = parseInt(q.correct_option_index, 10);
                            var isCorrect = (userAnsIdx !== undefined && parseInt(userAnsIdx, 10) === correctIdx);
                            
                            var statusBadge = '';
                            var statusBorder = '';
                            if (userAnsIdx === undefined || userAnsIdx === null || userAnsIdx === '') {
                                statusBadge = '<span class="ceq-pos-badge" style="background:#EDF2F7; color:#4A5568; border:1px solid #CBD5E0; border-radius:4px; padding:2px 8px; font-size:12px; font-weight:600;">Unanswered</span>';
                                statusBorder = 'border-left: 5px solid #A0AEC0;';
                            } else if (isCorrect) {
                                statusBadge = '<span class="ceq-pos-badge" style="background:#F0FFF4; color:#38A169; border:1px solid #C6F6D5; border-radius:4px; padding:2px 8px; font-size:12px; font-weight:600;">✓ Correct</span>';
                                statusBorder = 'border-left: 5px solid #48BB78;';
                            } else {
                                statusBadge = '<span class="ceq-pos-badge" style="background:#FFF5F5; color:#E53E3E; border:1px solid #FEB2B2; border-radius:4px; padding:2px 8px; font-size:12px; font-weight:600;">✗ Incorrect</span>';
                                statusBorder = 'border-left: 5px solid #F56565;';
                            }

                            var qBox = $('<div class="ceq-q-review-box" style="margin-bottom:20px; padding:15px; background:#F8FAFC; border-radius:6px; border:1px solid #E2E8F0; ' + statusBorder + '"></div>');
                            var qTitle = $('<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><strong style="color:#1A365D;">Question ' + (idx + 1) + ' (' + q.section_name + ')</strong>' + statusBadge + '</div>');
                            var qText = $('<div style="margin-bottom:12px; font-weight:500;">' + q.question_text + '</div>');
                            if (q.question_image && q.question_image.trim() !== '') {
                                qText.append('<div style="margin-top:10px; margin-bottom:10px;"><img src="' + q.question_image + '" style="max-height: 180px; max-width: 100%; border: 1px solid #E2E8F0; border-radius: 4px; display: block;" alt="Question Attachment" /></div>');
                            }
                            
                            var oList = $('<div style="display:grid; grid-template-columns:1fr; gap:8px; margin-bottom:12px;"></div>');
                            var bulletLetters = ['A', 'B', 'C', 'D'];
                            q.options.forEach(function(opt, oIdx) {
                                var oStyle = 'padding:8px 12px; border:1px solid #E2E8F0; border-radius:4px; font-size:13px; display:flex; flex-direction:column; align-items:flex-start; gap:6px;';
                                var prefixStyle = 'display:inline-block; font-weight:700; border-radius:12px; padding:2px 6px; background:#E2E8F0; font-size:11px;';
                                
                                if (oIdx === correctIdx) {
                                    oStyle += 'background:#E6FFFA; border-color:#81E6D9; font-weight:600; color:#0D9488;';
                                    prefixStyle = 'display:inline-block; font-weight:700; border-radius:12px; padding:2px 6px; background:#319795; color:#ffffff; font-size:11px;';
                                } else if (userAnsIdx !== undefined && parseInt(userAnsIdx, 10) === oIdx) {
                                    oStyle += 'background:#FFF5F5; border-color:#FEB2B2; font-weight:600; color:#9B2C2C;';
                                    prefixStyle = 'display:inline-block; font-weight:700; border-radius:12px; padding:2px 6px; background:#C53030; color:#ffffff; font-size:11px;';
                                }
                                
                                var optImgHtml = '';
                                if (q.option_images && q.option_images[oIdx] && q.option_images[oIdx].trim() !== '') {
                                    optImgHtml = '<div class="ceq-opt-image-wrap" style="margin-top:4px;">' +
                                                     '<img src="' + q.option_images[oIdx] + '" style="max-height:80px; max-width:100%; border:1px solid #E2E8F0; border-radius:4px; padding:2px; background:#fff;" />' +
                                                 '</div>';
                                }

                                oList.append(
                                    '<div style="' + oStyle + '">' +
                                        '<div style="display:flex; align-items:center; gap:10px;">' +
                                            '<span style="' + prefixStyle + '">' + bulletLetters[oIdx] + '</span> ' + (opt ? opt : '') +
                                        '</div>' +
                                        optImgHtml +
                                    '</div>'
                                );
                            });

                            var expPart = $('<div style="background:#EDF2F7; padding:12px; border-radius:4px; font-size:13px; color:#4A5568;"><strong style="color:#2D3748;">Explanation:</strong> ' + (q.explanation || 'No explanation provided for this question.') + '</div>');

                            qBox.append(qTitle).append(qText).append(oList).append(expPart);
                            explanationsList.append(qBox);
                        });
                    } else {
                        explanationsList.html('<div style="text-align: center; color: #fc8181; padding: 20px; font-weight: bold;">Failed to load questions list or solutions review.</div>');
                    }
                },
                error: function() {
                    explanationsList.html('<div style="text-align: center; color: #fc8181; padding: 20px; font-weight: bold;">Failed to load questions list or solutions review.</div>');
                }
            });

            // AJAX call to retrieve live database rankings for scoreboard
            $.ajax({
                url: State.ajax_url,
                method: 'POST',
                data: {
                    action: 'ceq_load_leaderboard',
                    security: State.nonce,
                    quiz_id: row.quiz_id
                },
                success: function(response) {
                    if (response.success && response.data && response.data.length > 0) {
                        var tableHtml = 
                            '<div style="overflow-x: auto; width:100%; -webkit-overflow-scrolling: touch;">' +
                                '<table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 12px; margin: 0;">' +
                                    '<thead>' +
                                        '<tr style="background: #f7fafc; border-bottom: 1px solid #e2e8f0; color: #718096; font-weight: bold; text-transform: uppercase; font-size: 11px;">' +
                                            '<th style="padding: 10px 12px; text-align: center; width: 60px;">Rank No</th>' +
                                            '<th style="padding: 10px 12px;">Candidate Full Name</th>' +
                                            '<th style="padding: 10px 12px; text-align: center;">Marks Obtained</th>' +
                                            '<th style="padding: 10px 12px; text-align: center;">Duration</th>' +
                                            '<th style="padding: 10px 12px; text-align: center;">Status</th>' +
                                        '</tr>' +
                                    '</thead>' +
                                    '<tbody>';

                        response.data.forEach(function(entry, idx) {
                            var isCurrent = parseInt(entry.id, 10) === parseInt(row.id, 10);
                            var rowBg = isCurrent ? '#fffbeb' : '#ffffff';
                            var rowActiveBorder = isCurrent ? 'outline: 2px solid #f6ad55; font-weight: bold;' : '';
                            var badgeBg = '#edf2f7';
                            var badgeCol = '#4a5568';

                            if (idx === 0) {
                                badgeBg = '#feebc8';
                                badgeCol = '#c05621';
                            } else if (idx === 1) {
                                badgeBg = '#e2e8f0';
                                badgeCol = '#4a5568';
                            } else if (idx === 2) {
                                badgeBg = '#feebc8';
                                badgeCol = '#744210';
                            }

                            var rankBadge = '<span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; font-size: 10.5px; font-weight: 900; background: ' + badgeBg + '; color: ' + badgeCol + ';">' + (idx + 1) + '</span>';
                            
                            var entryScore = parseFloat(entry.score);
                            var isEntryPassed = entryScore >= passingScore;

                            tableHtml += 
                                '<tr style="background: ' + rowBg + '; border-bottom: 1px solid #edf2f7; ' + rowActiveBorder + '">' +
                                    '<td style="padding: 10px 12px; text-align: center;">' + rankBadge + '</td>' +
                                    '<td style="padding: 10px 12px; color: #2d3748; font-weight: ' + (isCurrent ? '700' : 'normal') + ';">' +
                                        entry.candidate_name + 
                                        (isCurrent ? ' <span style="background: #feebc8; color: #9c4221; font-size: 9px; font-weight: bold; text-transform: uppercase; padding: 2px 6px; border-radius: 4px; margin-left: 6px; border: 1px solid #fbd38d;">You</span>' : '') +
                                    '</td>' +
                                    '<td style="padding: 10px 12px; text-align: center; color: #2b6cb0; font-weight: bold;">' + entry.score + ' pts</td>' +
                                    '<td style="padding: 10px 12px; text-align: center; font-family: monospace; color: #718096;">' + formatDuration(entry.time_taken_seconds) + '</td>' +
                                    '<td style="padding: 10px 12px; text-align: center;">' +
                                        '<span style="background: ' + (isEntryPassed ? '#c6f6d5; color: #22543d;' : '#fed7d7; color: #742a2a;') + '; font-size: 9.5px; font-weight: 800; padding: 2px 8px; border-radius: 4px; text-transform: uppercase;">' + (isEntryPassed ? 'PASSED' : 'FAILED') + '</span>' +
                                    '</td>' +
                                '</tr>';
                        });

                        tableHtml += '</tbody></table></div>';
                        scoreboardTableWrapper.html(tableHtml);
                    } else {
                        scoreboardTableWrapper.html('<div style="text-align: center; color: #a0aec0; padding: 25px; font-style: italic; font-size: 12px;">No rankings available.</div>');
                    }
                },
                error: function() {
                    scoreboardTableWrapper.html('<div style="text-align: center; color: #fc8181; padding: 25px; font-weight: bold; font-size: 12px;">Failed to retrieve active comparative scoreboard.</div>');
                }
            });
        }

        // Fire Initialization triggers
        initApp();
    });

})(jQuery);
