/**
 * Competitive Exam Quiz - Standard Mock Data and Typings
 */

export interface Quiz {
  id: number;
  title: string;
  subject_code?: string;
  sections?: string; // Comma separated sections
  duration_mins: number;
  passing_score: number;
  positive_marks: number;
  negative_marks: number;
  starts_at?: string; // Future datetime string for scheduled exams
  created_at: string;
  status?: 'published' | 'draft';
  restrict_by_phone?: number; // 0 or 1
  allowed_phones?: string; // Comma separated list of phone numbers
  section_settings?: string; // JSON string mapping: { section_name: { positive_marks, negative_marks } }
}

export interface Question {
  id: number;
  quiz_id: number;
  section_name: string;
  question_text: string;
  options: string[];
  correct_option_index: number;
  explanation: string;
  positive_marks?: number; // Optional question-specific marks
  negative_marks?: number; // Optional question-specific negative marks
  question_image?: string; // Optional question-specific image URL or base64 data
  option_images?: string[]; // Optional option-specific image URL or base64 data array of size 4
}

export interface Result {
  id: number;
  quiz_id: number;
  candidate_name: string;
  candidate_father_name?: string;
  candidate_email: string;
  candidate_phone?: string;
  score: number;
  answers: Record<number, number>; // { question_id: selected_index }
  time_taken_seconds: number;
  cheating_alerts_count: number;
  section_scores: Record<string, {
    score: number;
    correct: number;
    incorrect: number;
    unanswered: number;
  }>;
  created_at: string;
}

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 1,
    title: "SSC CGL (Tier-I) Mock Assessment",
    subject_code: "SSC-CGL-2026",
    sections: "General Intelligence,General Awareness,Quantitative Aptitude,English Language",
    duration_mins: 15,
    passing_score: 33.0,
    positive_marks: 2.0,
    negative_marks: 0.5,
    created_at: "2026-05-26 10:00:00",
    status: "published"
  },
  {
    id: 2,
    title: "UPSC General Studies Paper-I Simulator",
    subject_code: "UPSC-GS-1",
    sections: "History,Polity,Geography,Economy,Science & Tech",
    duration_mins: 20,
    passing_score: 40.0,
    positive_marks: 2.0,
    negative_marks: 0.66,
    created_at: "2026-05-25 14:30:00",
    status: "published"
  }
];

export const INITIAL_QUESTIONS: Question[] = [
  // Quiz 1 Questions
  {
    id: 101,
    quiz_id: 1,
    section_name: "General Intelligence",
    question_text: "Identify the next element in the logical alphanumeric sequence: A1Z, C3X, E5V, G7T, ?",
    options: ["I9S", "H8S", "I9R", "J10R"],
    correct_option_index: 2,
    explanation: "Letters progress in steps of +2 (A -> C -> E -> G -> I). Digits increase by +2 (1 -> 3 -> 5 -> 7 -> 9). The third letters step backwards by -2 (Z -> X -> V -> T -> R). Thus, the correct next token is I9R."
  },
  {
    id: 102,
    quiz_id: 1,
    section_name: "General Intelligence",
    question_text: "Select the option that is related to the third number in the same way as the second number is related to the first number: 7 : 343 :: 9 : ?",
    options: ["512", "729", "1000", "243"],
    correct_option_index: 1,
    explanation: "The logic is num cubed. 7 cubed is 343. Similarly, 9 cubed is 729."
  },
  {
    id: 103,
    quiz_id: 1,
    section_name: "General Awareness",
    question_text: "Which layer of the atmosphere contains the ozone layer that protects life on Earth from harmful ultraviolet radiation?",
    options: ["Troposphere", "Stratosphere", "Mesosphere", "Thermosphere"],
    correct_option_index: 1,
    explanation: "The ozone layer is concentrated primarily in the lower portion of the stratosphere, from approximately 15 to 35 kilometers above Earth."
  },
  {
    id: 104,
    quiz_id: 1,
    section_name: "General Awareness",
    question_text: "Who has been recognized as the dynamic founder of the historical Gupta Empire in Indian history?",
    options: ["Samudragupta", "Chandragupta I", "Sri Gupta", "Ghatotkacha"],
    correct_option_index: 2,
    explanation: "Sri Gupta is widely acknowledged as the pre-eminent founder of the imperial Gupta Dynasty around the late 3rd century CE."
  },
  {
    id: 105,
    quiz_id: 1,
    section_name: "Quantitative Aptitude",
    question_text: "An article is sold at a 15% discount for $1,360. What would be the total selling price if it is sold at a 15% profit on the original cost?",
    options: ["$1,760", "$1,840", "$1,600", "$1,920"],
    correct_option_index: 1,
    explanation: "Discounted Price = 85% of Marked Price = 1360. MP = 1360 / 0.85 = 1600. Assuming Cost Price matches MP, a 15% profit increases the price to 1600 * 1.15 = 1840."
  },
  {
    id: 106,
    quiz_id: 1,
    section_name: "Quantitative Aptitude",
    question_text: "If 15 painters can finish painting a commercial residential estate in 12 days working 8 hours daily, how many days will 10 painters take to finish it working 9 hours a day?",
    options: ["16 days", "14 days", "20 days", "18 days"],
    correct_option_index: 0,
    explanation: "By standard work formula: M1 * D1 * H1 = M2 * D2 * H2. Thus, 15 * 12 * 8 = 10 * D2 * 9. 1440 = 90 * D2 => D2 = 16 days."
  },
  {
    id: 107,
    quiz_id: 1,
    section_name: "English Language",
    question_text: "Select the sentence segment that contains a grammatical error: 'Neither of the secondary path designs were successfully implemented during the first phase of research.'",
    options: [
      "Neither of the",
      "secondary path designs",
      "were successfully implemented",
      "during the first phase"
    ],
    correct_option_index: 2,
    explanation: "The singular pronoun 'Neither' requires a singular verb. Therefore, 'were successfully implemented' should be replaced with 'was successfully implemented'."
  },
  {
    id: 108,
    quiz_id: 1,
    section_name: "English Language",
    question_text: "Identify the alternative that represents the closest antonym of the vocabulary token: 'FRUGAL'",
    options: ["Parsimonious", "Extravagant", "Prudent", "Miserly"],
    correct_option_index: 1,
    explanation: "Frugal refers to thrifty or economical spending. Extravagant represents wasteful, lavish, or excessive expenditure, which is a direct antonym."
  },

  // Quiz 2 Questions
  {
    id: 201,
    quiz_id: 2,
    section_name: "General Awareness",
    question_text: "Consider the following statement sets regarding the Sovereign Gold Bond (SGB) Scheme in India. Which is correct?",
    options: [
      "Bonds are issued by commercial public banks on capital margins.",
      "The minimum permissible investment scale is 1 gram of gold.",
      "Individuals are prohibited from holding more than 2 kilograms annually.",
      "Capital gains tax is fully applied upon mature redemption transactions."
    ],
    correct_option_index: 1,
    explanation: "Under the SGB framework, the minimum investment unit is restricted to exactly 1 gram, making option B correct."
  }
];

export const INITIAL_RESULTS: Result[] = [
  {
    id: 501,
    quiz_id: 1,
    candidate_name: "Amit Kumar Sharma",
    candidate_email: "amit.sharma@domain.co.in",
    score: 14.5,
    answers: { 101: 2, 102: 1, 103: 1, 104: 2, 105: 1, 106: 0, 107: 1, 108: 0 },
    time_taken_seconds: 520,
    cheating_alerts_count: 0,
    section_scores: {
      "General Intelligence": { score: 4.0, correct: 2, incorrect: 0, unanswered: 0 },
      "General Awareness": { score: 4.0, correct: 2, incorrect: 0, unanswered: 0 },
      "Quantitative Aptitude": { score: 4.0, correct: 2, incorrect: 0, unanswered: 0 },
      "English Language": { score: 2.5, correct: 1, incorrect: 1, unanswered: 0 }
    },
    created_at: "2026-05-26 11:24:00"
  },
  {
    id: 502,
    quiz_id: 1,
    candidate_name: "Priya Rajvanshi",
    candidate_email: "priya.raj@edu.org",
    score: 12.0,
    answers: { 101: 2, 102: 1, 103: 0, 104: 2, 105: 1, 106: 2, 107: 2, 108: 1 },
    time_taken_seconds: 640,
    cheating_alerts_count: 1,
    section_scores: {
      "General Intelligence": { score: 4.0, correct: 2, incorrect: 0, unanswered: 0 },
      "General Awareness": { score: 1.5, correct: 1, incorrect: 1, unanswered: 0 },
      "Quantitative Aptitude": { score: 2.5, correct: 1, incorrect: 1, unanswered: 0 },
      "English Language": { score: 4.0, correct: 2, incorrect: 0, unanswered: 0 }
    },
    created_at: "2026-05-26 12:05:00"
  }
];

export const PLUGIN_METADATA_FILES = [
  {
    path: "competitive-exam-quiz.php",
    label: "competitive-exam-quiz.php (Main Core Entry)",
    type: "php",
    description: "Declares WordPress headers, provisions custom SQL database tables upon activation, registers core load action nodes, handles uninstallation, and bootstraps sample exam sheets automatically."
  },
  {
    path: "includes/class-quiz-db.php",
    label: "includes/class-quiz-db.php (Database Interface)",
    type: "php",
    description: "Commands standard custom table operations including SQL injections prevention, fetching quiz attributes, retrieving questions mapping lists, writing submitted scorecard records, and returning highscore leaderboard ranking summaries."
  },
  {
    path: "includes/class-quiz-ajax.php",
    label: "includes/class-quiz-ajax.php (Secure AJAX)",
    type: "php",
    description: "Acts as a secure firewall that processes server-side grading algorithms (preventing client data manipulation), verifies token nonces, compiles positive/negative mark balances, and populates JSON logs."
  },
  {
    path: "admin/class-quiz-admin.php",
    label: "admin/class-quiz-admin.php (Dashboard Interface)",
    type: "php",
    description: "Renders wp-admin navigation tabs, structures manual question entry modules, operates CSV question uploading parsers, outputs quiz delete gates, and compiles candidate results export matrices."
  },
  {
    path: "public/class-quiz-public.php",
    label: "public/class-quiz-public.php (Shortcode Binder)",
    type: "php",
    description: "Integrates the shortcode [competitive_quiz id='...'] and anchors script enqueuing parameters, including jsPDF external CDNs, stylesheets, and localization tokens."
  },
  {
    path: "public/css/quiz-style.css",
    label: "public/css/quiz-style.css (CBT Frontend Styles)",
    type: "css",
    description: "A resetting responsive CSS suite styled with deep blues and yellows, matching the classic Staff Selection Commission (SSC) Computer Based Test (CBT) web presentation."
  },
  {
    path: "public/js/quiz-engine.js",
    label: "public/js/quiz-engine.js (Live Test controller)",
    type: "javascript",
    description: "The client-side core state machine: processes countdown digital clocks, operates 5-state palette updates, intercept cheats (tab switching warnings), triggers auto-submit boundaries, and drafts jsPDF certificates on demand."
  },
  {
    path: "readme.txt",
    label: "readme.txt (WordPress standard readme)",
    type: "text",
    description: "Provides standard WordPress directory listings, installation guidelines, frequently asked questions, compatibility records, and technical specs details."
  }
];

export function getQuestionMarks(
  question: Question,
  quiz: Quiz
): { positive: number; negative: number } {
  // Start with quiz general fallbacks
  let pos = Number(quiz.positive_marks);
  let neg = Number(quiz.negative_marks);

  // 1. Apply Section-specific overrides if defined
  if (quiz.section_settings) {
    try {
      const parsed = typeof quiz.section_settings === 'string' ? JSON.parse(quiz.section_settings) : quiz.section_settings;
      const secName = question.section_name;
      if (parsed && parsed[secName]) {
        const secConf = parsed[secName];
        if (secConf.positive_marks !== undefined && secConf.positive_marks !== null && !isNaN(Number(secConf.positive_marks))) {
          pos = Number(secConf.positive_marks);
        }
        if (secConf.negative_marks !== undefined && secConf.negative_marks !== null && !isNaN(Number(secConf.negative_marks))) {
          neg = Number(secConf.negative_marks);
        }
      }
    } catch (e) {
      // JSON parse error fallback
    }
  }

  // 2. Apply Question-specific overrides (take absolute precedence)
  if (
    question.positive_marks !== undefined &&
    question.positive_marks !== null &&
    !isNaN(Number(question.positive_marks))
  ) {
    pos = Number(question.positive_marks);
  }
  if (
    question.negative_marks !== undefined &&
    question.negative_marks !== null &&
    !isNaN(Number(question.negative_marks))
  ) {
    neg = Number(question.negative_marks);
  }

  return { positive: pos, negative: neg };
}

